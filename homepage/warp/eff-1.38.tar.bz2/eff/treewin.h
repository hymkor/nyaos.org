/* -*- c++ -*- */
#ifndef TREEWIN_H
#define TREEWIN_H
#include "basicwin.h"

class VBuffer;

class TreeWin : public DirBasicWin {
  class TIterator; friend class TIterator;
  int nlists,startAt;
  void hookOnOpen();

  struct RestoreTreeWin;
  
  class Node {
    friend class TreeWin;
    class ::TreeWin::TIterator; friend class ::TreeWin::TIterator;
    enum { 
      NO_SUBDIRS  , SUBDIRS_OPEN , SUBDIRS_CLOSE , SUBDIRS_UNKNOWN ,
    } subdir;
    Node *children,*parent;
  public:
    Node *next,*prev;
  private:
    int nchildren,level;
    string name , fullname;
  public:
    Node()
      : subdir(NO_SUBDIRS),children(0),parent(0),next(0),prev(0)
	,nchildren(0),level(0){}
    explicit Node( const char *nm )
      : subdir(NO_SUBDIRS),children(0),parent(0),next(0),prev(0)
	,nchildren(0),level(0),name(nm),fullname(nm){}
    explicit Node( const string &nm )
      : subdir(NO_SUBDIRS),children(0),parent(0),next(0),prev(0)
	,nchildren(0),level(0),name(nm),fullname(nm){}
      
    ~Node();
    void operator = ( const char *nm )
      { name = fullname = nm; }
    void operator = ( const string &nm )
      { name = fullname = nm; }
      
    int open();
    void close(){ 
      if( subdir != NO_SUBDIRS )
	subdir = SUBDIRS_CLOSE;
    }
    int howManyLists();

    char *getPrintOut() const;
    int listFlatly( Node **&ptr );

    const string &getName() const { return name; }
    const string &getFullPath() const { return fullname; }

    void putbar(VBuffer &);

    struct Comparer {
      int method;
      int operator() (const Node *,const Node *)  const throw();
      Comparer(int m) : method(m) { }
    };
  } roots['Z'-'A'+1 ] , **flatlist;

  class TIterator : public BasicWin::Iterator {
    TreeWin *treeWin;
  public:
    explicit TIterator( TreeWin *tw ) : treeWin(tw) {}
    TIterator( const TIterator &it ) 
      : Iterator(it) , treeWin(it.treeWin) {}

    int can_forward() const;
    Iterator *dup() const;
    void mark(int){};
    int mark() const { return 0; }
    const char *getName() const
      { return treeWin->flatlist[n]->getName().c_str(); }
    bool getLine(VBuffer &,int w);
    void set(const Iterator &it);

    const Node *operator -> () const { return treeWin->flatlist[ N() ]; }
    Node *operator -> () { return treeWin->flatlist[ N() ]; }

    const char *getPath() const { return (*this)->fullname.c_str(); }
    void toUpper();
  };

  int makeFlatList();

public:
  int open( const string & );
  explicit TreeWin( const string &dir );
  ~TreeWin();

  RestoreWin *saveMe();
  
  Status runTreeWin(int key);
  Status run(int key){ return runTreeWin(key); }
  char titleLine(VBuffer &);

  const string &getCurrentDir() const throw()
    {  return flatlist[ cursor->N() ]->getFullPath(); }

  static int main(int x,int y,int w,int h,const char *dir);

  static unsigned color_titleline , color_titlebar , color_normal;

  virtual const char *what() const { return "TREE"; }
};
#endif

