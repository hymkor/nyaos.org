#define INCL_WINSWITCHLIST
#include <os2.h>

#include "fileswin.h"
#include "prowin.h"
#include "VBuffer.h"

struct ProcessWindow::RestoreProcessWin : public BasicWin::RestoreWin {
  RestoreWin *prev;

  RestoreProcessWin() : prev(0){}
  RestoreProcessWin(RestoreWin *r) : prev(r) {}
  ~RestoreProcessWin(){ delete prev; }
  BasicWin *restore(){
    BasicWin *tmp=new ProcessWindow(prev);
    prev=0;
    return tmp;
  }
  RestoreWin *dup(){
    return new RestoreProcessWin(prev->dup());
  }
};

/* �v���Z�X�E�C���h�E���A���̃E�C���h�E�ֈڍs���邱�Ƃ͖����̂ŁA
 * ��{�I�ɂǂ��ł��悢�B
 * (�v���Z�X�E�C���h�E�֍s���Ă���A�߂�Ƃ������Ƃ͗L�肦�邪�c)
 */
BasicWin::RestoreWin *ProcessWindow::saveMe()
{
  RestoreWin *restoreWin=getRestoreWin();
  if( restoreWin != 0 )
    restoreWin = restoreWin->dup();
  
  return new RestoreProcessWin( restoreWin );
}

unsigned ProcessWindow::color_normal    = 0x0F;
unsigned ProcessWindow::color_titlebar  = 0x9F;
unsigned ProcessWindow::color_titleline = 0x09;

void ProcessWindow::ProcessIterator::set( const BasicWin::Iterator &it_ )
{
  try{
    const ProcessIterator &it
      = dynamic_cast<const ProcessIterator &>( it_ );
    
    this->parent = it.parent;
  }catch(...){
    ;
  }
}

ProcessWindow::ProcessWindow(BasicWin::RestoreWin *r) : BasicWin(r)
{
  setColumn(1);
  top = new ProcessIterator(*this);
  heaven = top->dup();
  cursor = heaven->dup();
  earth = NULL;
}


ProcessWindow::Status ProcessWindow::runProcessWindow(int key)
{
  BasicWin *tmp=0;
  
  ProcessIterator *cursor=getCursor();
  switch( key ){
  case '2':
  case BIND_VIEW_TWO:
    try{
      RestoreWin *r=getRestoreWin();
      if( forkWin( tmp=new ProcessWindow(r ? r->dup() : 0 )) != 0 ){
	message("Can not open a new window");
	delete tmp;
	return CONTINUE;
      }
    }catch(...){
      message("can not open a new window");
      delete tmp;
    }
    return CONTINUE;

  case 'o':
  case BIND_LEAVE:
    try{
      BasicWin::RestoreWin *r=getRestoreWin();
      if( r==NULL )
	return zero_window(0);
      else
	replaceWin( r->restore() );
    }catch(...){
      message("Can not open a new window.");
      delete tmp;
    }
    return CONTINUE;

  case ('L' & 0x1F):
  case BIND_REPAINT:
    {
      int n=cursor->N();
      jobs.refresh();
      earth = NULL;
      cursor = dynamic_cast<ProcessIterator*>(top->dup());
      heaven = dynamic_cast<ProcessIterator*>(top->dup());
      
      while( n-- > 0  &&  cursor->can_forward() )
	cursor->forward();
      
      BasicWin::repaint();
    }
    break;

  case BIND_ENTER:
  case '\n':  case '\r':  case 'i':  case 'f':
    if( cursor != 0 )
      jobs.fg( cursor->N() );
    break;
    
  case '\b':
  case 'b':
  case 'u':
    if( cursor != 0 )
      jobs.bg( cursor->N() );
    break;

  default:
    return this->BasicWin::runBasicWin(key);
  }
  return CONTINUE;
}

char ProcessWindow::titleLine(VBuffer &vbuf)
{
  vbuf.color( color_titleline ) 
    << horizon_char << horizon_char << horizon_char
      << horizon_char << horizon_char ;

  vbuf.color( color_titlebar  ) << " Task Selector ";
  vbuf.color( color_titleline );
  return horizon_char;
}

bool ProcessWindow::ProcessIterator::getLine( VBuffer &vbuf , int w )
{
  vbuf.color( color_normal );

  SWENTRY &entry=parent->jobs[N()];
  
  const static char *progtype[] = {
    "DEF" , "FUL" , "VIO/W" , "PM" ,
    "VDM" , "???" , "???"   , "VDM/W",
  };

  vbuf.printf("%2d%5d%4d %-3s %-5s "
	      , N()
	      , entry.swctl.idProcess
	      , entry.swctl.idSession
	      , ( entry.swctl.uchVisibility == SWL_VISIBLE 
		 ? "YES"
		 : (entry.swctl.uchVisibility == SWL_INVISIBLE
		    ? "NO" : "???" ) )
	      , (  entry.swctl.bProgType > 8 
		 ? "???" : progtype[ entry.swctl.bProgType ] )
	      );
  for(const char *p=entry.swctl.szSwtitle ; *p != '\0' ; p++ )
    vbuf << (char)*p;

  return true;
}

int ProcessWindow::main(int x,int y,int w,int h)
{
  enum{ message_lines=2 };
  ProcessWindow *win=0;

  try{
    if( (win=new ProcessWindow(0) ) != NULL ){
      win->open(x,y,w,h-message_lines-1);
      return BasicWin::main( y+h-message_lines-1 , message_lines );
    }
  }catch(...){
    delete win;
  }
  return CONTINUE;
}
