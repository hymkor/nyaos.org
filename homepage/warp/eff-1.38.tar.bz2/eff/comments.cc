#undef DEBUG
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/video.h>

#include "basicwin.h"
#include "fileswin.h"
#include "wminput.h"
#include "ealib.h"
#include "os2eff.h"
#include "macros.h"
#include "autoptr.h"

BasicWin::Status FilesWin::commentWrite(int)
{
  static WmInput input(console_handle,bottom_handle);

  string target=getCursor()->getFullPath();

  wmout << "comment to " << target << " :" << flush;
  string remark = ExtAttr::getOneComment( target );
  if( input( remark ) < 0 ){
    wmout << "\ncannceled." << endl;
    return CONTINUE;
  }

  if( set_ascii_ea( target.c_str() , ".SUBJECT" , remark.c_str() ) == 0 ){
    // ���݂̃E�C���h�E�̕��փR�����g�𔽉f������.
    getCursor()->setSubject( remark );
    repaint_cursor_line();
    clear_message();
  }else{
    wmout << "\nunable to comment to '" << cursor->getName() << '\'' << endl;
  }
  return BasicWin::CONTINUE;
}

BasicWin::Status FilesWin::rename(int)
{
  message("rename %s to ? ",getCursor()->getName() );
  
  WmInput input(console_handle,bottom_handle);
  string oldName=getCursor()->getName();
  string newName=oldName;
  if( input(newName) > 0 ){
    string oldPath = AFile::makepath( getCurrentDir() , oldName );
    string newPath = AFile::makepath( getCurrentDir() , newName );
    
    // ����Ƀ��l�[���ł���΁A�t�@�C�����ă\�[�g����B
    if( ::rename(oldPath.c_str(),newPath.c_str()) == 0  ){
      MatchExactly match( newName.c_str() );
      
      this->reset();
      this->repaint();
      grep( match );
    }
  }
  clear_message();
  return CONTINUE;
}

BasicWin::Status FilesWin::relongname(int)
{
  message("longname for %s ? ",cursor->getName() );
  
  WmInput input(console_handle,bottom_handle);
  const char *longname = input( getCursor()->getLongname().c_str() );
  
  if( longname == NULL ){
    message( "\ncanceled.\n");
    return CONTINUE;
  }

  string target = getCursor()->getFullPath();

  if( (  longname[0] != '\0' 
       ? set_ascii_ea( target.c_str() , ".LONGNAME" , longname )
       : unset_ea( target.c_str() , ".LONGNAME" ) )==0 ){
    
    getCursor()->setLongname( longname );
    
    repaint_cursor_line();
    clear_message();
  }else{
    message("\nunable to relongname for '%s'\n",cursor->getName() );
  }
  return BasicWin::CONTINUE;
}

BasicWin::Status FilesWin::mkdir(int)
{
  message("new directory name ? ");

  WmInput input( console_handle , bottom_handle );
  string dirName;
  if( input( dirName ) >= 0 ){
    string dirPath = AFile::makepath( getCurrentDir() , dirName );
    // ����ɍ쐬�ł����
    if( ::mkdir( dirPath.c_str() , 0777 ) == 0 ){
      MatchExactly match( dirName.c_str() );
      
      this->reset();
      this->updateThisDirectory();
      grep( match );
    }
  }
  clear_message();
  return CONTINUE;
}

