#include <string>
#include <cstdio>

#include "pmint.h"
#include "basicwin.h"
#include "fileswin.h"

#define INCL_VIO
#define INCL_DOSPROCESS
#define INCL_DOSNLS
#include <os2.h>

#define DBG1(x) /**/

PastableObject *PastableObject::first=0;

class CopiedFile : public PastableObject {
  DirBasicWin::FileNames path;
public:
  CopiedFile( const string &p ) : path(p){}
  CopiedFile( const DirBasicWin::FileNames &p ) : path(p){}
  CopiedFile( const string &p , const string &lp) : path(p,lp){}

  const char *getPath() const { return path.c_str(); }
  const DirBasicWin::FileNames &getPaths() const { return path; }
};

class AFileToMove : public CopiedFile {
  string message;
public:
  AFileToMove( const string &path ) : CopiedFile(path){}
  AFileToMove( const DirBasicWin::FileNames &p ) : CopiedFile(p){}
  AFileToMove( const string &p , const string &lp ) : CopiedFile(p,lp){}

  int paste( const char *todir , int &nsuccess, int &nfail );
  const char *whatToDo(){
    message  = "copy ";
    message += getPath();
    return message.c_str();
  }
};

class AFileToCopy : public CopiedFile {
  string message;
public:
  AFileToCopy( const string &path ) : CopiedFile(path){}
  AFileToCopy( const DirBasicWin::FileNames &p ) : CopiedFile(p){}
  AFileToCopy( const string &p , const string &lp) : CopiedFile(p,lp){}
  
  int paste( const char *todir , int &nsuccess , int &nfail );
  const char *whatToDo(){
    message  = "move ";
    message += getPath();
    return message.c_str();
  }
};

int  FilesWin::copy2buffer(bool removeOriginal)
{
  int nfiles=0;
  string filestr;

  for( list<Node*>::iterator itr=nodes.begin() ; itr != nodes.end() ; itr++ ){
    if( (*itr)->getMark() ){
      ++nfiles;
      string path = AFile::makepath( getCurrentDir() , (*itr)->getName() );
      
      PastableObject::push(  removeOriginal
			   ? new AFileToMove( path ,  (*itr)->getLongname())
			   : new AFileToCopy( path , (*itr)->getLongname()));
      
      // copy to clipboard.
      if( path.find(' ') != string::npos ){
	filestr += '"';
	filestr += path;
	filestr += "\" ";
      }else{
	filestr += path;
	filestr += ' ';
      }
    }
  }
  if( nfiles <= 0 ){
    ++nfiles;
    string path = AFile::makepath( getCurrentDir() , getCursor()->getName() );
    PastableObject::push(  removeOriginal
			 ? new AFileToMove(path,getCursor()->getLongname())
			 : new AFileToCopy(path,getCursor()->getLongname()));
    
    // copy to clipboard.
    if( path.find(' ') != string::npos ){
      filestr += '"';
      filestr += path;
      filestr += "\" ";
    }else{
      filestr += path;
      filestr += ' ';
    }
  }
  PMInterface::writeClipBoard( filestr.c_str() );
  return nfiles;
}

BasicWin::Status  FilesWin::move_to_killring(int)
{
  message( "reserve %d file(s) to kill" , copy2buffer(true) );
  return CONTINUE;
}

BasicWin::Status  FilesWin::copy_to_killring(int)
{
  message( "reserve %d file(s) to copy" , copy2buffer(false) );
  return CONTINUE;
}

static DirBasicWin::FileManip::FileSystem getHowToMove(int src,int dst)
{
  int srcFsys = AFile::getFileSys( src );
  int dstFsys = AFile::getFileSys( dst );

  if( srcFsys == 'H' && dstFsys == 'F' )
    return DirBasicWin::FileManip::HPFStoFAT;
  else if( srcFsys == 'F' && dstFsys == 'H' )
    return DirBasicWin::FileManip::FATtoHPFS;
  return DirBasicWin::FileManip::NORMALMOVE;
}


int AFileToMove::paste( const char *todir , int &nsuccess , int &nfail )
{
  DirBasicWin::FileMove fmove;
  fmove.fileSystem = getHowToMove(getPath()[0],todir[0]);
  if( fmove( getPaths() , todir , DirBasicWin::FileManip::DST_IS_DIR )==0 ){
    ++nsuccess;
    return 0;
  }else{
    ++nfail;
    return -1;
  }
}

int AFileToCopy::paste( const char *todir , int &nsuccess , int &nfail )
{
  DirBasicWin::FileCopy fcopy;
  fcopy.fileSystem = getHowToMove(getPath()[0],todir[0]);
  if( fcopy( getPaths() , todir , DirBasicWin::FileManip::DST_IS_DIR )==0 ){
    ++nsuccess;
    return 0;
  }else{
    ++nfail;
    return -1;
  }
}

BasicWin::Status  DirBasicWin::paste_from_killring(int)
{
  PastableObject *obj=0;
  int nSuccess=0;
  int nFailure=0;

  while( (obj=PastableObject::pop()) != 0 ){
    if( obj->paste( getCurrentDir().c_str() , nSuccess , nFailure ) == 0 ){
      message( "\n%s to %s" , obj->whatToDo() , getCurrentDir().c_str() );
    }else{
      message( "\nfail to %s" , obj->whatToDo() );
    }
    delete obj;
  }
  message( "\n%d object(s) pasted." , nSuccess );
  if( nFailure > 0 )
    message( " but, %d couldn't." , nFailure );

  for( BasicWin *ptr=BasicWin::first ; ptr ; ptr=ptr->getNextWin() ){
    FilesWin *dirptr=dynamic_cast<FilesWin*>(ptr);
    if( dirptr )
      dirptr->refresh();
  }
  return CONTINUE;
}
