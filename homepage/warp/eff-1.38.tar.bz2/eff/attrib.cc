#include <ctime>
#include <cstdio>
#include <utime.h>
#include "wminput.h"
#include "os2.h"
#include "fileswin.h"

BasicWin::Status FilesWin::attrib(int)
{
  FILESTATUS3 filestatus;
  _chdir2( this->getCurrentDir().c_str() );

  /* �}�[�N�̗L���𒲂ׂ� */
  bool markexist=false;
  ULONG attr=0;
  for( list<Node*>::iterator itr=nodes.begin() ; itr != nodes.end() ; ++itr ){
    if( (*itr)->getMark() ){
      /* �}�[�N���������̂ŁA�ŏ��̃}�[�N�s�̑����𓾂� */
      markexist = (*itr)->getAttr();
      DosQueryPathInfo(  (PSZ)(*itr)->getName().c_str() , 1 , &filestatus 
		       , sizeof(filestatus) );
      attr = filestatus.attrFile;
      markexist = true;
      break;
    }
  }
  if( !markexist ){
    /* �}�[�N��������΁A�J�[�\���s�̑����𓾂� */
    DosQueryPathInfo(  (PSZ)getCursor()->getName() , 1 , &filestatus 
		     , sizeof(filestatus) );
    attr = filestatus.attrFile;

    for(;;){
      message( "%s's attribute : %cR) %cH) %cS) %cA)"
	      " ENTER)to Fix ESC)to CANCEL ?\n"
	      , getCursor()->getName()
	      , attr & AFile::READONLY ? '+' : '-'
	      , attr & AFile::HIDDEN   ? '+' : '-'
	      , attr & AFile::SYSTEM   ? '+' : '-'
	      , attr & AFile::ARCHIVED  ? '+' : '-' );
      switch( readkey() ){
      case 'r':
      case 'R':
	attr ^= AFile::READONLY;
	break;
      case 'h':
      case 'H':
	attr ^= AFile::HIDDEN;
	break;
      case 's':
      case 'S':
	attr ^= AFile::SYSTEM;
	break;
      case 'A':
      case 'a':
	attr ^= AFile::ARCHIVED;
	break;
      case '\n':
      case '\r':
	filestatus.attrFile = attr;
	DosSetPathInfo(  (PSZ)getCursor()->getName() , 1 , &filestatus
		       , sizeof(filestatus) , 0x10 );
	this->refresh();
	return CONTINUE;
      case '\x1B':
	return CONTINUE;
      }
    }
  }else{
    /* �}�[�N������΁AAND �p�^�[���� OR �p�^�[������� */
    int acts[4]={0,0,0,0};

    for(;;){
      int orBits,andBits;
      message("Marked files attribute : %cR) %cH) %cS) %cA)"
	      " ENTER)to Fix ESC)to CANCEL ?\n"
	      , "*+-"[ acts[0] ]
	      , "*+-"[ acts[1] ]
	      , "*+-"[ acts[2] ]
	      , "*+-"[ acts[3] ] );
      switch( readkey() ){
      case 'r':
      case 'R':
	acts[0] = (acts[0]+1) % 3;
	break;
      case 'h':
      case 'H':
	acts[1] = (acts[1]+1) % 3;
	break;
      case 's':
      case 'S':
	acts[2] = (acts[2]+1) % 3;
	break;
      case 'A':
      case 'a':
	acts[3] = (acts[3]+1) % 3;
	attr ^= AFile::ARCHIVED;
	break;
      case '\r':
      case '\n':
	orBits = (  (acts[0] == 1 ? AFile::READONLY : 0 )
		  | (acts[1] == 1 ? AFile::HIDDEN   : 0 )
		  | (acts[2] == 1 ? AFile::SYSTEM   : 0 )
		  | (acts[3] == 1 ? AFile::ARCHIVED  : 0 ) );
	andBits= ~(  (acts[0] == 2 ? AFile::READONLY : 0 )
		   | (acts[1] == 2 ? AFile::HIDDEN   : 0 )
		   | (acts[2] == 2 ? AFile::SYSTEM   : 0 )
		   | (acts[3] == 2 ? AFile::ARCHIVED  : 0 ) );
	for(  list<Node*>::iterator itr=nodes.begin()
	    ; itr != nodes.end() ; ++itr ){
	  
	  if( (*itr)->getMark() ){
	    DosQueryPathInfo(  (PSZ)(*itr)->getName().c_str() , 1
			     , &filestatus , sizeof(filestatus) );
	    filestatus.attrFile |= orBits;
	    filestatus.attrFile &= andBits;
	    DosSetPathInfo(  (PSZ)(*itr)->getName().c_str() , 1
			   , &filestatus , sizeof(filestatus) , 0x10 );
	  }
	}
	this->refresh();
	return CONTINUE;
      case '\x1B':
	return CONTINUE;
      }
    }
  }
}

BasicWin::Status FilesWin::touchNow(int)
{
  struct utimbuf newStamp ;
  time_t now;

  time( &now );
  newStamp.actime = now;
  newStamp.modtime = now;
  AFile::Date date( *localtime( &now ) );

  char ymd[ 32 ];
  sprintf(ymd,"%04d/%02d/%02d %02d:%02d:%02d"
	  , date.year	  , date.month
	  , date.day	  , date.hour
	  , date.minute	  , date.second );

  message( "New time stamp ? ", cursor->getName() );
  static WmInput timeInput(console_handle,bottom_handle);
  const char *newYmd=timeInput( ymd );
  if( newYmd == NULL  || newYmd[0] == '\0' ){
    message( "\ncanceled" );
    return CONTINUE;
  }

  char *p;
  if(   (date.year = strtoul(newYmd,&p,10)) <= 1900
     ||  date.year >= 2500
     ||  *p != '/'
     || (date.month = strtoul(p+1,&p,10)) < 1
     ||  date.month > 12
     ||  *p != '/'
     || (date.day  = strtoul(p+1,&p,10)) < 1
     ||  date.day > 31
     ||  *p != ' '
     || (date.hour = strtoul(p+1,&p,10)) >= 24
     ||  *p != ':'
     || (date.minute = strtoul(p+1,&p,10)) >= 60
     ||  *p != ':'
     || (date.second = strtoul(p+1,&p,10)) >= 60 )
    {
      message( "\nSyntax Error! Time stamp is not changed." );
      return CONTINUE;
    }

  int done=0;
  for( list<Node*>::iterator itr=nodes.begin() ; itr != nodes.end(); ++itr ){
    if( (*itr)->getMark() ){
      string path=(*itr)->makepath( this->getCurrentDir() );
      utime( path.c_str() , &newStamp );
      (*itr)->setAccessedDate( date );
      (*itr)->setWrittenDate( date );
      done++;
    }
  }
  if( done <= 0 ){
    Node &node=getCursor()->getNode();
    string path=node.makepath( this->getCurrentDir() );
    utime( path.c_str() , &newStamp );    
    node.setAccessedDate( date );
    node.setWrittenDate( date );
  }
  repaint();
  return CONTINUE;
}
