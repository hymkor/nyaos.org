#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstdarg>
#include <cstring>
#include <strstream>
#include <fstream>
#include <sys/video.h>
#include <sys/kbdscan.h>

#include "VBuffer.h"

#include "afile.h"
#include "wminput.h"
#include "effetc.h"
#include "basicwin.h"
#include "effcfg.h"
#include "macros.h"
#include "prowin.h"
#include "textwin.h"
#include "keybind.h"

#define INCL_DOSQUEUES
#include <os2.h>

#define VER "1.37"

char BasicWin::horizon_char='-';
extern int extJumpList[ 0x200 ];
bool BasicWin::is_message_remained=true;

unsigned BasicWin::color_cursor		= 0x10 ;
unsigned BasicWin::color_standard	= 0x0F ;
unsigned BasicWin::color_message	= 0x0F ;
unsigned BasicWin::color_background	= 0x00 ;

int BasicWin::default_ndevides=2;

int BasicWin::Iterator::forward()
{  return can_forward() ? ++n : -1 ; }

int BasicWin::Iterator::backward()
{  return  n > 0 ? --n : -1 ; }

void BasicWin::Iterator::putat(int x,int y,int at,int width)
{
  VBuffer vbuf;

  if( getLine(vbuf,width) )
    vbuf.putatPart( x , y , at , width , ' ' );
}

void BasicWin::hookOnOpen()
{
  setColumn(last_ndevides);
}

void BasicWin::reform(int n)
{
  if( n == -1 )
    n = cursor->N();
  else
    cursor->gotoN( n );

  heaven->gotoN( n - n % getElementsPerScreen() );
}

static void V_xorattr(int xor,int x,int y,int count)
{
  char *buffer = (char*)_tmalloc(count*2);
  v_getline(buffer,x,y,count);
  short *p=(short*)buffer;
  xor <<= 8;
  for(int i=0;i<count;i++)
    *p++ ^= xor;
  v_putline(buffer,x,y,count);
  _tfree(buffer);
}

void BasicWin::printCursor()
{
  if( cursor != 0 ){
    int line   = cursor->N() - heaven->N();
    int column = line / height;
    int w = getWidthPerColumn();
    int x = x0 + column * w ;
    int y = y0 + line % height;
    V_xorattr( color_cursor , x , y , w );
  }
}

wm_handle BasicWin::console_handle=NULL;
wm_handle BasicWin::bottom_handle=NULL;
wm_ostream BasicWin::wmout;
bool BasicWin::wmoutIsCout=true;

BasicWin *BasicWin::first   = NULL;
BasicWin *BasicWin::garbage = NULL;
BasicWin *BasicWin::focus   = NULL;

int BasicWin::Iterator::gotoN(int N)
{
  if( N > n ){
    while( can_forward() && N > n )
      forward();
  }else if( N < n ){
    while( can_backward() && N < n )
      backward();
  }
  return n;
}

void BasicWin::open(int x,int y,int w,int h)
{
  x0 = x ; y0 = y ; width = w ; height = h-1;
  heaven = top->dup();
  cursor = top->dup();
  earth  = top->dup();

  hookOnOpen();

  /* ���łɘA������Ă�����A���̘A������U�O�� */
  if( next != NULL )    next->prev = prev;
  if( prev != NULL )    prev->next = next;

  /* �ĘA�� */
  if( first == NULL ){
    prev = next = NULL;
    first = this;
    return;
  }
  if( this->y0 < first->y0 ){
    next = first;
    prev = NULL;
    first->prev = this;
    first = this;
    return;
  }
  
  BasicWin *cur=first;
  BasicWin *nxt=cur->next;
  while( nxt != NULL ){
    if( cur->y0 <= this->y0  &&  this->y0 < nxt->y0  ){
      // cur �� this �� nxt �Ȃ�΁Acur �̎���this ����������.
      cur->next = this;
      nxt->prev = this;
      this->prev = cur;
      this->next = nxt;
      return;
    }
    cur = nxt;
    nxt = nxt->next;
  }
  // ���[�ɐڑ�����B
  cur->next = this;
  this->prev = cur;
  this->next = NULL;
}


int BasicWin::close()
{
  if( next != NULL ){
    /* �s�����̃E�C���h�E�ɕ����^���� */
    next->y0 = this->y0;
    next->height += this->height+1;
    
    focus = next;
  }else if( prev != NULL ){
    /* �s��O�̃E�C���h�E�ɕ����^���� */
    prev->height += this->height+1;
    focus = prev;
  }else{
    focus = NULL;
  }
  /* �㉺�ɃE�C���h�E�������ꍇ�͂ǂ����悤���Ȃ� */
  
  if( next != NULL )    next->prev = prev;
  if( prev != NULL )    prev->next = next;
  if( first == this )   first = (prev ? prev : next );
  
  /* ���݂̃E�C���h�E���폜���X�g�ɉ����� */
  addDeleteQueue();
  return 0;
}

void BasicWin::replaceWin( BasicWin *another , const char *cursorAt )
{
  if( another == 0 )
    return;

  /* �V�����E�C���h�E���쐬���� */
  another->x0 = x0;
  another->y0 = y0;
  another->width  = width;
  another->height = height;

  another->heaven = another->top->dup();
  another->cursor = another->top->dup();
  another->earth  = another->top->dup();

  another->prev  = prev;
  if( prev ){
    prev->next = another;
    prev = 0;
  }
  another->next  = next;
  if( next ){
    next->prev = another;
    next = 0;
  }
  if( focus == this )
    focus = another;
  if( first == this )
    first = another;
  
  another->last_ndevides = this->last_ndevides;
  another->hookOnOpen();
  /* ���܂ł̃E�C���h�E���폜���X�g�ɒǉ����� */
  addDeleteQueue();
  
  if( cursorAt ){
    MatchExactly match( cursorAt );
    another->grep( match );
  }
  another->repaint();
}

int BasicWin::forkWin( BasicWin *that )
{
  if( that == NULL  ||  getAllHeight() < 4 )
    return -1;
  
  int upper=getAllHeight() / 2;
  int lower=getAllHeight() - upper;

  this->height = upper - 1;
  this->reform();
  this->repaint();

  that->last_ndevides = this->last_ndevides;
  that->open( x0 , y0+upper , width , lower );

  /* �J�[�\���ʒu���Č����� */
  MatchExactly match( cursor->getName() );
  if( ! that->grep( match ) )
    that->repaint();
  
  /* �����ۂɖ߂��̃E�C���h�E�̏������ʂ��Ă��� */
  that->restoreWin = ( restoreWin ? restoreWin->dup() : 0 );
    
  return 0;
}

BasicWin::~BasicWin(void)
{
  delete restoreWin;
  
  if( next != NULL )
    next->prev = this->prev;
  
  if( prev != NULL ){
    prev->next = this->next;
  }else if( first == this ){
    first = next;
  }
}

void BasicWin::repaint(void)
{
  horizon_char = Property::root["eff.directory.horizon"].value("-")[0];

  if( heaven == NULL  ||  ! heaven->isOk()  ){
    v_attrib( color_background );
    v_scroll(x0,y0,width,height,1,V_SCROLL_CLEAR);
    earth = cursor = NULL;
    return;
  }

  // �J�[�\���s�ʒu���L��������.
  int nHeaven = ( heaven != NULL ? heaven->N() : 0 );
  int nCursor = ( cursor != NULL ? cursor->N() : nHeaven );

  // heaven �ȍ~�̍s�̍ĕ\��.
  v_attrib( color_standard );

  earth = heaven->dup();

  int j=0; // 0...ndevides-1 : ��ʒu.
  int i=0; // 0...height -1 : �s�ʒu.

  int w=getWidthPerColumn();
  int n=getColumn();

  for(;;){
    earth->putat( x0+j*w , y0+i , print_offset , w );
    
    if( ++i >= height ){
      i=0;
      if( ++j >= n )
	break;
    }

    if( ! earth->can_forward() ){
      if( i < height ){
	v_attrib( color_background );
	v_scroll( x0+w*j, y0+i, x0+w*j+w-1 , y0+height-1, 1 , V_SCROLL_CLEAR );
      }
      if( ++j < n ){
	v_attrib( color_background );
	v_scroll( x0+w*j, y0 , x0+width-1 , y0+height-1, 1 , V_SCROLL_CLEAR );
      }
      break;
    }
    earth->forward();
  }
  if( w*n < width ){
    v_attrib( color_background );
    v_scroll( x0+w*n , y0 , x0+width-1 , y0+height-1,1,V_SCROLL_CLEAR);
  }

  // �J�[�\���s�ʒu�̉�
  cursor = heaven->dup();
  if( nCursor <= earth->N() )
    cursor->gotoN(nCursor);
  
  VBuffer vbuf;
  char linechar=titleLine( vbuf ) ;
  vbuf.putatPart( x0 , y0+height , 0 , width , linechar );
}

static char *line_buffer=NULL;

void BasicWin::scrollup(void)
{
  if( earth->forward() >= 0 ){
    heaven->forward();
    if( getColumn() >= 2 ){
      if( line_buffer == NULL )
	line_buffer = (char*)_tmalloc( width*2 );

      v_getline( line_buffer , x0 , y0 , width );
    }
    v_scroll(x0,y0,x0+width-1,y0+height-1,1,V_SCROLL_UP);

    int w=getWidthPerColumn();
    if( ndevides >= 2 ){
      v_putline(  line_buffer + 2*w
		, x0
		, y0+height-1
		, width - w );
    }
    earth->putat(  x0+w*(getColumn()-1)
		 , y0+height-1
		 , print_offset
		 , w );
  }
}

BasicWin::Status BasicWin::gotoRight(int)
{
  if( cursor->N() + height <= earth->N() ){
    /* �E�Ɉړ��\ */
    for(int i=0;i<height;i++){
      if( ! cursor->can_forward() )
	break;
      cursor->forward();
    }
  }else if( earth->can_forward() >= 0 ){
    /* �E�Ɉړ��ł��Ȃ��̂ŁA���փX�N���[�������� */
    for(int i=0;i<height;i++){
      if( cursor->can_forward() )
	cursor->forward();
    }
    heaven->gotoN( cursor->N() - cursor->N() % getElementsPerScreen() );
    repaint();
  }
  return CONTINUE;
}

BasicWin::Status BasicWin::gotoLeft(int)
{
  if( cursor->N() - height >= heaven->N() ){
    /* ���ֈړ��\ */
    for(int i=0 ; i<height && cursor->can_backward() ; i++)
      cursor->backward();
  }else if( heaven->can_backward() ){
    for(int i=0;i<height;i++)
      cursor->backward();
    heaven->gotoN( cursor->N() - cursor->N() % getElementsPerScreen() );
    repaint();
  }
  return CONTINUE;
}


void BasicWin::scrolldown(void)
{
  if( heaven->backward() >= 0 ){
    if( ndevides >= 2 ){
      if( line_buffer == NULL )
	line_buffer = (char*)_tmalloc( width*2 );
      v_getline( line_buffer , x0 , y0+height-1 , width );
    }
    v_scroll(x0,y0,x0+width-1,y0+height-1,1,V_SCROLL_DOWN);
    if( earth->N()-heaven->N() >= height*ndevides )
      earth->backward();
    if( getColumn() >= 2 ){
      v_putline(  line_buffer
		, x0+ getWidthPerColumn()
		, y0
		, getWidthPerColumn()*(getColumn()-1) );
    }
    heaven->putat( x0 , y0 , print_offset , getWidthPerColumn() );
  }
}

void BasicWin::repaint_cursor_line(void)
{
  if( cursor != NULL ){
    int i=cursor->N()-heaven->N();
    int x=(i / height);
    int y=(i % height);
    
    cursor->putat(  x0+ x*getWidthPerColumn() 
		  , y0+y
		  , print_offset
		  , getWidthPerColumn() );
  }
}

BasicWin::Status BasicWin::forward(int)
{
  if( cursor->forward() >= 0  &&  cursor->N() > earth->N() ){
    if( getColumn() <= 1 ){
      /* 1��\���̎��́A�㉺�ɃX�N���[������̂� */
      scrollup();
    }else{
      /* ����\���̎��́A�y�[�W���O���� */
      heaven->gotoN( cursor->N() - cursor->N() % getElementsPerScreen() );
      repaint();
    }
  }
  return CONTINUE;
}

BasicWin::Status BasicWin::backward(int)
{
  if( cursor->backward() >= 0  &&  cursor->N() < heaven->N() ){
    if( getColumn() <= 1 ){
      /* 1�s�\���̎��́A�㉺�ɃX�N���[������̂� */
      scrolldown();
    }else{
      /* ���s�\���̎��́A�������փy�[�W���O���� */
      heaven->gotoN( cursor->N() - cursor->N() % getElementsPerScreen() );
      repaint();
    }
  }
  return CONTINUE;
}

BasicWin::Status BasicWin::forward_page(int)
{
  int nCursor= ( cursor != 0 ? cursor->N() - heaven->N() : 0 );

  for(int i=0 ; i<height  &&  earth->forward() >= 0 ; i++)
    heaven->forward();

  cursor = heaven->dup();
  for(int i=0;i<nCursor && cursor->can_forward() ;i++)
    cursor->forward();

  repaint();
  return CONTINUE;
}

BasicWin::Status BasicWin::backward_page(int)
{
  int nCursor = ( cursor != 0 ? cursor->N() - heaven->N() : 0 );

  for(int i=0;i<height  &&  heaven->backward() >= 0 ;i++)
    ;

  cursor = heaven->dup();
  for(int i=0;i<nCursor && cursor->can_forward() ;i++)
    cursor->forward();

  repaint();
  return CONTINUE;
}

BasicWin::Status BasicWin::goto_head(int)
{
  earth = 0;
  
  while( heaven->can_backward() )
    heaven->backward();

  cursor = heaven->dup();
  repaint();
  return CONTINUE;
}

BasicWin::Status BasicWin::goto_tail(int)
{
  while( earth->can_forward() ){
    heaven->forward();
    earth->forward();
  }
  cursor = earth->dup();
  repaint();
  return CONTINUE;
}
BasicWin::Status BasicWin::quit(int)
{
  wmout << "Quit ? [Y/N]" << flush;
  box_cursor_on();
  

  if( readkey() == 'y' ){
    return QUIT;
  }else{
    cursor_off();
    clear_message();
    return CONTINUE;
  }
}

BasicWin::Status BasicWin::quit_without_ask(int)
{
  return QUIT;
}

BasicWin::Status BasicWin::zero_window(int)
{
  this->close();
  if( focus != 0 )
    focus->repaint();
  return CONTINUE;
}

BasicWin::Status BasicWin::next_window(int)
{ 
  focus = focus->next;
  if( focus == NULL )
    focus = first;
  focus->repaint();
  return CONTINUE;
}
BasicWin::Status BasicWin::do_nothing(int){ return CONTINUE; }

BasicWin::Status BasicWin::one_window(int)
{
  int y=y0;
  int h=height+1;
  BasicWin *it=first ;
  
  while( it != NULL ){
    BasicWin *nxt=it->next;
    if( it != this ){
      if( it->y0 <= y ){
	y = it->y0;
      }
      h += it->height+1;
      delete it;
    }
    it = nxt;
  }
  y0 = y;
  height = h-1;
  this->repaint();
  return CONTINUE;
}

/* s ���u.�v���u..�v�Ȃ� true �B�����Ȃ���� false */
inline static bool isCurrentOrParent( const char *s )
{
  if( s[0] == '.' ){
    if( s[1] == '.' && s[2] == '\0' )
      return true;
    else if( s[1] == '\0')
      return true;
  }
  return false;
}

BasicWin::Status BasicWin::markAll(int key)
{
  autoptr_t<Iterator> iter(top->dup());
  int n=0;
  for(;;){
    if( iter->mark() ) ++n;
    if( ! iter->can_forward() ) break;
    iter->forward();
  }
  iter = top->dup();
  for(;;){
    /* ���łɈ�ł��}�[�N������΁A�}�[�N�������B
     * �J�����g�f�B���N�g������e�f�B���N�g�����̏ꍇ���A�}�[�N������ */
    iter->mark( n > 0 || isCurrentOrParent(iter->getName()) ? 0 : 1 );
    if( ! iter->can_forward() ) break;
    iter->forward();
  }
  repaint();
  return CONTINUE;
}

BasicWin::Status BasicWin::markAndForward(int key)
{
  cursor->mark( cursor->mark() ? 0 : 1 );
  repaint_cursor_line();
  forward(key);
  return CONTINUE;
}
BasicWin::Status BasicWin::backwardAndMark(int key)
{
  backward(key);
  cursor->mark( cursor->mark() ? 0 : 1 );
  repaint_cursor_line();
  return CONTINUE;
}

string BasicWin::getAnotherWindowTitle()
{
  BasicWin *win=NULL;
  DirBasicWin *dirwin=NULL;
  if(   (   (win=getNext()) != NULL
	 && (dirwin=dynamic_cast<DirBasicWin*>(win)) != NULL )
     || (   (win=getPrev()) != NULL
	 && (dirwin=dynamic_cast<DirBasicWin*>(win)) != NULL ) ){
    return dirwin->getCurrentDir();    
  }
  return "";
}

string BasicWin::getMarkedNames()
{
  string result;
  
  int n=0;
  Iterator *iter=top->dup();
  for(;;){
    if( iter->mark() ){
      result += iter->getName();
      result += ' ';
      ++n;
    }
    if( ! iter->can_forward() )
      break;
    iter->forward();
  }
  delete iter;
  if( n == 0 )
    result += cursor->getName();
  return result;
}

void BasicWin::listupMarkedNames( vector<string> &vec )
{
  vec.clear();

  Iterator *iter=top->dup();
  for(;;){
    if( iter->mark() )
      vec.push_back( iter->getName() );
    if( ! iter->can_forward() )
      break;
    iter->forward();
  }
  delete iter;
  if( vec.size() == 0 )
    vec.push_back( cursor->getName() );
}

int BasicWin::extractDollar( int ch , bool fromStdin , string &result )
{
  int flag=0;
  switch( ch ){
  case '$':
    result += '$';
    break;
  case 'P':
    flag |= USED_P;
    if( fromStdin )
      break;
    // continue to next case.

  case 'C':
  case 'c':
    result += cursor->getName();
    flag |= USED_C;
    break;
  case 'w':
  case 'W':
    flag |= USED_W;
    break;
  case 't':
  case 'T':
    result += getAnotherWindowTitle();
    flag |= USED_T;
    break;
  case 'M':
  case 'm':
    result += getMarkedNames();
    flag |= USED_W;
    break;
  }
  return flag;
}

/* �R�}���h���C���̃x�[�X������($�Ȃǂ��g����������)��W�J����.
 *	base		�x�[�X������
 *	fromStdin	�W�����͂�p����ꍇ true �ɂ���(���ʂ� false)
 *	cmdline		�W�J����
 * return
 *	USED_? �̃r�b�g��
 *	-1 : cancel
 */
int BasicWin::makeLaunchBase(  const string &base
			     , bool fromStdin
			     , string &cmdline )
{
  int flag=0;
  cmdline.erase();
  
  for( string::const_iterator sp=base.begin() ; sp != base.end() ; ++sp ){
    if( *sp != '$' ){
      cmdline += *sp;
    }else switch( *++sp ){
    case 't':
    case 'T':
      {
	wmout << "Target ? " << flush;
	WmInput input(console_handle,bottom_handle);
	const char *answer=input( getAnotherWindowTitle().c_str() );
	wmout << endl;
	if( answer == NULL )
	  return -1;
	cmdline += answer;
	flag |= USED_T;
      }
      break;
      
    case 'w':
    case 'W':
      flag |= USED_W;
      break;
      
    case '$':
      cmdline += '$';
      break;

    case 'P':
      flag |= USED_P;
      if( fromStdin )
	break;
      // continue to next case.
      
    case 'c':
    case 'C':
      cmdline += cursor->getName();
      flag |= USED_C;
      break;
      
    case '{':
      {
	string prompt , defaultValue;
	
	while( *++sp != '}' ){
	  if( *sp == '\0' ){
	    wmout << "Syntax Error in configuration file." << flush;
	    return -1;
	  }else if( *sp == '=' ){
	    // find default value !
	    while( *++sp != '}' ){
	      if( *sp == '\0' ){
		wmout << "Syntax Error in configuration file." << endl;
		return -1;
	      }else if( *sp == '$' ){
		flag |= extractDollar( *++sp , fromStdin , defaultValue );
	      }else{
		defaultValue += *sp;
	      }
	    }
	    break;
	  }else if( *sp == '$' ){
	    flag |= extractDollar( *++sp , fromStdin , prompt );
	  }else{
	    prompt += *sp;
	  }
	}
	wmout << prompt << flush;
	WmInput input(console_handle,bottom_handle);
	string answer=defaultValue;
	if( input( answer ) <= 0 )
	  return -1;
	wmout << endl;
	cmdline += answer;
      }
      break;
	
    case 'm':
    case 'M':
      cmdline += getMarkedNames();
      flag |= USED_M;
      break;
    }// end switch and end-if.
  }// end loop.
  
  return flag;
}

int BasicWin::makeLaunchBase2(  const string &base
			      , bool fromStdin
			      , string &cmdline )
{
  int bits=makeLaunchBase(base,fromStdin,cmdline);
  if( bits == -1 || cmdline.empty() )
    return -1;

  /* $C �� $F ���g���Ă��Ȃ��ꍇ�͖����ɒǉ�����B*/
  if( (bits & (USED_P | USED_C))==0  ){
    cmdline += ' ';
    cmdline += cursor->getName();
  }
  return bits;
}

BasicWin::Status BasicWin::launcher(int key)
{
  Launcher *launcher=Launcher::at( key );
  if( launcher == 0 )
    return CONTINUE;

  box_cursor_on();
  CommandLauncher *cmdLauncher=dynamic_cast<CommandLauncher*>( launcher );
  if( cmdLauncher != 0 ){
    string cmdline;
    
    int bits=makeLaunchBase( cmdLauncher->command() , false , cmdline );
    if( bits == -1 )
      return CONTINUE;
    
    wm_cvis( console_handle , 1 );

    ScrnSave scrnsave;

    system( cmdline.c_str() );
    if( bits & USED_W ){
      puts("[Hit Any Key]");
      readkey();
    }
  }
  RexxLauncher *rexxLauncher=dynamic_cast<RexxLauncher*>( launcher );
  if( rexxLauncher != 0 ){
    vector<string> marknodes;
    listupMarkedNames( marknodes );
    (**rexxLauncher)( marknodes );
  }
  cursor_off();
  refreshAll();
  // repaintAllWin(0);
  
  return CONTINUE;
}
  
void BasicWin::Iterator::mark(int)
{ /* nothing to do */ }

int BasicWin::Iterator::mark() const
{ return 0; }
  

BasicWin::Status BasicWin::change_column(int x)
{
  setColumn( x );
  last_ndevides = getColumn();
  cursor = 0;
  repaint();
  return CONTINUE;
}

BasicWin::Status BasicWin::one_devide(int)
{  return change_column( 1 ); }

BasicWin::Status BasicWin::two_devide(int)
{  return change_column( 2 ); }

BasicWin::Status BasicWin::three_devide(int)
{  return change_column( 3 ); }
  
BasicWin::Status BasicWin::four_devide(int)
{  return change_column( 4 ); }

BasicWin::Status BasicWin::five_devide(int)
{  return change_column( 5 ); }

BasicWin::Status BasicWin::inc_devide(int)
{  return getWidthPerColumn()<12 ? CONTINUE : change_column(getColumn()+1); }

BasicWin::Status BasicWin::dec_devide(int)
{  return getColumn() <= 1 ? CONTINUE : change_column(getColumn()-1); }

BasicWin::Status BasicWin::makeProcessWindow(int)
{
  BasicWin *newWin=0;
  if( (newWin=new ProcessWindow(this->saveMe())) == 0 )
    wmout << "Can not open TASK VIEW" << flush;
  else
    this->replaceWin(newWin);
  return CONTINUE;
}

BasicWin::Status BasicWin::makeHelpWindow(int)
{
  BasicWin *newWin = new TextWin( saveMe() );

  if( newWin == NULL )
    wmout << "Can not open Help View" << flush;
  else
    this->replaceWin(newWin);

  return CONTINUE;
}

BasicWin::Status BasicWin::incPrintOffset(int)
{
  print_offset++;
  repaint();
  return CONTINUE;
}
BasicWin::Status BasicWin::decPrintOffset(int)
{
  if( print_offset > 0 )
    --print_offset;
  repaint();
  return CONTINUE;
}

BasicWin::Status BasicWin::repaintAllWin(int)
{
  for(  BasicWin *ptr=first ; ptr != NULL ; ptr = ptr->next )
    ptr->repaint();

  return CONTINUE;
}

BasicWin::Status BasicWin::runBasicWin(int key)
{
  static JumpList <BasicWin::Status (BasicWin::*)(int)> jumplist[] = {
    { KEY(F1)		, &makeHelpWindow },
    { KEY(F2)		, &makeProcessWindow },
    { KEY(F4)		, &quit },
    
    { KEY(ALT_1)	, &one_devide },
    { KEY(ALT_2)	, &two_devide },
    { KEY(ALT_3)	, &three_devide },
    { KEY(ALT_4)	, &four_devide },
    { KEY(ALT_5)	, &five_devide },
    { '['		, &dec_devide },
    { ']'		, &inc_devide },
    
    { '1'		, &one_window },
    { '0'		, &zero_window },
    { '\t'		, &next_window },
      
    { KEY(PAGEDOWN)	, &forward_page	},
    { CTRL('V')		, &forward_page	},
    { KEY(PAGEUP)	, &backward_page },
    { CTRL('Z')		, &backward_page },
    { KEY(DOWN)		, &forward },
    { 'j'		, &forward },
    { CTRL('N')		, &forward },
    { CTRL('X')		, &forward },
    { 'h'		, &gotoLeft },
    { CTRL('B')		, &gotoLeft },
    { KEY(LEFT)		, &gotoLeft },
    { 'l'		, &gotoRight },
    { CTRL('F')		, &gotoRight },
    { KEY(RIGHT)	, &gotoRight },
    { CTRL('L')		, &repaintAllWin },
    
    { KEY(UP)		, &backward },
    { 'k'		, &backward },
    { CTRL('P')		, &backward },
    { CTRL('E')		, &backward },
    { CTRL('[')		, &quit },
    { 'q'		, &quit },
    { 'Q'         	, &quit_without_ask },
    { KEY(CTRL_DOWN)	, &markAndForward },
    { ' '		, &markAndForward },
    { KEY(CTRL_UP)	, &backwardAndMark },
    { '/'		, &search_for_forward },
    { '?'		, &search_for_backward },
    { 'n'		, &search_next },
    { 'N'		, &search_reverse },
    { KEY(HOME)		, &goto_head },
    { '<'		, &goto_head },
    { '>'		, &goto_tail },
    { KEY(END)		, &goto_tail },
    { 'P'		, &makeProcessWindow },
    
    { '('		, &decPrintOffset },
    { ')'		, &incPrintOffset },
    { 'H'		, &decPrintOffset },
    { 'L'		, &incPrintOffset },

    { KEY(ALT_RIGHT)	, &incPrintOffset },
    { KEY(ALT_LEFT)	, &decPrintOffset },
    
    { CTRL('s')		, &incremental_search },
    { CTRL('r')		, &incremental_search },
    { 'A'		, &markAll },
    { 0 , 0 }
  };
  
  static KeyBind <BasicWin::Status (BasicWin::*)(int)> keyBind(jumplist);
  try{
    return (Status)keyBind( this , key );
  }catch(NoBound &e){
    return CONTINUE;
  }
}

void BasicWin::message(const char *fmt,...)
{
  wm_cursor( console_handle );
  wm_cvis( console_handle , 1 );
  wm_attrib( console_handle , color_message );
  v_attrib( color_message );

  va_list vp;
  va_start(vp,fmt);
  char buffer[1024];
  vsnprintf(buffer , sizeof(buffer) , fmt , vp);
  wm_puts( console_handle , buffer );
  va_end(vp);
  
  is_message_remained = true;
}

void BasicWin::clear_message()
{
  wmout << flush;

  wm_attrib( console_handle , color_message );
  v_attrib( color_message );
  wm_clear( console_handle );
  wm_gotoxy( console_handle , 0 , 0 );

  is_message_remained = false;
}

void BasicWin::addDeleteQueue()
{
  prev = NULL;
  next = garbage;
  if( garbage != 0 )
    garbage->prev = this;
  garbage = this;
}

void BasicWin::cleanUpWin()
{
  while( garbage != 0 ){
    BasicWin *tmp=garbage->next;
    delete garbage;
    garbage = tmp;
  }
}

void DirBasicWin::setBaseSortMethod(int x)
{
  sort_method = ((sort_method & ~AFile::Comparer::MASK) | x );
}
void DirBasicWin::setOptionSortMethod(int x)
{
  sort_method |= x;
}

int BasicWin::foreach( BasicWin::Foreach &command )
{
  Iterator *iter=top->dup();
  int nmarked=0;
  for(;;){
    if( iter->mark() ){
      ++nmarked;
      if( command( iter , true ) == false )
	return -nmarked;
    }
    if( ! iter->can_forward() )
      break;
    iter->forward();
  }
  if( nmarked <= 0 ){
    if( command( cursor , false ) == false )
      return 0;
    ++nmarked;
  }
  delete iter;
  return nmarked;
}

void BasicWin::refreshAll(void)
{
  for(  BasicWin *ptr=first ; ptr != NULL ; ptr = ptr->next )
    ptr->refresh();
}

/* �J�[�\���ŁA������̂����̈��I�ԁB
 *
 * list  �I����������̓������|�C���^�z��i�Ō�̗v�f�� NULL �ł��邱�Ɓj
 * pos   �J�[�\�����ŏ��ɉ��Ԗڂ̗v�f�̈ʒu�ɂ��邩�B
 * dem   �I����������̊Ԃɒu��������
 * tail	 �I����������̌�ɒu��������
 */
int BasicWin::selectWithCursor(  const char **list , int pos 
				, const char *dem , const char *tail )
{
  int x,y;
  
  wm_getxy( console_handle , &x , &y );
  int attr=wm_get_attrib(console_handle);

  for(;;){
    int i;
    for(i=0 ; list[i] != 0 ; ++i ){
      if( i==pos ){
	wm_attrib( console_handle , attr | 0x40 );
	wm_puts( console_handle , list[i] );
	wm_attrib( console_handle , attr );
      }else{
	wm_puts( console_handle , list[i] );
      }
      if( list[i+1] != 0  &&  dem != 0 )
	wm_puts( console_handle , dem );
    }
    if( tail != 0 )
      wm_puts( console_handle , tail );
    
    int key = readkey();
    switch( key ){
      
    case 'i':
    case '\n':
    case '\r':
      wm_putc(console_handle,'\n');
      return pos;

    case '\t':
    case ' ':
    case 'l':
    case CTRL('F'):
    case KEY(RIGHT):
      pos = (pos+1) % i;
      break;

    case KEY(BACKTAB):
    case 'h':
    case CTRL('B'):
    case KEY(LEFT):
      pos = (pos+i-1) % i;
      break;

    case 'q':
    case 'o':
    case '\x1B':
      wm_putc(console_handle,'\n');
      return -1;
    }
    wm_gotoxy(console_handle,x,y);
  }
}

int BasicWin::main(int message_line , int nlines )
{
  box_cursor_on();

  int bottom_line=message_line;

  console_handle = wm_create(  0 , message_line
			     , first->width-1 , message_line+nlines-1
			     , 0 , 0x00 , BasicWin::color_message );
  
  wmout.attach( console_handle );
  wmoutIsCout = false;
  
  wm_attrib( console_handle , BasicWin::color_message );
  wm_open( console_handle );
  
  bottom_handle = wm_create(  0 , message_line+nlines
			    , first->width-1 , message_line+nlines
			    , 0 , 0x00 , BasicWin::color_message );
  wm_attrib( bottom_handle , BasicWin::color_message );
  wm_open( bottom_handle );

  clear_message();

  wmout << "The `eff' "VER" 1998-2002 (c) HAYAMA,Kaoru";
  string doteff=Property::root["eff.doteff"].value();
  if( ! doteff.empty() )
    wmout << "\n  Config file `" << doteff << "' is loaded !";

  v_attrib( BasicWin::color_message );
  v_scroll(  0 , message_line+nlines
	   , first->width-1 , message_line+nlines+1
	   , 1 , V_SCROLL_CLEAR );
  
  is_message_remained = true;
  
  focus = first;
  focus->repaint();
  v_hidecursor();

  for(;;){
    if( focus != 0 )
      focus->printCursor();

    wmout << flush;

    if( ! is_message_remained ){
      if( focus != NULL && focus->cursor != NULL ){
	focus->cursor->putat(  0
			     , bottom_line
			     , focus->print_offset
			     , first->width*3);
      }else{
	clear_message();
      }
    }
    ::cursor_off();
    int key = readkey();
    
    if( focus != 0 )
      focus->printCursor();

    clear_message();

    /* �L�[�̍����ς� */
    if(   (unsigned)key < numof(extJumpList)
       && extJumpList[ key ] != NO_BOUND )
      key = extJumpList[ key ];

    if( Launcher::at( key ) != NULL ){
      if( focus->launcher( key ) == QUIT )
	break;
    }else if( focus->run(key) == QUIT || focus == NULL ){
      break;
    }

    cleanUpWin();
  }
  BasicWin *ptr=BasicWin::first;
  while( ptr != NULL ){
    BasicWin *nxt=ptr->next;
    delete ptr;
    ptr = nxt;
  }
  ptr = BasicWin::garbage;
  while( ptr != NULL ){
    BasicWin *nxt=ptr->next;
    delete ptr;
    ptr = nxt;
  }
  wm_exit();
  
  const char *pipe2nyaos=getenv("PIPE2NYAOS");
  if( pipe2nyaos != NULL ){
    HPIPE hp;
    unsigned long dummy;
    int rc=DosOpen( (unsigned const char *)pipe2nyaos
		   , &hp
		   , &dummy
		   , 0
		   , FILE_NORMAL
		   , OPEN_ACTION_FAIL_IF_NEW | OPEN_ACTION_OPEN_IF_EXISTS
		   , OPEN_ACCESS_WRITEONLY | OPEN_SHARE_DENYNONE
		   , NULL );
    if( rc == 0 ){
      char cmds[ FILENAME_MAX ];
      strcpy(cmds,"cd ");
      if( _getcwd2(cmds+3,sizeof(cmds)-3) != NULL ){
	// printf( "%s\n" , cmds );
	DosWrite( hp , cmds , strlen(cmds)+1 , &dummy );
      }
      DosClose(hp);
    }
  }
  return 0;
}


