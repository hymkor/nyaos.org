/* -*- c++ -*- */
#ifndef ARCHIVEWIN_H
#define ARCHIVEWIN_H

#include <cstring>
#include <string>
#include <cstdlib>

#include "afile.h"
#include "ziplist.h"
#include "basicwin.h"

class ArchiveWin : public BasicWin {
  class Cursor;

  ZipType *ziptype;
  string elltmpdir;
  
  class Node { friend class Cursor;
    Node *prev,*next;
    string name,info[3];
    int nInfo;
    bool mark;
    bool delmark;
  public:
    Node():prev(0),next(0),nInfo(0),mark(false),delmark(false){}

    Node( const string &n )
      : prev(0),next(0),name( n ),nInfo(0),mark(false),delmark(false){}

    Node( const Node &x ) // copy constructor.
      : prev(0),next(0),name(x.name),nInfo(x.nInfo),mark(x.mark)
	,delmark(x.delmark)
	{  info[0] = x.info[0];  info[1] = x.info[1];  info[2] = ""; }
    
    Node *combine( Node *x ){
      if( next )	next->prev = 0;
      if( x->prev )	x->prev->next = 0;
      next = x;
      x->prev = this;
      return this;
    }
    Node &operator << (const string &s){
      if( nInfo < numof(info)-1 )
	info[ nInfo++ ] = s;
      return *this;
    }
    const string &operator[](int n) const { return info[n]; }
    
    const char *getName() const { return name.empty() ? 0 : name.c_str(); }
    void setName(const string &nm ){ name = nm; }
    
    int getMark() const { return mark; }
    void setMark(bool x){ mark=x; }

    bool isDeleted() const { return delmark; }
    void setDelMark(bool x){ delmark = x ; }
    
    Node *getNext(){ return next; }
    Node *getPrev(){ return prev; }

  } *first;

  string path,name,title;

  const char *getTitle() const 
    { return title.empty() ? path.c_str() : title.c_str(); }
  void setTitle(const string &t){ title = t; }

  enum{
    PATHNAME_HAS_SPACES=1,
  };
  unsigned flag ;

  void hookOnOpen();
  class RestoreArchiveWin;
friend class RestoreArchiveWin;

public:
  ZipType *getType() const { return ziptype; }

  class Cursor : public BasicWin::Iterator {
    Node *node;
    ArchiveWin *parent;
  public:
    Cursor(Cursor *p) : node(p->node) , parent(p->parent){}
    Cursor(Node *p,ArchiveWin *a) : node(p) , parent(a){}
    virtual ~Cursor(){}

    int can_forward() const { return node->getNext() != 0; }
    int forward(){
      if( node->getNext() == 0 )
	return -1;
      node = node->getNext();
      ++n;
      return N();
    }
    int backward(){
      if( node->getPrev() == 0 )
	return -1;
      node = node->getPrev();
      --n;
      return N();
    }
    Iterator *dup() const { return new Cursor(*this); }
    void mark(int code){ node->setMark(code); }
    int mark() const { return node->getMark(); }
    int isDeleted() const { return node->isDeleted(); }
    void setDelMark(bool mark){ node->setDelMark(mark); }

    const char *getName() const { return node->getName(); }
    bool getLine(VBuffer &,int width);
    void set(const Iterator &it){
      const Cursor *x=dynamic_cast<const Cursor*>( &it );
      if( x ) node=x->node;
    }
  };

  struct Fail{};

  ArchiveWin(  const string &archive
	     , ZipType *
	     , const string &title
	     , RestoreWin *restoreWin
	     ) throw(Fail);
  ArchiveWin( const ArchiveWin *) throw( Fail );
  ~ArchiveWin();
  void execute();

  RestoreWin *saveMe();
  
  char titleLine(VBuffer &);
  BasicWin::Status run(int key);

  int getWidth() const { return width; }
  int go_elldir(AFile::DirSave *dirsave=0);

  int openArchiveRecursively();
  Status enter(int), pager(int) , open_object(int) , cmd_extract(bool,bool);
  Status yank(int) , cmd_markdel(int);
  const char *getOneLineInfo(Node *);

  static int main(int,int,int,int,const char *fname);

private:
  int  extract( Iterator *
	       , const string ZipType::*extractor=&ZipType::unpacker);
  int  extractMark( const string ZipType::*extractor=&ZipType::unpacker );
  void extractAll( const string ZipType::*extractor=&ZipType::unpacker );
  
public:
  static unsigned color_text , color_titlebar , color_titleline ;
  virtual const char *what() const { return "ARCHIVE"; }
};
#endif
