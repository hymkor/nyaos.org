// -*- c++ -*-

#ifndef PROWIN_H
#define PROWIN_H

#include <sys/video.h>
#include "basicwin.h"
#include "jobs.h"

class ProcessWindow : public BasicWin {
  class ProcessIterator; friend class ProcessIterator;
  Jobs jobs;

  BasicWin::Status runProcessWindow(int);
public:  

  class ProcessIterator : public BasicWin::Iterator { 
    ProcessWindow *parent;
  public:
    int can_forward() const { return n+1 < parent->jobs.N(); }
    int forward() { return N() < parent->jobs.N()-1 ? ++n : -1; }
    int backward() { return N() > 0 ? --n : -1 ; }
    Iterator *dup() const { return new ProcessIterator(*this); }
    void mark(int){}
    int mark() const { return 0; }
    const char *getName() const { return parent->jobs.getName(N()); }
    bool getLine( VBuffer & , int width );
    bool isOk() const { return true; }

    ProcessIterator(const ProcessIterator &p) : parent(p.parent) {}
    ProcessIterator(ProcessWindow &w) : parent(&w) {}
    virtual ~ProcessIterator() {}
    void set(const BasicWin::Iterator &it);
  };

  // void drawTitle();
  char titleLine(VBuffer &);
  Status run(int key){ return runProcessWindow(key); }

  ProcessWindow( BasicWin::RestoreWin *r);
  // ProcessWindow(int x,int y,int w,int h);
  ~ProcessWindow(){}

  struct RestoreProcessWin;
  RestoreWin *saveMe();
  
  ProcessIterator *getCursor()
    { return static_cast<ProcessIterator*>((Iterator*)cursor);}

  static int main(int x,int y,int w,int h);

  static unsigned color_normal , color_titlebar , color_titleline;
  const char *what() const { return "PROCESS"; }
};

#endif
