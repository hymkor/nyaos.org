#include <cctype>
#include <cstdio>
#include <sys/kbdscan.h>
#include <iostream>
#include <fstream>
#include <strstream>

#include "property.h"
#include "effetc.h"
#include "fileswin.h"
#include "VBuffer.h"
#include "textwin.h"

struct TextWin::RestoreTextWin : public BasicWin::RestoreWin {
  RestoreWin *prev;
public:
  RestoreTextWin( RestoreWin *r )
    : prev( r ? r->dup() : 0 ){}

  ~RestoreTextWin(){ delete prev; }

  BasicWin *restore(){
    BasicWin *tmp=new TextWin(prev);
    prev = 0;
    return tmp;
  }

  RestoreWin *dup()
    {  return new RestoreTextWin(prev);  }
};

BasicWin::RestoreWin *TextWin::saveMe()
{
  return new RestoreTextWin(getRestoreWin());
}

void TextWin::init( istream &ins )
{
  Node *last=0;
  char buffer[256];
  while( ins.good() && ins.getline(buffer,sizeof(buffer)) != NULL ){
    Node *tmp=new Node(buffer);
    if( last != NULL ){
      last->combine(tmp);
      last = tmp;
    }else{
      last = first = tmp;
    }
  }
  if( last == 0 || first == 0 )
    last = first = new Node("Can not find the helpfile.");

  top    = new Cursor(first,this);
  heaven = top->dup();
  earth  = top->dup();
  cursor = top->dup();
  helpfname = "-";
}


TextWin::TextWin( istream &ins , BasicWin::RestoreWin *r ) : BasicWin(r)
{
  init(ins);
}

TextWin::TextWin( BasicWin::RestoreWin *r ) : BasicWin(r)
{
  string help;
  
  if( ! (help=Property::root["eff.help.text"].value()).empty() ){
    // �w���v���A�v���p�e�B�[���璼�ځA�ǂݎ��.
    istrstream ins(help.c_str());
    init(ins);
  }else if( ! (help=Property::root["eff.help.file"].value()).empty() ){
    // �w���v���A�O���t�@�C������ǂݎ��.
    ifstream ins(help.c_str());
    init(ins);
  }else{
    istrstream ins("There are no help-text.");
    init(ins);
  }
}


#if 0
TextWin::TextWin( const string &textFile , BasicWin::RestoreWin *r )
     throw(TextWin::Fail) : BasicWin(r)
{
  FILE *fp=fopen(textFile.c_str(),"r");
  if( ! fp ){
    first = new Node("Can not find the helpfile.");
  }else{
    Node *last=0;
    char buffer[256];
    while( !feof(fp) && fgets(buffer,sizeof(buffer),fp) != NULL ){
      Node *tmp=new Node(buffer);
      if( last != NULL ){
	last->combine(tmp);
	last = tmp;
      }else{
	last = first = tmp;
      }
    }
    if( last == 0 || first == 0 ){
      last = first = new Node("Can not find the helpfile.");
    }
  }

  top    = new Cursor(first,this);
  heaven = top->dup();
  earth  = top->dup();
  cursor = top->dup();
  helpfname = textFile;
  return;
}
#endif

bool TextWin::Cursor::getLine(VBuffer &vbuf , int w )
{
  for( const char *sp=node->toChar().c_str() ; *sp != '\0' ; ){
    if( isKanji(*sp) ){
      vbuf << *sp++;
      vbuf << *sp++;
    }else if( *sp == '\\' ){
      if( *++sp == '\\' ){
	vbuf << '\\';
      }else{
	int color=0;
	for(int i=0 ;i<2 && isxdigit(*sp) ; i++){
	  color <<= 4;
	  if( isdigit(*sp) )
	    color |= (*sp-'0');
	  else if( islower(*sp) )
	    color |= (*sp-'a')+10;
	  else
	    color |= (*sp-'A')+10;
	  ++sp;
	}
	vbuf.color(color);
      }
    }else{
      vbuf << *sp++;
    }
  }
  return true;
}

char TextWin::titleLine(VBuffer &vbuf)
{
  vbuf << "\xFF\07-----\xFF\x70 Help View \xFF\x07";
  return '-';
}

TextWin::~TextWin()
{
  while( first ){
    Node *tmp=first->getNext();
    delete first;
    first = tmp;
  }
}

BasicWin::Status TextWin::run(int key)
{
  BasicWin *tmp=0;
  switch(key){
  default:
    return BasicWin::runBasicWin(key);

  case BIND_LEAVE:
  case BIND_CHG_HELP_VIEW:
  case KEY(F1):
  case 'o':
    try{
      BasicWin::RestoreWin *r=getRestoreWin();
      if( r==NULL )
	return zero_window(0);
      else
	replaceWin( r->restore() );
    }catch(...){
      message("Can not back (;_;)");
      delete tmp;
    }
    return CONTINUE;
  }
}
