/* -*- c++ -*- */
#ifndef ZIPLIST_H
#define ZIPLIST_H

#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <stack>

/* ���Ɍ^�B���ɂɊւ���X�y�b�N��ێ����� */
class ZipType{
  // ���ɂ̔��ʃL�[�B���ނ̏��ɂł��A�g���q�┻�ʖ@�͕�������.
  class Key {
    string suffix , keyword;
    int period , startAddress , endAddress;

    void count_period();
  public:
    Key( const string &s )
      : suffix(s) , startAddress(0) , endAddress(-1)
	{ count_period(); }
    Key( const string &s , const string &k , int st=0 , int ed=0 )
      : suffix(s) , keyword(k) , startAddress(st) , endAddress(ed)
	{ count_period(); }
    Key( const Key &k ) : suffix(k.suffix) , keyword(k.keyword)
      , startAddress(k.startAddress) , endAddress(k.endAddress)
	{ count_period(); }

    int belongTo( const string &fname , FILE *&fp );
  };
  int belongTo( const string &fname , FILE *&fp );
  
  vector <Key*> keys;
  static vector <ZipType*> zipTypeList;
public:
  /* ���ɂ̃v���p�e�B�[�͕ύX������Ƃ��� */
  string unpacker , junk_unpacker , lister , printer;
  string killer , header , tailer ;
  int islaunch , period , rootchar , linecount , fnamepos, isIndex ;
  
  struct Format {
    Format *next;
    virtual void paste( string & , string * )=0;
    Format() : next(0){}
    virtual ~Format(){}
  } *format;
  
  struct BetaText : public Format {
    string text;
    void paste( string & , string * );
    BetaText(const char *s) : text(s) {}
    BetaText(const string &s) : text(s) {}
    ~BetaText(){}
  };
  struct SubString : public Format {
    int start,end,line;
    void paste( string & , string * );
    SubString(int s,int e,int l=0) : start(s),end(e),line(l){}
    ~SubString(){}
  };

  ZipType() : unpacker("rem") , killer("rem") , islaunch(0) , period(1) 
    , rootchar(0) , linecount(1) , fnamepos(1) ,isIndex(0) , format(0) { }
  ZipType &operator = ( const ZipType &z );
  ZipType( const ZipType &z ){ *this = z; }
  ~ZipType();

  void appendKey( const string &s )
    { keys.push_back( new Key(s) ); }
  void appendKey( const string &s , const string &k , int st=0 , int ed=0 )
    { keys.push_back( new Key(s,k,st,ed) ); }
  
  static ZipType *search( const char *fname );
  static ZipType *get1st(){ return zipTypeList[0]; }
  void   regist(){ zipTypeList.push_back( this ); }
};

/* XXXX YYYY zzz1 zzz2 ... �Ƃ����R�}���h����������N���X
 *	XXXX �R�}���h��(�����Ă� zip �Ƃ� lha )
 *	YYYY �Œ������(�����Ă� ���ɖ�)
 *	ZZZn �ό�����(�����Ă� ���ɂɊ܂܂��t�@�C����)
 * �ȏ�� 100�����ȓ��Ɏ��܂�悤�ȃT�C�Y�ō쐬����B
 */
class ZipCommand {
  enum{ max = 240 };
  int done , n;
  string head , tail , files;
  stack <string> cmdslist;

public:
  ZipCommand( const string &format , const string &arcfn );
  operator const void*() const
    { return head.length()+tail.length() < max ? this : 0 ; }
  bool operator !() const
    { return head.length()+tail.length() >= max ; }
  
  void append( const string &argn );  
  int execute();
  int getCount() const { return done; }

  static void make1cmd( const string &format , const string &arcfn
		       , string &result );
  static void make1cmd( const string &format , const string &arcfn
		       ,const string &fn1 , string &result );
  static int execute( const string &format , const string &arcfn );
  static int execute( const string &format , const string &arcfn
		     , const string &fn1 );
  static FILE *popen( const string &format , const string &arcfn );
};


#endif
