#include <cstring>
#include <vector>

#include <io.h>
#include <sys/kbdscan.h>

#include "icanna.h"
#include "effcfg.h"
#include "fileswin.h"
#include "arcwin.h"
#include "VBuffer.h"
#include "effetc.h"
#include "deltree.h"
#include <os2.h>

#define DBG1(x) /**/

unsigned ArchiveWin::color_titleline = 0x0E;
unsigned ArchiveWin::color_titlebar  = 0xE0;
unsigned ArchiveWin::color_text      = 0x0F;

struct ArchiveWin::RestoreArchiveWin : public BasicWin::RestoreWin {
private:
  RestoreWin *prev2; /* ����ɉߋ�������ꍇ�ׂ̈Ɂc */
  string arcfile , title , elltmpdir;
  ZipType *ziptype;
public:
  RestoreArchiveWin(  const string &a
		    , ZipType *z
		    , const string &t
		    , const string &eld
		    , RestoreWin *p=0)
    : prev2(p ? p->dup():0) , arcfile(a) , title(t) 
      , elltmpdir(eld) , ziptype(z){}
  
  ~RestoreArchiveWin(){ delete prev2; }  
  
  BasicWin *restore(){
    ArchiveWin *tmp=new ArchiveWin(arcfile,ziptype,title,prev2);
    tmp->elltmpdir = this->elltmpdir;
    prev2 = 0;
    return tmp;
  }
  
  RestoreWin *dup(){
    return new RestoreArchiveWin(arcfile,ziptype,title,elltmpdir,prev2);
  }
};

BasicWin::RestoreWin *ArchiveWin::saveMe()
{
  return new RestoreArchiveWin(  path , ziptype , title , elltmpdir
			       , getRestoreWin() );
}

void ArchiveWin::hookOnOpen()
{
  setColumn( 1 );
  repaintAllWin(0);
}

class GarbageTempDirList {
  stack <string> tmpdirs;
public:
  void regist( const string &dirname )
    { tmpdirs.push( dirname ); }

  ~GarbageTempDirList(){
    /* ���܂œo�^���ꂽ�ꎞ�f�B���N�g����S�č폜����B  */
    for( ; ! tmpdirs.empty() ; tmpdirs.pop() ){
      AFile::DirSave dirsave( tmpdirs.top() );
      if( dirsave ){
	chdir( ".." );
	deltree( tmpdirs.top().c_str() );
      }
    }
  }
};
static GarbageTempDirList garbageTempDirList;

/* ���ɕ\���E�C���h�E�̃N���X��(�R�s�[)�R���X�g���N�^
 */
ArchiveWin::ArchiveWin( const ArchiveWin *that ) throw( ArchiveWin::Fail ) 
: BasicWin( that->getRestoreWin() ? that->getRestoreWin()->dup() : 0 )
     , first(0) , path(that->path) , name(_getname(path.c_str()) )
     , title(that->title) , flag(that->flag)
{
  ziptype = that->ziptype;
  
  setColumn(1);

  first = new Node(*that->first);
  if( first == NULL )
    throw Fail();

  Node *last=first;
  for(  Node *from=that->first->getNext() 
      ; from != NULL 
      ; from=from->getNext() ){

    Node *tmp=new Node(*from);
    if( tmp == 0 )
      throw Fail();
    last->combine(tmp);
    last = tmp;
  }
  top    = new Cursor(first,this);
  heaven = top->dup();
  cursor = heaven->dup();
  earth  = heaven->dup();
}

/* ���ɕ\���E�C���h�E �N���X�̃R���X�g���N�^
 *	archiveName - ���ɖ�
 *	ztype - ���ɂ̃^�C�v
 *	title_ - ���ɂ̃^�C�g��
 *	r - �{�E�C���h�E�̑O�ɕ\������Ă����E�C���h�E���Č�����I�u�W�F�N�g
 */
ArchiveWin::ArchiveWin(  const string &archiveName
		       , ZipType *ztype
		       , const string &ttl
		       , RestoreWin *r=0
		       ) throw( ArchiveWin::Fail )
: BasicWin(r) , ziptype(ztype) , first(0) , path(archiveName)
     , name(_getname(path.c_str()))
     , title(ttl.empty() ? archiveName : ttl) , flag(0)
{
  FILE *pp=ZipCommand::popen( ztype->lister , archiveName );
  if( pp == NULL )
    throw Fail();

  char buffer[512];
  try{
    /* �w�b�_��������폜���� */
    if( ! ztype->header.empty() ){
      do{
	if( fgets(buffer,sizeof(buffer),pp) == NULL ){
	  wmout << "\nNo header" << flush;
	  throw Fail();
	}
      }while( strstr(buffer,ztype->header.c_str() )==0 );
    }
    
    Node *last=NULL; 
    int i=0;
    
    while( !feof(pp) &&  fgets(buffer,sizeof(buffer),pp) != NULL ){
      if(    ! ztype->tailer.empty()
	 &&  strstr(buffer,ztype->tailer.c_str()) != NULL )
	break;

      if( i==0 ){
	Node *tmp = new Node;
	if( tmp == NULL ) 
	  throw Fail();
	if( first == NULL )
	  first = tmp;
	else
	  last->combine(tmp);
	last = tmp;
      }
      *last << buffer;

      if( i==0 ){
	int ntokens=0;
	char *tokens[32];
	
	char *token=strtok(buffer," \t\n\r");
	while( token != NULL  &&  ntokens < numof(tokens) ){
	  tokens[ ntokens++ ] = token;
	  token=strtok(NULL," \t\n\r");
	}
	
	if( ztype->fnamepos == 0 )
	  last->setName( tokens[ 0 ] );
	else if( ztype->fnamepos > 0 && ztype->fnamepos <= ntokens )
	  last->setName( tokens[ ztype->fnamepos-1 ] );
	else if( ztype->fnamepos < 0 && ntokens+ztype->fnamepos >= 0 )
	  last->setName( tokens[ ntokens+ztype->fnamepos ] );
      }

      if( ztype->linecount > 1 )
	i = (i+1) % ztype->linecount;
    }
  }catch(...){
    pclose(pp);
    throw;
  }
  pclose(pp);

  if( first == NULL ){
    wmout << "\nNo lists" << flush;
    throw Fail();
  }

  top    = new Cursor(first,this);
  heaven = top->dup();
  cursor = heaven->dup();
  earth  = heaven->dup();
}

BasicWin::Status ArchiveWin::cmd_markdel(int key)
{
  int n=0;
  Cursor *csr=dynamic_cast<Cursor*>((Iterator*)heaven );
  if( csr != NULL  &&  (csr=dynamic_cast<Cursor*>(csr->dup())) != NULL ){
    do{
      if( csr->mark() ){
	csr->setDelMark( ! csr->isDeleted() );
	++n;
      }
    }while( csr->forward() >= 0 );
    delete csr;
  }
  if( n > 0 ){
    repaint();
  }else if( cursor && (csr=dynamic_cast<Cursor*>((Iterator*)cursor ) ) != NULL ){
    csr->setDelMark( ! csr->isDeleted() );
    repaint_cursor_line();
    forward(key);
  }
  return CONTINUE;
}

/*
 * substring �\��
 */
bool ArchiveWin::Cursor::getLine( VBuffer &vbuf , int width )
{
  if( node == NULL )
    return false;
  
  vbuf.color( ArchiveWin::color_text );
  ZipType *zt=parent->getType();
  vbuf << ( node->getMark() ? '*' : ' ');
  vbuf << ( node->isDeleted() ? 'D' : ' ');
  
  if( zt->format != 0 ){
    /* LZH �ȂǁA�P�t�@�C���̓��e���Q�s�ɂ킽��ꍇ�̂��߂ɁA
     * �s���e��ҏW���āA�P�s�ɂ���B
     */
    string sbuf;
    for(  ZipType::Format *ptr = zt->format
	; ptr != NULL
	; ptr=ptr->next ){
      
      ptr->paste( sbuf , node->info );
    }
    vbuf << sbuf.c_str();
  }else{
    /* �s���e��ҏW����K�v�������ꍇ�A
     * �P�s�ڂ�����W�J����B
     */
    vbuf << (*node)[0].c_str() ;
    if( ! (*node)[1].empty() ){
      for(  int i=(*node)[0].length()
	  ; i < parent->getWidth()
	  ; ++i ){
	vbuf << char(' ');
      }
      vbuf << (*node)[1].c_str();
    }
  }
  return true;
}


char ArchiveWin::titleLine(VBuffer &vbuf)
{
  vbuf.color( color_titleline )
    << horizon_char << horizon_char << horizon_char
      << horizon_char << horizon_char ;

  vbuf.color( color_titlebar  ) << title.c_str() << ' ';
  vbuf.color( color_titleline );
  return horizon_char;
}

/* �폜�}�[�N�̂����t�@�C�������ɂ��珜�� */
void ArchiveWin::execute()
{
  ZipCommand zipCommand( ziptype->killer , path );
  for( Node *csr=first ; csr ; csr=csr->getNext() ){
    if( zipCommand && csr->isDeleted() ){
      int ch=0;
      wmout << "delete " << csr->getName() ;
      wmout << " in " << path << " : Y)es, N)o ? " << flush;
      wmout << char(ch=readkey()) << endl;
      
      if( ch == 'y' )
	zipCommand.append( csr->getName() );
    }
  }
  wmout << endl;
  zipCommand.execute();
  repaintAllWin(0);
}


ArchiveWin::~ArchiveWin()
{
  execute();
  while( first != 0 ){
    Node *csr=first->getNext();
    delete first;
    first = csr;
  }
}

BasicWin::Status ArchiveWin::pager(int)
{
  string cmdline;
  ZipCommand::make1cmd( ziptype->printer, path, cursor->getName(), cmdline );
  ThePager::lookOutput( cmdline , title + " - " + cursor->getName() );
  repaintAllWin(0);
  
  return CONTINUE;
}

int ArchiveWin::go_elldir(AFile::DirSave *dirsave=0)
{
  if( elltmpdir.empty() ) {
    elltmpdir = tempnam("C:\\", "EFF");
    if( mkdir(elltmpdir.c_str(), 0L) )
      return -1;
    
    garbageTempDirList.regist( elltmpdir );
  }
  if( dirsave == 0 ){
    _chdir2(elltmpdir.c_str() );
  }else{
    if( dirsave->pushd( elltmpdir.c_str() ) != 0 )
      return -1;
  }
  return 0;
}


int ArchiveWin::extractMark( const string ZipType::*extr )
{
  ZipCommand zipCommand(ziptype->*extr,path);
  if( !zipCommand )
    return -1;

  for( Node *ptr=first ; ptr != 0 ; ptr=ptr->getNext() ){
    if( ptr->getMark() )
      zipCommand.append( ptr->getName() );
  }
  zipCommand.execute();
  return zipCommand.getCount();
}

void ArchiveWin::extractAll(const string ZipType::*extractor)
{
  ZipCommand zipCommand( ziptype->*extractor , path );
  zipCommand.append(" "); // dummy
  zipCommand.execute();
}

/* �w��s�̃t�@�C����W�J����(�f�B���N�g���t��)
 */
int ArchiveWin::extract(  BasicWin::Iterator *p_cursor
			, const string ZipType::*eer)
{
  if( (ziptype->*eer).empty() ){
    wmout << '\n' << cursor->getName() ;
    wmout << ": cannot extract such a method.";
    return -1;
  }
  Cursor *cursor = dynamic_cast<Cursor*>( p_cursor );
  if(   cursor == NULL ){
    wmout << '\n' << cursor->getName() << ": Can not extract archive.";
    return -1;
  }
  if( access( cursor->getName() , 0 ) != 0 ){
    // ���݂��Ȃ��������W�J����.
    ZipCommand::execute( ziptype->*eer , path , cursor->getName() );
  }
  return 0;
}



BasicWin::Status ArchiveWin::open_object(int)
{
  AFile::DirSave dirsave;
  
  if( go_elldir(&dirsave) == 0 ){
    extract( cursor );

    string path , path1=AFile::makepath(elltmpdir,cursor->getName());
    AFile::f2b( path1 , path );
    
    HOBJECT hObject=WinQueryObject( (PSZ) path.c_str() );
    WinSetObjectData( hObject , (PCSZ)"OPEN=DEFAULT" );
  }
  return CONTINUE;

}

/* �J�[�\���̎����A�[�J�C�u�t�@�C�����ċA�I�ɊJ��
 * return
 *	 0 : �ċA�I�ɊJ����
 *	-1 : �J���Ȃ�����(�܂�A�A�[�J�C�u�t�@�C���ł͂Ȃ�����)
 *	-2 : �ʂ̃G���[
 */
int ArchiveWin::openArchiveRecursively()
{
  /* �A�[�J�C�u�t�@�C�����ǂ����A�ƍ� */
  ZipType *matchType=ZipType::search( cursor->getName() );
  if( matchType == NULL )
    return -1;

  ArchiveWin *tmp=0;
  RestoreWin *preWin=0;

  string path;
  char newTitle[ FILENAME_MAX ];

  AFile::DirSave dirsave;
  if( go_elldir(&dirsave) != 0 )
    return -2;

  /* �W�J */
  extract( cursor );

  path=AFile::makepath( elltmpdir , cursor->getName() );
    
  snprintf(  newTitle,sizeof(newTitle)
	   , "%s - %s" , getTitle() , cursor->getName() );
    
  /* �p�X���̍쐬�E���݂̃E�C���h�E�̕ۑ��E�V�E�C���h�E�̍쐬��
   * �S�Đ���������A����I�� */
  if(    ! path.empty()
     && (preWin=saveMe()) != NULL
     && (tmp=new ArchiveWin( path ,matchType ,newTitle, preWin )) != NULL){
    replaceWin( tmp );
    return 0; /* ����I���I */
  }
  /* �A�[�J�C�u�t�@�C����W�J�ł��Ȃ��������̏��� */
  
  delete preWin;
  delete tmp;
  
  char tmpdir[ FILENAME_MAX ];
  _getcwd2(tmpdir,sizeof(tmpdir));
  wmout << "\nCannot open archive file at " << tmpdir << endl;
  return -1;
}

BasicWin::Status ArchiveWin::enter(int key)
{
  /* �܂��A�J�����g�t�@�C�����A�A�[�J�C�u�t�@�C���Ƃ��ăI�[�v����
   * ���݂�B����������A����ŏI�� */
  if( openArchiveRecursively() == 0 )
    return CONTINUE;

  /* ��ʂ̊֘A�t�����ꂽ�t�@�C�����ǂ������ƍ� */
  SuffixList *suffixType=SuffixList::find( _getext2(cursor->getName() ) );
  if( suffixType == NULL )
    return pager(key);

  AFile::DirSave dirsave;
  
  switch( suffixType->getType() ){
  case SuffixList::PAGER:
    if( suffixType->getProcedure().empty() ){
      /* ���Ƀt�B���^�[�͖����ꍇ */
      return pager(key);
    }else{
      string cmdline;
      int bits=makeLaunchBase2(suffixType->getProcedure(),true,cmdline );
      if( bits == -1 )
	return CONTINUE;

      string newTitle;
      if( title.empty() ){
	newTitle  = cursor->getName();
      }else{
	newTitle  = title;
	newTitle += " - ";
	newTitle += cursor->getName();
      }
      
      if( bits & USED_P ){ /* �t�B���^���W������ Ok �̎� */
	string cmdline2;
	ZipCommand::make1cmd( ziptype->printer , path , cmdline2 );
	cmdline2 += " | ";
	cmdline2 += cmdline;
	ThePager::lookOutput( cmdline2 , newTitle );

      }else if( go_elldir(&dirsave)==0 ){
	/* �W�����͂���󂯂Ƃ��t�B���^�[�Ƃ͌���Ȃ��̂ŁA
	 * ��x�A�W�J����
	 */
	extract( cursor );
	
	ThePager::lookOutput( cmdline , newTitle );
	repaintAllWin(0);
      }
    }
    break;

  case SuffixList::EXEC:
    if( go_elldir(&dirsave)==0 ){
      string cmdline;
      if( makeLaunchBase2(suffixType->getProcedure(),false,cmdline ) == -1 )
	return CONTINUE;

      extract( cursor );
      
      ::box_cursor_on();
      system( cmdline.c_str() );
      cursor_off();
      repaintAllWin(0);
    }
    break;

  case SuffixList::REXX:
    if( go_elldir(&dirsave)==0 ){
      extract( cursor );
      
      suffixType->run( cursor->getName() );
      repaintAllWin(0);
    }
    return CONTINUE;

  case SuffixList::OPEN:
    return open_object(key);
    break;
    
  default:
    pager(key);
    break;
  }
  return CONTINUE;
}

/* �W�J�R�}���h 'e'
 *	withDir - true:�f�B���N�g���t , false:�f�B���N�g������
 *	all - true:�S�t�@�C�� , false:�w��t�@�C���̂�
 * return
 *	��� CONTINUE
 */
BasicWin::Status ArchiveWin::cmd_extract(bool withDir , bool all )
{
  const char *todir=input_directory(  withDir
				    ? "extract (with path) to :"
				    : "extract (junk path) to :" );
  if( todir == NULL )
    return CONTINUE;

  AFile::DirSave dirsave;
  if( todir[0] != '\0' ){
    if( todir[0] == '~' && (todir[1] == '/' || todir[1] == '\\' ) ){
      const char *home=getenv("HOME");
      if( home != NULL ){
	if( dirsave.pushd( home ) != 0 ){
	  char c;
	  wmout << home << " does not exist. mkdir ? Y)es N)o :" << flush;
	  wmout << (c=readkey()) << endl;
	  if( c == 'y' )
	    mkdir( home , 0777 );
	  else
	    return CONTINUE;
	}
	dirsave.pushd( todir+2 );
      }else{
	dirsave.pushd( todir );
      }
    }else{
      dirsave.pushd( todir );
    }
    if( ! dirsave ){
      char c;
      wmout << todir << " does not exist. mkdir ? Y)yes N)o :" << flush;
      wmout << (c=readkey()) << endl;
      if( c == 'y' )
	mkdir( todir , 0777 );
      else
	return CONTINUE;
    }
  }
  /* withDir �̓��e�ɏ]���āA�W�J�R�}���h��I������ */

  string ZipType::*extractor
    = (  withDir
       ? &ZipType::unpacker
       : &ZipType::junk_unpacker );

  if( all )
    extractAll( extractor );
  else if( extractMark( extractor ) == 0 )
    extract( cursor , extractor );

  refreshAll();
  return CONTINUE;
}

class ZippedCopiedObject : public PastableObject {
  ZipCommand zipCommand;
public:
  ZippedCopiedObject(  const string &format , const string &arcfn )
    : zipCommand(format,arcfn){}

  void append( const string &fn ){ zipCommand.append(fn); }
  
  int paste( const char *todir , int &nsuccess , int &nfailure ){
    AFile::DirSave dirsave(todir);
    if( dirsave ){
      zipCommand.execute();
      nsuccess += zipCommand.getCount();
      return 0;
    }else{
      nfailure += zipCommand.getCount();
      return -1;
    }
  };
  const char *whatToDo(){  return "extract"; }
};

BasicWin::Status ArchiveWin::yank(int key)
{
  if( ziptype->junk_unpacker.empty() ){
    wmout << "\ncannot yank this type archive." << flush;
    return CONTINUE;
  }
  ZippedCopiedObject *zco
    = new ZippedCopiedObject( ziptype->junk_unpacker , path );
  int n=0;
  for( Node *ptr=first ; ptr != 0 ; ptr=ptr->getNext() ){
    if( ptr->getMark() ){
      zco->append( ptr->getName() );
      ++n;
    }
  }
  if( n <= 0 ){
    zco->append( cursor->getName() );
    ++n;
  }
  PastableObject::push( zco );

  wmout << '\n' << n << " files registed to extract.";
  return CONTINUE;
}

BasicWin::Status ArchiveWin::run(int key)
{
  BasicWin *tmp=0;

  switch( key ){
  default:
    return this->BasicWin::runBasicWin(key);

  case 'd':
    return cmd_markdel(key);
    
  case BIND_EXTRACT_ALL:
  case 'E':
    return cmd_extract(true,true); /* �f�B���N�g���t�E�S�� */

  case BIND_EXTRACT:
  case 'e':
    return cmd_extract(true,false);/* �f�B���N�g���t�E���� */

  case BIND_COPY:
  case 'c':
    return cmd_extract(false,false);/* �f�B���N�g�������E���� */

  case BIND_PASTE:
  case CTRL('c'):
  case KEY(CTRL_INS):
    return yank(0);

  case BIND_PAGER:
  case 'v':
    return this->pager(key);

  case BIND_OPEN_OBJECT:
  case 'O':
    return this->open_object(key);

  case BIND_ENTER:
  case 'i':
  case '\r':
  case '\n':
    return this->enter(key);

  case BIND_VIEW_TWO:
  case '2':
    try{
      if( forkWin( tmp=new ArchiveWin(this) ) != 0 ){
	wmout << "\nCan not make a new window" << endl;
	delete tmp;
      }
    }catch(...){
      wmout << "\nCan not make a new window" << endl;
      delete tmp;
    }
    return CONTINUE;

  case BIND_LEAVE:
  case '\b':
  case 'o':
  case '\x1B':
    if( restoreWin == NULL ){
      return BasicWin::quit(0);
    }
    try{
      replaceWin( tmp=(restoreWin->restore()) , name.c_str() );
    }catch(...){
      wmout << "\nCan not open a new window" << flush;
      delete tmp;
    }
    return CONTINUE;
  };

}

int ArchiveWin::main(int x,int y,int w,int h,const char *filename)
{
  ArchiveWin *tmp=0;

  ZipType *matchType = ZipType::search( filename );
  if( matchType ){
    try{
      char path[ FILENAME_MAX ];
      _fullpath( path , filename , sizeof(path) );
      ScrnSave scrnsave;
      
      if( (tmp=new ArchiveWin(path,matchType,path,0)) != 0 ){
	tmp->open(x,y,w,h-message_lines-1);
	return BasicWin::main( y+h-message_lines-1 , message_lines );
      }
    }catch( ArchiveWin::Fail ){
      ;
    }
  }
  return -3776;
}
