#include <cctype>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cstdarg>
#include <process.h>
#include <io.h>
#include <algorithm>
#include <sys/kbdscan.h>
#include <fstream>
#include <strstream>

#include "afile.h"
#include "startup.h"
#include "tokenizer.h"
#include "effetc.h"
#include "effcfg.h"
#include "fileswin.h"
#include "lesz.h"
#include "leszbuf.h"
#include "ziplist.h"
#include "wminput.h"
#include "property.h"

inline int system2( const string &s )
{  return system( s.c_str() );  }

inline int access2( const string &s )
{  return access( s.c_str() , 0 ); }

inline void toLower( string &s )
{  transform( s.begin() , s.end() , s.begin() , tolower );  }

/* ~/ �� @/ �� $HOME ���֕ϊ�����.
 */
static string explodeHome( const string &path )
{
  static const char *home=getenv("HOME");
  if( home != NULL ){
    if( path[0] == '~' ){
      // �u/�v�� path.substr(1)�Ɋ܂܂��.
      return string(home) += path.substr(1);
    }
  }
  if( path[0] == '@' ){
    char progname[ FILENAME_MAX ];
    if( _execname( progname , sizeof(progname) )==0 ){
      const char *tail=_getname(progname);
      // �u/�v�� ���ӂɊ܂܂��.
      return string( progname , tail-progname ) += path.substr(2);
    }
  }
  return path;
}

int Launcher::init()
{
  for(int i=0;i<numof(commands);i++)
    commands[ i ] = 0;
  return 0;
}

void Launcher::term(int)
{
  for(int i=0;i<numof(commands);i++)
    delete commands[i];
}

static StartUpCode startUp( &Launcher::init , &Launcher::term );
Launcher *Launcher::commands[];

int ThePager::lookFile( const string &fname )
{
  string pager=programName();
  if( pager.empty() ){
    lesz_file( fname.c_str() );
  }else{
    ScrnSave scrnsave;
    spawnlp(  P_WAIT
	    , pager.c_str()
	    , pager.c_str()
	    , fname.c_str()
	    , 0 );
  }
  return 0;
}
int ThePager::lookOutput( const string &cmdline , const string &title )
{
  string pager=programName();
  if( pager.empty() ){
    lesz_pipe( cmdline.c_str() , title.c_str() );
  }else{
    ScrnSave scrnsave;
    string cmdline2=cmdline;
    cmdline2 += " | ";
    cmdline2 += pager;
    system2( cmdline2 );
  }
  return 0;
}
int ThePager::lookStdin( const string &title )
{
  string pager=programName();
  if( pager.empty() ){
    return lesz_stdin( title.c_str() );
  }else{
    return system2( pager );
  }
}

void SuffixList::setSuffix( const string &suffix )
{
  string s=suffix;
  if( s.length() > 0 && s[0] != '.' )
    s.insert(0,".");

  toLower( s );
  suffixes.push_back( s );
}

vector <SuffixList*> SuffixList::table;
map <string,SuffixList *> SuffixList::index;

/* �֘A�t�����ꂽ�g���q�̎d�l����������B
 *	suffix �g���q(�s���I�h����)
 * return
 *	�Y������ SuffixList �̃C���X�^���X�ւ̃|�C���^
 */
SuffixList *SuffixList::find(const string &suffix)
{
  string lower=suffix;
  toLower( lower );

  map<string,SuffixList*>::iterator result=index.find(lower);
  if( result == index.end() )
    return NULL;
  else
    return result->second;
}

void SuffixList::regist()
{
  // �����C���f�b�N�X�̍쐬.
  for( unsigned i=0 ; i < suffixes.size() ; i++ )
    index[ suffixes[i] ] = this;

  // �e�[�u���ւ̓o�^.
  if( ! isRegisted ){
    table.push_back( this );
    isRegisted = true;
  }
}

SuffixList::~SuffixList()
{
  for( unsigned i=0 ; i < suffixes.size() ; i++ )
    index[ suffixes[i] ] = 0;
  
  if( isRegisted ){
    for( unsigned i=0; i < table.size() ; i++ )
      if( table[i] == this )
	table[i] = NULL;
  }
}


static int cfg_print(Tokenizer &tzer,ostream &)
{
  // Property &prop=Property::root[ "eff.directory.print" ];
  Property &prop=Property::root[ "eff.directory" ];

  while( tzer.passSpace() , *tzer != ';' ){
    if( *tzer == '1' || *tzer == '2' || *tzer == '4' ){
      BasicWin::default_ndevides = (*tzer - '0');
      ++tzer;
    }else{
      bool flag=true;
      if( *tzer=='+' ){
	++tzer;
      }else if( *tzer=='-' ){
	++tzer;
	flag = false;
      }
      
      switch( *tzer ){
      case 'c': /* �R�����g��\������ */
	prop["comments"] = (flag ? "true" : "false");
	break;
	
      case 'h': /* �B���t�@�C����\������ */
	prop["hidden"] = (flag ? "true" : "false");
	break;
	
      case 'l': /* .LONGNAME ���t�@�C�����ʒu�ɕ\������ */
	prop["longname"] = (flag ? "true" : "false");
	break;
	
      case 'w': /* ���b�Z�[�W�E�C���h�E�̏��� */
	BasicWin::is_message_remained = flag;
	break;
	
      case 'p': /* �y�[�W���ŋL����\������ */
	Book::crlf_arrow_mode = flag;
	break;
	
      default:
	throw Tokenizer::UnexpectedChar(tzer);
      }
      ++tzer;
    }
  }
  return 0;
}

/**** �ucanna�v�ݒ� ****/
static int cfg_canna( Tokenizer &tzer ,ostream &)
{

  while( tzer.passSpace() , *tzer != ';' ){
    switch( *tzer ){
    case '1': /* canna.dll �𒼂��Ƀ��[�h���� */
      // iCanna::summonCanna();
      Property::root[ "canna.whenload" ] = "startup";
      break;
      
    case '0': /* ����Ȃ���؎g��Ȃ��Bcanna ���������̂Ƃ��� */
      // iCanna::sealCanna();
      Property::root[ "canna.whenload" ] = "none";
      break;
      
    case '2': /* ���͉������Ȃ��̂�` */
      break;
      
    default:
      throw Tokenizer::UnexpectedChar(tzer);
    }
    ++tzer;
  }
  return 0;
}


/**** �usort�v�R�}���h ****/
static int cfg_sort( Tokenizer &tzer , ostream &)
{
  while( tzer.passSpace() , *tzer != ';' ){
    switch( *tzer ){
    case '-': /* �\�[�g���Ȃ� */ 
      DirBasicWin::setBaseSortMethod( AFile::Comparer::UNSORT );
      break;
    case 'n': /* ���O�Ń\�[�g */
      DirBasicWin::setBaseSortMethod( AFile::Comparer::NAME );
      break;
    case 't': /* �����\�[�g */
      DirBasicWin::setBaseSortMethod( AFile::Comparer::MODIFICATION_TIME );
      break;
    case 'x': /* �g���q�\�[�g */
      DirBasicWin::setBaseSortMethod( AFile::Comparer::SUFFIX );
      break;
    case 'i': /* �啶���������𖳎����ă\�[�g */
      DirBasicWin::setBaseSortMethod( AFile::Comparer::NAME_IGNORE );
      break;
    case 'd': /* �f�B���N�g����擪�ɂ��� */
      DirBasicWin::setOptionSortMethod( AFile::Comparer::DIRTOP );
      break;
    case 'r': /* �t���ɂ��� */
      DirBasicWin::setOptionSortMethod( AFile::Comparer::REVERSE );
      break;
    default:
      throw Tokenizer::UnexpectedChar(tzer);
    }
    ++tzer;
  }
  return 0;
}

static int setprops( Tokenizer &tzer , const char *name )
{
  string value;
  tzer.passSpace();
  tzer.readQuoted( value );
  Property::root[ name ] = value;
  return 0;
}

static int cfg_helpfile( Tokenizer &tzer , ostream & )
{  return setprops( tzer , "eff.help" ); }

/**** �ueditor�v�R�}���h ****/
static int cfg_editor(Tokenizer &tzer,ostream &)
{  return setprops( tzer , "eff.editor" );  }

/***** �upager�v�R�}���h *****/
static int cfg_pager(Tokenizer &tzer,ostream &)
{  return setprops( tzer , "eff.pager" );  }


/***** �ukey�v�R�}���h ******/
/* ALTKEY �A���t�@�x�b�g�ꕶ�� "�R�}���h" */
static int cfg_altkey(Tokenizer &tzer,ostream &)
{
  const static int scancode[]={
    KEY(ALT_SPACE),
    KEY(ALT_A),KEY(ALT_B),KEY(ALT_C),KEY(ALT_D),KEY(ALT_E),KEY(ALT_F),
    KEY(ALT_G),KEY(ALT_H),KEY(ALT_I),KEY(ALT_J),KEY(ALT_K),KEY(ALT_L),
    KEY(ALT_M),KEY(ALT_N),KEY(ALT_O),KEY(ALT_P),KEY(ALT_Q),KEY(ALT_R),
    KEY(ALT_S),KEY(ALT_T),KEY(ALT_U),KEY(ALT_V),KEY(ALT_W),KEY(ALT_X),
    KEY(ALT_Y),KEY(ALT_Z),
  };
  /* �A���t�@�x�b�g�P������ǂݎ�� */
  string alphabet;
  tzer.readQuoted(alphabet);

  int code=alphabet[0] & 0x1F;
  if( code >= numof(scancode) )
    return 0;
  int key=scancode[ code ];

  /* �R�}���h����ǂݎ�� */
  string cmds;
  tzer.readQuoted( cmds );
  Launcher *tmp=new CommandLauncher( cmds );
  tmp->registAt( key );
  
  return 0;
}

/******** �uext�v�R�}���h ********/
static int cfg_ext(Tokenizer &tzer,ostream &)
{
  vector<string> suffixes;
  for(;;){
    string suffix;
    tzer.readQuoted( suffix );
    toLower( suffix );
    suffixes.push_back( suffix );
    
    tzer.passSpace();
    if( *tzer != ',' )
      break;
    ++tzer;
  }
  string ident;
  tzer.readIdentifier(ident);
  
  SuffixList *tmp=0;
  
  if( ident.compare("pager")==0 ){
    /* �y�[�W���N�����w�� */
    tzer.passSpace();
    if( *tzer == '"' ){
      /* �t�B���^�[�w��̏ꍇ */
      string filter;
      tzer.readQuoted(filter);
      tmp = new SuffixForPager( suffixes[0] , filter );
    }else{
      /* �t�B���^�����̏ꍇ */
      tmp = new SuffixForPager( suffixes[0] );
    }
  }else if( ident.compare("open")==0 ){
    tmp = new SuffixForOpen( suffixes[0] );
  }else if( ident.compare("exec")==0 ){
    string command;
    tzer.readQuoted( command );
    tmp = new SuffixForExec( suffixes[0] , command );
  }else if( ident.compare("rexx")==0 ){
    string inlineScript;
    tzer.readQuotedRexxScript( inlineScript );
    tmp = new SuffixForRexx( suffixes[0] , inlineScript );
  }else{
    throw Tokenizer::UnexpectedWord(tzer,ident);
  }
  
  for( unsigned i=1 ; i<suffixes.size() ; i++ )
    tmp->setSuffix( suffixes[i] );
  
  if( tmp ) tmp->regist();
    
  return 0;
}

int SuffixForRexx::run( const char *params )
{
  return script( params , 0 );
}


static int cfg_setenv( Tokenizer &tzer , ostream &)
{
  /* setenv �ϐ���="���e" */

  string sbuf;
  tzer.readIdentifier(sbuf);
  tzer.passChar('=');
  sbuf += '=';

  string value;
  tzer.readQuoted( value );
  string::iterator sp=value.begin();
  while( sp != value.end() ){
    if( *sp == '%' ){
      /* ���ϐ��̓W�J */
      string envname;
      ++sp; // skip first '%'
      while( *sp != '\0' ){
	if( *sp == '%' ){
	  ++sp; // skip last '%'
	  break;
	}
	envname += *sp++;
      }
      const char *env=getenv(envname.c_str());
      if( env != 0 )
	sbuf += env;
    }else{
      sbuf += *sp++;
    }
  }
  putenv( strdup(sbuf.c_str()) );
  return 0;
}
static int cfg_begin( Tokenizer &tzer , ostream &os )
{
  string rexx;
  tzer.readQuotedRexxScript( rexx );

  MyRexx script( "eff" , rexx );
  script( "begin" , 0 );
  return 0;
}


extern int cfg_archive(Tokenizer &tzer,ostream &);
extern int cfg_color(Tokenizer &tzer,ostream &);

extern int extJumpList[ 0x200 ];

extern int keyNameToCode( const char *s );

static int interpret_keystr( const char *s )
{
  if( s == NULL || s[0] == '\0' )
    return -1;
  
  if( s[1] == '\0' )
    return s[0] & 0xFF;
  
  return keyNameToCode( s );
}

static int cfg_bindkey(Tokenizer &tzer,ostream &messenger)
{
  char buf[256];
  tzer.readQuoted( buf , sizeof(buf) );

  int k1=interpret_keystr(buf);
  if( 0 < k1 && k1 > 0x200 )
    throw Tokenizer::UnexpectedWord(tzer,buf);

  tzer.passSpace();
  if( *tzer == ',' ){
    /* �L�[�ɁA�����R�}���h�̋@�\�����肠�Ă� */
    
    ++tzer; // �J���}��ǂݔ�΂�.
    tzer.readQuoted( buf , sizeof(buf) );
    int k2=interpret_keystr(buf);

    if( (unsigned)k2 < numof( extJumpList ) )
      extJumpList[ k1 ] = k2;
  }else{
    /* ���̌�ɗ\��ꂪ���� */
    tzer.readIdentifier(buf,sizeof(buf));
    strlwr(buf);
    if( buf[0] == 'e' && strcmp(buf,"exec")==0 ){
      /* exec �I�v�V���� */
      string cmds;
      tzer.readQuoted( cmds );
      Launcher *tmp=new CommandLauncher( cmds );
      tmp->registAt( k1 );
    }else if( buf[0] == 'r' && strcmp(buf,"rexx")==0 ){
      /* rexx �I�v�V���� */
      string script;
      tzer.readQuotedRexxScript( script );
      Launcher *tmp=new RexxLauncher( script );
      tmp->registAt( k1 );
    }else{
      throw Tokenizer::UnexpectedWord(tzer,buf);
    }
  }
  return 0;
}

static int cfg_include(Tokenizer &tzer,ostream &os)
{
  string path;
  tzer.readQuoted( path );
  return readConfigFile( explodeHome(path) , os , false );
}

struct ConfigCommand {
  const char *name;
  /* ���s�R�}���h���\�b�h
   * return
   *	-1 : �G���[�H
   *	 0 : �������Ȃ�
   *	�� : �����́u;�v�������œǂ݂Ƃ΂��B
   */
  int (*method)(Tokenizer &tzer,ostream &);
  
  static int compare(const void *key,const void *element){
    const char *x=static_cast<const char *>(key);
    const char *y=static_cast<const ConfigCommand *>(element)->name;
    
    return *x != *y ? *x-*y : strcmp(x,y);
  }
} jumpTable[]={
  { "altkey"	, &cfg_altkey }, // deprecated.
  { "archive"	, &cfg_archive },
  { "begin"     , &cfg_begin },   // deprecated.
  { "bindkey"	, &cfg_bindkey },
  { "canna"	, &cfg_canna }, // deprecated
  { "color"	, &cfg_color }, // to be deprecated.
  { "editor"	, &cfg_editor }, // deprecated.
  { "ext"	, &cfg_ext },
  { "helpfile"	, &cfg_helpfile }, // deprecated.
  { "include"	, &cfg_include },
  { "pager"	, &cfg_pager }, // deprecated.
  { "print"	, &cfg_print },
  { "setenv"	, &cfg_setenv },
  { "sort"	, &cfg_sort },
};

static int setProps( Property &base , Tokenizer &tzer );

static void readProperty( Property &base , Tokenizer &tzer )
{
  // �v���p�e�B�[���̎擾.
  Property *prop=&base;
  for(;;){
    string name;
    tzer.readIdentifier(name);
    prop = &(*prop)[ name ];
    tzer.passSpace();
    if( *tzer != '.' )
      break;
    ++tzer;
  }

  // �������l�̎擾.
  tzer.passChar('=');
  tzer.passSpace();
  if( *tzer == '\{' ){
    setProps( *prop , ++tzer );
  }else if( *tzer == '"' ){
    string value;
    tzer.readQuoted( value );
    *prop = value;
  }else{
    string value;
    tzer.readIdentifier( value );
    *prop = value;
  }
  tzer.passSpace();
}

static int setProps( Property &base , Tokenizer &tzer )
{
  for(;;){
    tzer.passSpace();
    if( *tzer == '}' ){
      ++tzer;
      return 0;
    }
    readProperty( base , tzer );
    if( *tzer == '}' ){
      ++tzer;
      return 0;
    }
    tzer.passChar( ',' );
  }
  return 0;
}


/* �C�ӂ̃X�g���[�����̃R���t�B�O����ǂ݂Ƃ�B
 * 	tzer : �X�g���[��
 * return
 *	0 : ���� -1 : ���s
 */
static int configurationCore( Tokenizer &tzer , ostream &messenger )
     throw(  Tokenizer::UnexpectedChar
	   , Tokenizer::UnexpectedWord
	   , Tokenizer::ErrorObject    )
	   
{
  /* ��ʃ��[�v */
  while( tzer.passSpace() , tzer.isOk() ){
    /* �R�}���h���̕��� */
    string cmdname;

    tzer.readIdentifier(cmdname);
    toLower( cmdname );
    
    ConfigCommand *cmds = 
      (ConfigCommand*)bsearch(  cmdname.c_str()
			      , jumpTable
			      , numof(jumpTable)
			      , sizeof(ConfigCommand)
			      , &ConfigCommand::compare );
    
    if( cmds == NULL ){
      // �\���łȂ��ꍇ => �ϐ����.
      tzer.passSpace();
      Property &prop=Property::root[cmdname];
      if( *tzer == '.' ){
	++tzer;
	readProperty( prop , tzer );
      }else{
	// �������l�̎擾.
	tzer.passSpace();
	// '=' �͂����Ă������Ă��悢.
	if( *tzer == '=' )
	  ++tzer;
	tzer.passSpace();
	if( *tzer == '\{' ){
	  setProps( prop , ++tzer );
	}else if( *tzer == '"' ){
	  string value;
	  tzer.readQuoted( value );
	  prop = value;
	}else{
	  string value;
	  tzer.readIdentifier( value );
	  prop = value;
	}
	tzer.passSpace();
      }
      // �����̃Z�~�R�����͔C��.
      tzer.passSpace();
      if( *tzer == ';' )
	++tzer;
    }else{
      // �\���̏ꍇ => ���ߌĂяo��.
      switch( (*cmds->method)(tzer,messenger) ){
      case -1:
	return -1;
	
      case 1:
	continue;
	
      default:
	tzer.passChar(';');
	break;
      }
    }
  }
  return 0;
}


/* �R���t�B�O�t�@�C����ǂ�
 *	fname �t�@�C����
 *	messenger �G���[���b�Z�[�W���o�͂���֐��I�u�W�F�N�g
 *	skipflag true�̎��A�u#�v�Ŏn�܂�ueff�v���܂ލs��������܂�
 *			�ǂ݂Ƃ΂��B
 * return
 *	0 ����I�� , -1�` �G���[(���b�Z�[�W���\�������)
 */
int readConfigFile(const string &fname,ostream &outs,bool skipflag=false)
{
  try{
    ifstream ins( fname.c_str() );
    Tokenizer tzer(ins);
    if( ! tzer.isOk() ){
      outs << fname << ": File not found." << endl; 
      return -1;
    }
    if( skipflag ){
      string buffer;
      do{
	tzer.readline(buffer);
      }while( buffer[0] != '#' && buffer.find("eff") != string::npos );
    }
    if( configurationCore( tzer , outs ) )
      return -1;
  }catch( Tokenizer::ErrorObject &e ){
    outs << fname << '(' << e.getLNum() << "): " << e << endl;
    return -3;
  }
  return 0;
}

/* ���ϐ����A�R���t�B�M�����[�V��������ǂ�
 *	env - ���ϐ���
 *	messenger - �G���[���b�Z�[�W���o���֐��I�u�W�F�N�g
 * return
 *	0 : �G���[���� , ��0 : �G���[
 */
static int readConfigEnv( const char *env , ostream &outs )
{
  const char *str=getenv(env);
  if( str == NULL )
    return 0;

  try{
    istrstream ins( str );
    Tokenizer tzer( ins );
    
    if( configurationCore( tzer , outs ) )
      return -1;
  }catch( Tokenizer::ErrorObject &e ){
    outs << '%' << env << "%: " << e << endl;
    return -2;
  }
  return 0;
}

static int readline(int argc,const string *args,string &result)
{
  int rc=0;
  string resultStr;
  if( argc >= 1 )
    resultStr = args[0];
  
  if( BasicWin::wmoutIsCout ){
    iCannaEmx getline;
    rc = getline( resultStr );
    cout << endl;
  }else{
    WmInput getline(BasicWin::console_handle,BasicWin::bottom_handle);
    rc = getline( resultStr );
    BasicWin::wmout << endl;
  }
  if( rc >= 0 )
    result = resultStr;
  else
    result = "";
  return 0;
}

static int print(int argc,const string *args,string &result)
{
  for( int i=0 ; i<argc ; i++ ){
    BasicWin::wmout << args[i];
  }
  BasicWin::wmout << flush;
  result = "";
  return 0;
}

static int println(int argc,const string *args,string &result)
{
  for( int i=0 ; i<argc ; i++ ){
    BasicWin::wmout << args[i];
  }
  BasicWin::wmout << endl;
  result = "";
  return 0;
}

static int viewtype(int argc,const string *args,string &result)
{
  result = BasicWin::whatsFocus();
  return 0;
}

static int manipProperty(int argc,const string *args,string &result)
{
  if( argc == 2 ){
    Property::root[ args[0] ] = args[1];
    result = args[1];
  }else if( argc == 1 ){
    result = Property::root[ args[0] ].value();
  }else{
    result.erase();
  }
  return 0;
}

static int keysProperty(int argc,const string *args,string &result )
{
  result.erase();
  Property &prop=( argc < 1 ? Property::root : Property::root[ args[0] ] );
  for(  Property::Properties::iterator itr=prop.begin()
      ; itr != prop.end()
      ; ++itr ){
    if( ! result.empty() )
      result += ' ';
    result += itr->second->name();
  }
  return 0;
}

static int eval(int argc,const string *args,string &result)
{
  try{
    for( int i=0 ; i<argc ; i++ ){
      istrstream ins( args[i].c_str() );
      Tokenizer tzer( ins );
      
      if( configurationCore( tzer , BasicWin::wmout ) ){
	result = "-1";
	return 0;
      }
    }
  }catch( Tokenizer::ErrorObject &e ){
    BasicWin::wmout << e << endl;
  }
  result = "0";
  return 0;
}


/* eff �̃R���t�B�M�����[�V�����t�@�C����T���ēǂ�
 * return
 *	 0: ����I��
 *	-1�`-3: readConfig �̃G���[
 *	-4: �R���t�B�O�t�@�C�����ǂ��ɂ����݂��Ȃ��B
 */
int effConfig( const string &doteff_ , bool skipflag )
{
  int rc=0;
  const char *home=0;
  const char *temp=0;
  
  MyRexx::registSubCommand( &system );
  MyRexx::registFunction( "READLINE" , &readline );
  MyRexx::registFunction( "PRINT" , &print );
  MyRexx::registFunction( "PRINTLN" , &println );
  MyRexx::registFunction( "VIEWTYPE" , &viewtype );
  MyRexx::registFunction( "EVAL" , &eval );
  MyRexx::registFunction( "PROPERTY" , &manipProperty );
  MyRexx::registFunction( "SUBPROPERTY" , &keysProperty );

  if( (temp=getenv("EDITOR")) != NULL ){
    Property::root[ "eff.editor" ] = temp;
  }else{
    Property::root[ "eff.editor" ] = "tedit";
  }
  if( (home=getenv("HOME")) != NULL ){
    Property::root[ "eff.home" ] = home;
  }else{
    Property::root[ "eff.home" ] = "";
  }
  
  string doteff = doteff_;
  if( ! doteff.empty()  ){
    rc = readConfigFile( doteff = doteff , cerr , skipflag );
  }else if(   access2( doteff="_eff" )==0
	   || access2( doteff=".eff" )==0 ){
    rc = readConfigFile( doteff , cerr , skipflag );
  }else if( home != NULL ){
    if(   access2( doteff=AFile::makepath(home,"_eff") )==0
       || access2( doteff=AFile::makepath(home,".eff") )==0){
      // �����ł� include �ׂ̈ɃJ�����g�f�B���N�g�����ꎞ�I��.
      // �ړ������Ă���.
      AFile::DirSave athome( home );
      
      rc = readConfigFile( doteff , cerr , skipflag );
    }
  }
  Property::root[ "eff.doteff" ] = doteff;

  rc |= readConfigEnv("EFF",cerr);

  string canna_when_load=Property::root[ "canna.whenload" ].value();
  if( canna_when_load == "startup" ){
    iCanna::summonCanna();
  }else if( canna_when_load == "none" ){
    iCanna::sealCanna();
  }
  return rc;
}

int SuffixList::run( const char *params )
{
  box_cursor_on();
  int rc=system2( procedure + ' ' + params );
  cursor_off();
  return rc;
}

// extern int lesz_pipe( const char *command , const char *title );

int SuffixList::seeCommandResult( const char *params , const char *title )
{
  string cmdline;
  cmdline  = procedure;
  cmdline += ' ';
  cmdline += params;
  
  return ThePager::lookOutput( cmdline , title ? title : params );
}
