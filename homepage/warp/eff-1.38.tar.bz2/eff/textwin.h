/* -*- c++ -*- */
#include <string>
#include "basicwin.h"

class istream;

class TextWin : public BasicWin {
  class Node {
    Node *next,*prev;
    string text;
  public:
    Node(const string &s) : next(0),prev(0),text(s) {}

    const string &toChar() const { return text; }

    Node *combine( Node *x ){
      if( next )	next->prev = 0;
      if( x->prev )	x->prev->next = 0;
      next = x;
      x->prev = this;
      return this;
    }
    Node *getNext() { return next; }
    Node *getPrev() { return prev; }

  } *first;

  class Cursor : public Iterator {
    Node *node;
    TextWin *parent;
  public:
    Cursor(Cursor *p) : node(p->node) , parent(p->parent){}
    Cursor(Node *p,TextWin *t) : node(p) , parent(t){}
    virtual ~Cursor(){}

    int can_forward() const { return node->getNext() != 0; }
    int forward(){
      if( node->getNext() == 0 )
	return -1;
      node = node->getNext();
      ++n;
      return N();
    }
    int backward(){
      if( node->getPrev() == 0 )
	return -1;
      node = node->getPrev();
      --n;
      return N();
    }
    Iterator *dup() const { return new Cursor(*this); }
    const char *getName() const { return node->toChar().c_str() ; }
    bool getLine(VBuffer &vbuf,int width);
    void set(const Iterator &it){
      const Cursor *x=dynamic_cast<const Cursor*>( &it );
      if( x ){ node=x->node; parent=x->parent; }
    }
  };
  
  char titleLine(VBuffer &);
  struct RestoreTextWin;
  string helpfname;
public:
  struct Fail {};
  RestoreWin *saveMe();

  void init( istream &ins );
  TextWin( RestoreWin *r );
  TextWin( istream &ins , RestoreWin *r );
  
  BasicWin::Status run(int key);
  
  virtual ~TextWin();
  const char *what() const { return "HELP"; }
};
