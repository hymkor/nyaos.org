#include "tokenizer.h"
#include "basicwin.h"
#include "fileswin.h"
#include "arcwin.h"
#include "treewin.h"
#include "prowin.h"
#include "leszbuf.h"

struct ColorCoordinate {
  const char *keyword;
  unsigned *pointor;
  
  static int compare(const void *key,const void *element){
    const char *x=static_cast<const char *>( key );
    const char *y=static_cast<ColorCoordinate *>( element )->keyword;

    return *x != *y ? *x-*y : strcmp(x,y);
  }
} color_tables[] = {
  { "A_NORMAL"		, &ArchiveWin::color_text },
  { "A_TITLEBAR"	, &ArchiveWin::color_titlebar },
  { "A_TITLELINE"	, &ArchiveWin::color_titleline },

  { "BLANK"		, &BasicWin::color_background },
  { "CURSOR"		, &BasicWin::color_cursor },

  { "F_DIRECTORY"	, &FilesWin::color_directory },
  { "F_EXECUTABLE"	, &FilesWin::color_executable },
  { "F_HIDDEN"		, &FilesWin::color_hidden },
  { "F_LONGNAME"	, &FilesWin::color_longname },
  { "F_MISC"		, &FilesWin::color_filemisc },
  { "F_NORMAL"		, &FilesWin::color_normal },
  { "F_READONLY"	, &FilesWin::color_readonly },
  { "F_SHORTNAME"	, &FilesWin::color_shortname },
  { "F_TITLEBAR"	, &FilesWin::color_titlebar },
  { "F_TITLELINE"	, &FilesWin::color_titleline },
  
  { "MESSAGE"		, &BasicWin::color_message },

  { "PAGER_BOLD"	, &Book::BOLD_COLOR },
  { "PAGER_CTRL"	, &Book::CTRL_COLOR },
  { "PAGER_RCTRL"	, &Book::REV_CTRL_COLOR },
  { "PAGER_TEXT"	, &Book::TEXT_COLOR },
  { "PAGER_TITLE"	, &Book::TITLE_COLOR },
  { "PAGER_UNDERLINE"	, &Book::UL_COLOR },

  { "P_NORMAL"		, &ProcessWindow::color_normal },
  { "P_TITLEBAR"	, &ProcessWindow::color_titlebar },
  { "P_TITLELINE"	, &ProcessWindow::color_titleline },
  
  { "STANDARD"		, &BasicWin::color_standard },

  { "T_NORMAL"		, &TreeWin::color_normal },
  { "T_TITLEBAR"	, &TreeWin::color_titlebar },
  { "T_TITLELINE"	, &TreeWin::color_titleline },
};

class ostream;
int cfg_color(Tokenizer &tzer,ostream &)
{
  char buffer[ 128 ];

  tzer.passChar('{');

  for(;;){
    tzer.readIdentifier( buffer , sizeof(buffer) );
    strupr( buffer );
    
    ColorCoordinate *cc=(ColorCoordinate*)
      bsearch(  buffer , color_tables
	      , numof(color_tables) , sizeof(ColorCoordinate)
	      , &ColorCoordinate::compare );
    if( cc != NULL ){
      tzer.passChar('=');
      tzer.passSpace();
      
      *cc->pointor = tzer.readNumber(); 
    }else if( strcmp(buffer,"HORIZON_CHAR")==0 ){
      tzer.passChar('=');
      tzer.passSpace();

      BasicWin::horizon_char = tzer.readNumber();
    }else{
      throw Tokenizer::UnexpectedWord(tzer,buffer);
    }
    
    if( tzer.topChar() == ',' ){
      ++tzer;
      if( tzer.topChar() == '}' ){
	++tzer;
	break;
      }
      continue;
    }else if( *tzer == '}' ){
      ++tzer;
      break;
    }else{
      throw Tokenizer::UnexpectedChar(tzer);
    }
  }
  return 1;
}
