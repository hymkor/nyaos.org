/* -*- c++ -*- */
#ifndef EFFCFG_H
#define EFFCFG_H

#include <cstdio>
#include <string>
#include <iostream>
#include <map>

#undef numof
#define numof(X) (sizeof(X)/sizeof((X)[0]))

#include "myrexx.h"
#include "property.h"

struct SuffixList{
public:
  enum SuffixType{ OPEN , PAGER , EXEC , REXX };
private:
  bool isRegisted;
  SuffixType type;
  vector<string> suffixes;
  string procedure;

  static vector<SuffixList*> table;
  static map<string,SuffixList *> index;
public:
  void setProcedure( const string &p ){ procedure = p; }
  const string &getProcedure() const { return procedure; }
  void setSuffix( const string &s );
  SuffixType getType() const { return type; }
  void regist();
  
  SuffixList( SuffixType t ) : isRegisted(false),type(t){}
  SuffixList( const SuffixList &s )
    : isRegisted(false), type(s.type)
      , suffixes(s.suffixes) , procedure(s.procedure) {}
  SuffixList( SuffixType t , const string &suffixString )
    : isRegisted(false) , type(t)
      {  setSuffix(suffixString);  }
  virtual ~SuffixList();
  
  virtual int run( const char *params );
  int seeCommandResult( const char *params , const char *title=0 );

  static SuffixList *find( const string & );
};

class SuffixForRexx : public SuffixList {
  MyRexx script;
public:
  SuffixForRexx( const string &suffix , const string &inlineScript )
    : SuffixList(REXX,suffix) , script( "eff" , inlineScript ){}
  int run( const char *params );
};

class SuffixForExec : public SuffixList {
public:
  SuffixForExec( const string &suffix , const string &cmdName )
    : SuffixList(EXEC,suffix)
      { setProcedure(cmdName); }
};

class SuffixForOpen : public SuffixList {
public:
  SuffixForOpen( const string &suffix )
    : SuffixList(OPEN,suffix){}
};

class SuffixForPager : public SuffixList {
public:
  SuffixForPager( const string &suffix )
    : SuffixList(PAGER,suffix){}
  SuffixForPager( const string &suffix , const string &filter )
    : SuffixList(PAGER,suffix){ setProcedure(filter); }
};

class Launcher {
  static Launcher *commands[ 0x400 ];
public:
  virtual ~Launcher(){}

  void registAt( int at ){
    delete commands[ at] ;
    commands[ at ] = this;
  }
  static Launcher *at( int x )
  {  return (unsigned)x < numof(commands) ? commands[ x ] : NULL ; }
  static int init();
  static void term(int);
};

class CommandLauncher : public Launcher {
  string commands_;
public:
  CommandLauncher( const string &cmd ) : commands_(cmd){}
  const string &command() const { return commands_ ; }
};

class RexxLauncher : public Launcher {
  MyRexx script_;
public:
  RexxLauncher( const string &inlineScript ) : script_("eff",inlineScript){}
  
  MyRexx &operator * () { return script_; }
  MyRexx *operator ->() { return &script_; }
};

class ThePager {
public:
  static const string &programName()
    { return Property::root["eff.pager"].value(); }
  static void useBuiltIn()
    { Property::root["eff.pager"] = ""; }
  static void setPager( const string &s )
    { Property::root["eff.pager"] = s; }

  static int lookFile  ( const string &fname );
  static int lookOutput( const string &cmdline , const string &title );
  static int lookStdin( const string &title="" );
};

SuffixList *findSuffix(const char *suffix);
int readConfigFile(const string &fname, ostream &out , bool skip=false );
int effConfig(const string &doteff,bool skipflag );

enum{ errValue = -32768 };

#endif
