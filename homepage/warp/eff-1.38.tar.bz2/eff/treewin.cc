#include <alloca.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <sys/kbdscan.h>

#include "mergesort.h"
#include "VBuffer.h"
#include "afile.h"
#include <os2.h>

#include "property.h"
#include "fileswin.h"
#include "treewin.h"

struct TreeWin::RestoreTreeWin : public BasicWin::RestoreWin {
  string cursorDir; /* �J�[�\���̂���f�B���N�g�� */

  RestoreTreeWin( const string &cd ) : cursorDir(cd){}
  BasicWin *restore() { return new TreeWin(cursorDir.c_str()); }
  RestoreWin *dup(){ return new RestoreTreeWin(cursorDir); }
};

BasicWin::RestoreWin *TreeWin::saveMe()
{
  return new RestoreTreeWin( getCurrentDir() );
}

int TreeWin::TIterator::can_forward() const 
{  return N()+1 < treeWin->nlists;  }

BasicWin::Iterator *TreeWin::TIterator::dup() const
{  return new TIterator(*this); }

TreeWin::Node::~Node()
{
  if( prev != NULL )    prev->next = NULL;
  if( next != NULL )    next->prev = NULL;

  delete next;
}

inline int TreeWin::Node::Comparer::operator() (  const TreeWin::Node *x
						, const TreeWin::Node *y )
     const throw() 
{
  switch( method & AFile::Comparer::MASK ){
  default:
    return x->getName().compare( y->getName() );
    
  case AFile::Comparer::NAME_IGNORE:
    return stricmp(x->getName().c_str(),y->getName().c_str());
  }
}

void TreeWin::TIterator::toUpper()
{
  int level=(*this)->level;
  if( level > 0 ){
    while( this->can_backward() && (*this)->level >= level )
      this->backward();

    treeWin->reform();
  }
}

/* S �̖��������ȊO�Ȃ�΁A����������B*/
static void appendRoot( string &s )
{
  int prevchar=0;
  for( size_t i=0 ; i<s.length() ; i++ ){
    if( isKanji(prevchar = (s[i] & 255)) )
      ++i;
  }
  if( prevchar != '\\' )
    s += '\\';
}


int TreeWin::Node::open()
{
  subdir = SUBDIRS_OPEN;
  _chdir2( fullname.c_str() );

  if( children != NULL )
    return nchildren;
  
  Node *first=NULL;
  int count=0;

  for( AFile::List dir(".") ; dir ; ++dir ){
    if( ! dir->isDir() || dir->getName()[0] == '.' )
      continue;
      
    Node *node=new Node;
    
    if( first != NULL )
      first->prev = node;

    node->prev   = NULL;
    node->next   = first;
    first = node;
    
    node->parent = this;
    node->level  = this->level+1;
    node->name   = dir->getName();
    
    node->fullname = this->fullname;
    appendRoot( node->fullname );
    node->fullname += dir->getName();
    
    ++count;
  }

  if( count <= 0 ){
    this->subdir = NO_SUBDIRS;
  }else{
    first = merge_sort( first , Comparer(DirBasicWin::sort_method) );

    for( Node *ptr=first ; ptr != NULL ; ptr=ptr->next ){
      for( AFile::List dir(ptr->fullname) ; dir ; ++dir ){
	if( dir->isDir()  &&  dir->getName()[0] != '.' ){
	  ptr->subdir = SUBDIRS_CLOSE;
	  break;
	}
      }
    }
  }
  delete children; children = first;
  return nchildren = count;
}

int TreeWin::Node::howManyLists()
{
  int n=1;
  if( subdir==SUBDIRS_OPEN && children != NULL )
    n += children->howManyLists();
  if( next != NULL )
    n += next->howManyLists();
  return n;
}

int TreeWin::Node::listFlatly( Node **&ptr )
{
  int n=1;
  *ptr++ = this;
  if( subdir==SUBDIRS_OPEN &&  children != NULL )
    n += children->listFlatly(ptr);
  if( next != NULL )
    n += next->listFlatly(ptr);
  return n;
}


int TreeWin::makeFlatList()
{
  nlists = 0;
  for(int i=0 ;i<numof(roots) ; i++ )
    nlists += roots[i].howManyLists();
  
  Node **ptr = new Node*[ nlists ];
  if( ptr == NULL ){
    nlists = 0;
    return 0;
  }
  delete [] flatlist;
  flatlist = ptr;
  
  for(int i=0 ; i<numof(roots) ; i++ )
    roots[i].listFlatly( ptr );

  return nlists;
}

void TreeWin::Node::putbar(VBuffer &vbuf)
{
  if( parent == NULL )
    return;

  static string vertical=Property::root["eff.treewin.vertical"].value("| ");
  parent->putbar(vbuf);

  if( parent->next != NULL ){
    vbuf << vertical; // "��";
  }else{
    vbuf << "  ";
  }
}


bool TreeWin::TIterator::getLine( VBuffer &vbuf , int w )
{
  static Property &treetext=Property::root[ "eff.treewin" ];
  static string open=treetext["open"].value(" [-]");
  static string close=treetext["close"].value(" [+]");
  static string tee=treetext["tee"].value("+-");
  static string corner=treetext["corner"].value("+-");

  vbuf.color( color_normal );
  if( treeWin->flatlist[ N() ] == NULL )
    return false;

  Node &node=*treeWin->flatlist[ N() ];
  
  node.putbar(vbuf);

  if( node.level > 0 ){
    if( node.next != NULL )
      vbuf << tee; // "��";
    else
      vbuf << corner; // "��";
  }

  vbuf << node.getName();

  if( node.subdir == TreeWin::Node::SUBDIRS_OPEN )
    vbuf << open; // " [-]";
  else if( node.subdir == TreeWin::Node::SUBDIRS_CLOSE )
    vbuf << close; // " [+]";
  
  if( w > 60 ){
    int left=w - vbuf.getLength() - node.fullname.length() - 4; 
    if( left > 0 ){
      while( left-- > 0 )
	vbuf << ' ';

      vbuf << "( " << node.fullname << " )" ;
    }
  }
  return true;
}

void TreeWin::TIterator::set(const BasicWin::Iterator &it_)
{
  try{
    const TIterator &it = dynamic_cast<const TIterator &>( it_ );
    treeWin = it.treeWin;
  }catch(...){
    ;
  }
}

TreeWin::TreeWin( const string &dir ) : nlists(0) , flatlist(0)
{
  char rootdir[] = { 'A' , ':' , '\\' , '\0' };

  for(int i=0;i<numof(roots);i++){
    roots[i] = rootdir;
    roots[i].subdir = Node::SUBDIRS_CLOSE;
    ++rootdir[0];
  }
  
  int nthDrive=(dir[0] & 0x1F)-1;
  roots[ nthDrive ].open();
  startAt=this->open( dir ) + nthDrive ;

  nlists = makeFlatList();

  top = new TIterator(this);
  heaven = top->dup();
  cursor = top->dup();
  earth = NULL;
}

void TreeWin::hookOnOpen()
{
  setColumn();
  reform( startAt );
}


TreeWin::~TreeWin()
{
  delete[] flatlist;
}

BasicWin::Status TreeWin::runTreeWin(int key)
{
  TIterator *cur=(cursor ? dynamic_cast<TIterator*>((Iterator*)cursor ) : 0 );
  BasicWin *tmp=0;

  switch( key ){
    
  default:
    return this->BasicWin::runBasicWin(key);

  case BIND_VIEW_TWO:
  case '2':
    try{
      if( forkWin(tmp=new TreeWin(cur->getPath())) != 0 ){
	message( "Can not open a new window." );
	delete tmp;
      }
    }catch(...){
      message("Can not open a new window.");
      delete tmp;
    }
    return CONTINUE;

  case BIND_CHG_TREE:
  case BIND_ENTER:
  case ';':
  case 't':
  case '\r':
  case '\n':
    try{
      replaceWin( tmp=new FilesWin(cur->getPath()) );
    }catch(...){
      message( "Can not open a new window" );
      delete tmp;
    }
    return CONTINUE;

  case BIND_LEAVE:
  case '\b':
  case 'o':
    if( (*cur)->subdir != Node::SUBDIRS_OPEN )
      cur->toUpper();
    (*cur)->close();
    nlists = makeFlatList();
    BasicWin::repaint();
    break;

    // case BIND_ENTER:
  case BIND_MARK_AND_FORWARD:
  case 'i':
  case ' ':
    if(   (*cur)->subdir == Node::NO_SUBDIRS 
       || ((*cur)->subdir==Node::SUBDIRS_OPEN && (*cur)->children != NULL )){
      try{
	replaceWin( tmp=new FilesWin(cur->getPath()) );
	return CONTINUE;
      }catch(...){
	message( "Can not open a new window" );
	delete tmp;
	break;
      }
    }else{
      (*cur)->open();
    }
    
    nlists = makeFlatList();
    BasicWin::repaint();
    break;

  case BIND_PASTE:
  case KEY(SHIFT_INS):
  case CTRL('y'):
  case KEY(INS):
    paste_from_killring(key);
    break;
  }
  return CONTINUE;
}

unsigned TreeWin::color_normal    = 0x0F ;
unsigned TreeWin::color_titlebar  = 0xA0 ;
unsigned TreeWin::color_titleline = 0x0A ;

char TreeWin::titleLine(VBuffer &vbuf)
{
  vbuf.color( color_titleline ) 
    << horizon_char << horizon_char 
      << horizon_char << horizon_char << horizon_char;

  vbuf.color( color_titlebar  ) << " Directory Trees ";
  vbuf.color( color_titleline );
  return horizon_char;
}

/* _path �̎����f�B���N�g���̉��̃T�u�f�B���N�g����W�J����B
 * ��������s������AmakeFlatList ���āAflatlist �Ɏˉe����
 * ����΁Arepaint ���Ă���ʂɔ��f����Ȃ��B
 *
 *	_path �t���p�X(x:/����n�܂�̂�O��)
 */
int TreeWin::open( const string &_path )
{
  char *path=(char*)alloca( _path.length()+1 );
  strcpy( path , _path.c_str() );
  
  char *dir=strtok(path,"/\\");
  if( dir == NULL )
    return 0;

  Node *ptr=&roots[ (dir[0] & 0x1F)-1 ];
  int csrlin=0;

  while( (dir=strtok(NULL,"/\\")) != NULL ){
    if( ptr->children == NULL  &&  ptr->subdir == Node::NO_SUBDIRS )
      break;
    ptr = ptr->children;
    for(;;){
      ++csrlin;
      if( ptr == NULL )
	return csrlin;

      if( stricmp(ptr->getName().c_str() , dir) == 0 )
	break;
      
      ptr = ptr->next;
    }
    ptr->open();
  }
  return csrlin;
}

int TreeWin::main(int x,int y,int w,int h,const char *dir)
{
  TreeWin *tmp=0;
  char fullpath[ FILENAME_MAX ];
  _fullpath( fullpath , dir , sizeof(fullpath) );

  try{
    if( (tmp=new TreeWin(fullpath)) != NULL ){
      tmp->BasicWin::open(x,y,w,h-message_lines-1);
      return BasicWin::main(y+h-message_lines-1,message_lines);
    }
  }catch(...){
    delete tmp;
  }
  return -1;
}
