#include <stdarg.h>
#include <stdio.h>
#include "icanna.h"

void iCannaTty::start(void)
{
  raw_mode();
  bindkey( CTRL('D') , &GetLine::erase_or_listing );
  bindkey( CTRL('I') , &GetLine::complete_or_listing );
}
void iCannaTty::end(void)
{
  cocked_mode();
  putchar('\n');
  clear_bottom();
}

int iCannaTty::getrawkey()
{
  fflush(stdout);
  return ::getkey();
}

void iCannaTty::dimen(int *wh) const 
{
  _scrsize(wh);
}
