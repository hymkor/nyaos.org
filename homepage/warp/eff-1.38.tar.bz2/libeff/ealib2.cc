#include <sys/ea.h>
#include "ealib.h"

class ExtAttr::EACover {
  struct _ea ea;
  bool status;
public:
  EACover( const string &fname , const string &eatype ){
    ea.value = NULL ;  ea.size = 0;
    if(    _ea_get( &ea , fname.c_str() , 0 , eatype.c_str() ) != 0
       || ea.size <= 0  || ea.value == NULL ){
      status = false;
    }else{
      status = true;
    }
  }
  ~EACover(){ if( status ) _ea_free( &ea ); }

  operator const void *() const { return status ? this : 0; }
  bool operator !() const { return ! status; }
  
  int   getSize()  const { return ea.size; }
  void *getValue() const { return ea.value; }
};

class ExtAttr::MultiPointor {
  union Ptr{
    const void  *set;
    const char  *byte;
    const short *word;
    
    Ptr(const void *p) : set(p) {} 
  }ptr;
  int left;
public:
  MultiPointor(const void *p,int L)
    : ptr(p) , left(L) {} 
  MultiPointor(const EACover &ea)
    : ptr(ea.getValue()) , left(ea.getSize()) {}

  int readw()
    {  return (left-=2) < 0 ? -1 : (0xFFFF & *ptr.word++); }
  string readstr();

  bool good() const { return ptr.set != NULL  &&  left > 0 ; }
  int getLeft() const { return left; }
};

string ExtAttr::MultiPointor::readstr()
{
  int size=0;
  if( ! good() || (size=readw()) < 0 || (left -= size) < 0 )
    return "";
  
  ptr.byte += size;
  return string( ptr.byte - size , size );
}


string ExtAttr::getTextEA( const string &fname , const string &eatype )
{
  EACover ea(fname,eatype);
  if( ! ea ) return "";
  
  MultiPointor ptr(ea);
  if( ! ptr.good() || ptr.readw() != EA_ASCIITYPE )
    return "";
    
  return ptr.readstr();
}

int ExtAttr::getTextEA(  const string &fname
		       , const string &eatype
		       , vector <string> &ealist )
{
  int count=0;
  EACover ea( fname , eatype );

  if( ! ea )
    return 0;
  
  MultiPointor ptr(ea);
  
  if( ! ptr.good()  ||  ptr.readw() != EA_MULTITYPE )
    return 0;
    
  (void)ptr.readw(); /* �R�[�h�y�[�W��ǂ݂Ƃ΂� */
  int n=ptr.readw(); /* �e�[�u���T�C�Y */
  if( n <= 0 )
    return 0;
  
  for(int i=0;i<n;i++){
    if( ptr.readw() != EA_ASCIITYPE )
      break;
    
    string s=ptr.readstr();
    if( ! s.empty() ){
      ealist.push_back( s );
      ++count;
    }
  }
  return count;
}
