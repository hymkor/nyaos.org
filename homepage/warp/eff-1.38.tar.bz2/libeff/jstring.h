


class JString {
public:
  static void tolower( string &string );
  static void toupper( string &string );


  

};
