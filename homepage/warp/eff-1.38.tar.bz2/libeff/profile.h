
#include <string>
#include <map>

class IniProfile {
  long hini;

  class Key {
    string name;
  public:
    Key( const string p_name ) : name(p_name){}
    virtual ~Key(){}
  };
  class StringProfile : public Key {
    string value;
  public:
    StringProfile( const string &p_name )
      : Key(p_name){}
    StringProfile( const string &p_name , const string &p_value )
      : Key(p_name) , value(p_value) {}
    const string &getValue() const { return value; }

    void operator = (const char   *s){ value = s; }
    void operator = (const string &s){ value = s; }
  };
  class App {
    string name;
    map<string,Key*> keys;
  public:
    App( const string p_name ) : name(p_name){}
    ~App();
    const string &getName() const { return name; }
    void listUp(long hini);
  };

  map<string,App*> apps;
  
public:
  void open(unsigned long hab,const string &fname);
  void close();
  
  IniProfile() : hini(-1){}
  ~IniProfile(){ if(hini != -1){ close(); } }
};
