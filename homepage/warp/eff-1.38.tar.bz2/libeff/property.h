/* -*- c++ -*- */
#ifndef PROPERTY_H
#define PROPERTY_H

#include <string>
#include <map>

class ostream;

class Property {
public:
  typedef map<string,Property*> Properties;
private:
  string name_ , value_ ;
  Properties *child;
public:
  Property( const string &name ) : name_(name) , child(0){}
  
  const string &name() const { return name_ ; }
  const string &value() const { return value_ ; }
  const string &value(const char *default_value){
    if( value_.empty() )
      value_ = default_value;
    return value_;
  };

  const char *c_str() const { return value_.c_str(); }
  void operator = (const string &value){ value_ = value; }

  Property &operator[]( const string &key );

  bool boolean();

  Properties::iterator begin(){ return child->begin(); }
  Properties::iterator end(){ return child->end(); }
  
  ~Property();

  void print(ostream &os , const string &at="");
  size_t size(){ return child->size(); }
  
  static Property root;
};

inline ostream &operator << ( ostream &os , Property &props )
{  props.print(os); return os;  }


#endif 

