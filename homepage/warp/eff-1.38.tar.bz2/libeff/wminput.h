/* -*- c++ -*- */
#ifndef WMINPUT_H
#include <sys/winmgr.h>
#include "icanna.h"

class WmInput : public iCanna {
  wm_handle handle , bottom_handle;
protected:
  void putchr(int);
  void putbs(int);
  void start(void);
  void end(void);
  int  puts_bottom( const char * );
  void clear_bottom();
  int getrawkey();
public:
  WmInput( wm_handle h , wm_handle b ) : handle(h) , bottom_handle(b){  }
};

#endif
