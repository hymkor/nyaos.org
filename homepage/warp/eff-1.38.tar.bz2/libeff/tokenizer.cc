#undef DEBUG
#include <cctype>
#include <string>
#include "tokenizer.h"

/* �󔒂�ǂݔ�΂��B�{���\�b�h�� EOF ������Ă��A�G���[�Ƃ��Ȃ��B
 */
Tokenizer &Tokenizer::passSpace()
{
  while( isOk()  &&  isspace(lastchar & 255) )
    lastchar = read();
  return *this;
}

/* �󔒂�ǂ݂Ƃ΂�����̍ŏ��̕�����Ԃ��B�|�C���^�́A���̕�����̂܂܁B
 */
int Tokenizer::topChar() throw(Tokenizer::TooNearEof)
{
  for(;;){
    if( !isOk() )			throw TooNearEof(*this);
    if( !isspace(lastchar & 255) )	return lastchar;
    lastchar = read();
  }
}


/* ����̕�����ǂݔ�΂��B
 */
void Tokenizer::passChar(int ch)
     throw(Tokenizer::UnexpectedChar,Tokenizer::TooNearEof)
{
  if( ! passSpace().isOk() ) throw TooNearEof(*this);

  if( (lastchar & 255) != (ch & 255) )
    throw UnexpectedChar(*this);

  lastchar = read();
}

int Tokenizer::passChar(const char *s)
     throw(Tokenizer::UnexpectedChar,Tokenizer::TooNearEof)
{
  if( ! passSpace().isOk() )
    throw TooNearEof(*this);
  
  for(int i=0; s[i] != '\0' ; i++ ){
    if( (lastchar & 255) == (s[i] & 255) ){
      lastchar = read();
      return i;
    }
  }
  throw UnexpectedChar(*this);
}


int Tokenizer::readNumber()
     throw(Tokenizer::UnexpectedChar,Tokenizer::TooNearEof)
{
  passSpace();
  if( ! isOk() )  throw TooNearEof(*this);

  if( lastchar == '\'' ){
    int rv=read();
    if( (lastchar = read() ) != '\'' )
      throw UnexpectedChar(*this);
    lastchar = read();
    return rv;
  }
  
  int n=0;
  int minus=0;
  
  if( lastchar == '-' ){
    minus = 1;
    lastchar = read();
    passSpace();
  }
  if( ! isdigit(lastchar & 255) )
    throw UnexpectedChar(*this);

  if( lastchar == '0' ){
    /* 16�i�� */
    lastchar = read();
    if( lastchar == 'x' || lastchar == 'X' ){
      lastchar = read();

      for(;;){
	if( isdigit(lastchar & 255) ){
	  n = (n*16)+(lastchar-'0');
	}else if( 'a' <= lastchar && lastchar <= 'f' ){
	  n = (n*16)+10+(lastchar-'a');
	}else if( 'A' <= lastchar && lastchar <= 'F' ){
	  n = (n*16)+10+(lastchar-'A');
	}else{
	  break;
	}
	lastchar = read();
      }
    }else{
      /* 8�i�� */
      while( '0' <= lastchar && lastchar <= '7' ){
	n = (n*8) + (lastchar-'0');
	lastchar = read();
      }
    }
  }else{
    /* 10�i�� */
    while( isdigit(lastchar & 255) ){
      n = (n*10)+(lastchar-'0');
      lastchar = read();
    }
  }
  return minus ? -n : n ;
}

void Tokenizer::readIdentifier( string &result )
     throw(  Tokenizer::UnexpectedChar
	   , Tokenizer::TooNearEof )
{
  passSpace();
  if( ! isOk() )            throw TooNearEof(*this);
  if( ! isalpha(lastchar) ) throw UnexpectedChar(*this);

  result = "";
  do{
    result += char(lastchar);
    lastchar = read();
  }while( isOk()  && (isalnum(lastchar & 255) || lastchar == '_' ));
}

void Tokenizer::readIdentifier( char *buffer , int size )
     throw(  Tokenizer::UnexpectedChar
	   , Tokenizer::TooNearEof )
{
  passSpace();
  if( ! isOk() )            throw TooNearEof(*this);
  if( ! isalpha(lastchar) ) throw UnexpectedChar(*this);

  char *p=buffer;
  do{
    if( size-- > 0 )
      *p++ = lastchar;
    lastchar = read();
  }while( isOk()  && (isalnum(lastchar & 255) || lastchar == '_' ));
  *p = '\0';
}


/* �h�ň͂܂ꂽ�������ǂݎ��B
 */
void Tokenizer::readQuoted(char *buffer,int size)
     throw(  Tokenizer::UnexpectedChar
	   , Tokenizer::TooNearEof )
{
  passSpace();
  if( ! isOk() )
    throw TooNearEof(*this);

  if( lastchar != '"' )
    throw UnexpectedChar(*this);

  char *p=buffer;
  while( isOk()  &&  (lastchar = read()) != '"' )
    if( size-- > 0 )
      *p++ = lastchar;

  *p = '\0';
  if( lastchar == '"' )
    lastchar = read();
  else
    throw TooNearEof(*this);
}


void Tokenizer::readQuoted( string &result )
     throw(  Tokenizer::UnexpectedChar
	   , Tokenizer::TooNearEof )

{
  passSpace();
  if( ! isOk() )
    throw TooNearEof(*this);

  if( lastchar != '"' )
    throw UnexpectedChar(*this);
  
  result = "";
  lastchar = read();
  while( isOk()  &&  lastchar != '"' ){
    if( lastchar == '\\' ){
      int num=0;
      if( isdigit(lastchar=readcont()) ){
	do{
	  num <<= 3;
	  num += (lastchar - '0');
	}while( isdigit(lastchar=readcont()) );
	result += char(num);
      }else if( lastchar == 'x' ){
	while( isxdigit(lastchar=readcont()) ){
	  if( islower(lastchar) ){
	    num <<= 4; num += (lastchar-'a')+10;
	  }else if( isupper(lastchar) ){
	    num <<= 4; num += (lastchar-'A')+10;
	  }else{
	    num <<= 4; num += (lastchar-'0');
	  }
	}
	result += char(num);
      }else if( lastchar == 'r' ){
	result += char('\r');
	lastchar = read();
      }else if( lastchar == 'n' ){
	result += char('\n');
	lastchar = read();
      }else if( lastchar == 't' ){
	result += char('\t');
	lastchar = read();
      }else if( lastchar == '"' ){
	result += '"';
	lastchar = read();
      }else if( lastchar == '\\' ){
	result += '\\';
	lastchar = read();
      }else{
	result += '\\';
      }
    }else{
      // �� �ŃG�X�P�[�v���Ă��Ȃ�����.
      result += char(lastchar);
      lastchar = read();
    }
  }

  if( lastchar == '"' )
    lastchar = read();
}

void Tokenizer::readQuotedRexxScript( string &result )
     throw(  Tokenizer::UnexpectedChar
	   , Tokenizer::TooNearEof )

{
  passSpace();
  if( ! isOk() )
    throw TooNearEof(*this);

  if( lastchar != '"'  &&  lastchar != '\'' &&  lastchar != '`' )
    throw UnexpectedChar(*this);

  int quote = lastchar;
  
  result = "";
  while( isOk()	){
    lastchar = read();
    if( lastchar == quote  &&  (lastchar=read()) != quote )
      break;
    if( lastchar == '\r' )
      continue;
    if( lastchar == '\n' )
      result += '\r';
    result += char(lastchar);
  }
}

int Tokenizer::read()
{
  if( this->operator * () == '\n' ){
    lnum++;
    int ch=ins.get();
    if( ch == '#' ){
      for(;;){
	if( ! ins.good() )
	  return -1;
	if( (ch=ins.get()) == '\n' )
	  return '\n';
      }
    }
    return ch;
  }
  return ins.get();
}

int Tokenizer::readcont()
{
  if( ! ins.good() )
    throw TooNearEof(*this);
  return read();
}


void Tokenizer::readline( string &buffer ) throw( TooNearEof )
{
  int ch;

  buffer.erase();
  for(;;){
    if( ! ins.good() ){
      throw TooNearEof(*this);
    }
    if( (ch=ins.get()) == '\n' ){
      ++lnum;
      return;
    }
    buffer += char(ch);
  }
}


ostream &Tokenizer::UnexpectedChar::output( ostream &outs )
{
  return outs << "Unexpected Character `" << getChar() << '\'';
}
ostream &Tokenizer::UnexpectedWord::output( ostream &outs )
{
  return outs << "Unknown identifier `" << getWord() << '\'';
}
ostream &Tokenizer::EtcError::output( ostream &outs )
{
  return outs << messege << '.';
}
ostream &Tokenizer::ErrorObject::output( ostream &outs )
{
  return outs << "Syntax Error.";
}
ostream &Tokenizer::TooNearEof::output( ostream &outs )
{
  return outs << "Too near EOF.";
}
