// -*- c++ -*-
#include <streambuf.h>
#include <ostream.h>
#include <sys/winmgr.h>

class wm_streambuf : public streambuf {
  wm_handle wh;
  bool isBound;
public:
  explicit wm_streambuf( wm_handle p_wh ) : wh(p_wh) , isBound(true){}
  wm_streambuf() : isBound(false){}
  ~wm_streambuf(){}
  
  void attach( wm_handle p_wh ){ wh = p_wh; isBound=true; }
  streamsize xsputn( const char *str , streamsize len );
  int overflow(int c);
};

class wm_ostream : public ostream {
  mutable wm_streambuf sbuf;
public:
  wm_ostream() : ostream( &sbuf ) , sbuf() {}
  wm_ostream( wm_handle p_wh ) : ostream( &sbuf ) , sbuf( p_wh ){}
  wm_streambuf *rdbuf() const { return &sbuf; }

  void attach( wm_handle p_wh ){ sbuf.attach(p_wh); }
};
