#include <assert.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <string.h> /* for memset */
#include <stdlib.h> /* for _osmode */
#include <dos.h>    /* for int86 */
#include <sys/termio.h>
#include <termios.h>

#include "effetc.h"
#include "getline.h"

enum{ FIRST_CALLED = -255 };

static int tty= FIRST_CALLED ;
static struct termios orig,s;
static int raw_level=0;

void rawMode(void)
{
  if( _osmode == DOS_MODE )
    return;
  
  if( tty == FIRST_CALLED ){
    tcgetattr(tty=2,&s);
    orig = s;
  }
  /* �@�\�� off �ɂ��� */
  s.c_lflag &= ~(  IDEFAULT
		 | ICANON /* line editing */
		 | ECHO   /* echo input */
		 | ECHOK  /* echo CR/LF after VKILL */
		 | ISIG   /* Enable signal processing */
		 | ECHONL /* not support ? */
		 );
  /* �ȉ��̓�s�͓� */
  s.c_oflag |=  ( TAB3 | OPOST | ONLCR );
  s.c_oflag &= ~( OCRNL | ONOCR | ONLRET );

  /* �ꕶ���P�ʂŁA0�b�Ŕ��������� */
  s.c_cc[VMIN] = 1;
  s.c_cc[VTIME] = 0;

  setmode( 2 , O_BINARY );
  cfsetospeed( &s , B38400 );
  fcntl(tty,O_NONBLOCK);
  tcsetattr(tty,TCSADRAIN,&s);
}

/* �����I�ɁA�ʏ탂�[�h�ֈڍs���� */
void cockedMode(void)
{
  if( tty == 2  &&  _osmode != DOS_MODE )
    tcsetattr(tty,TCSADRAIN,&orig);
  raw_level = 0;
}  

void raw_mode(void)
{
  if( raw_level++ > 0 )
    return;
  rawMode();
}

void cocked_mode(void)
{
  if( --raw_level > 0 )
    return;
  cockedMode();
}

int get86key(void)
{
  if( _osmode == DOS_MODE ){
    /* DOS�ł�_read_kbd�ŁA�����̑��o�C�g�ڂ��擾�ł��Ȃ��B*/
    union REGS regs;
    regs.h.ah = 0x7;
    return _int86( 0x21, &regs , &regs ) & 0xFF ;
  }else{
    unsigned char key;
    if( tty == FIRST_CALLED ){
      raw_mode();
      atexit( &cocked_mode );
    }

#if 0
    for(;;){
      if( read( 0 , &key , sizeof(char)) == 1 )
	return key & 255;
      sleep(0);
    }
#else
    int rc;

    enum{ READ_INTR = -2 };
    assert( tty != FIRST_CALLED );

    do{
      if( isatty( tty ) ){
	fd_set readfds;

	FD_ZERO( &readfds );
	FD_SET(tty,&readfds );
	/* �t�@�C���n���h�����A�N�Z�X�\�ɂȂ�܂ő҂B*/
	if( select(tty+1,&readfds,NULL,NULL,NULL) == -1 )
	  return -1;
      }
      
      rc = read( tty , &key , sizeof(char) );
      if( rc==1 )
	return key & 255;

      if( rc < 0 )
	return -1;
      if( rc == 1 )
	return key & 255;
    }while( rc != 1 );
#endif
    return key & 0xFF;
  }
}

static int keybuf[16],left=0;

void ungetkey(int key)
{
  keybuf[ left++ ] = key;
}

int getkey(void)
{
  if( left > 0 )
    return keybuf[ --left ];

  int key=get86key();
  if( key == -1 )
    return 0;

  int ch = (key & 255);
  if( ch == 0 )
    ch = (get86key()|0x100);
  else if( isKanji(ch) )
    ch = ((ch << 8)|(get86key() & 0xFF));

  return ch;
}
