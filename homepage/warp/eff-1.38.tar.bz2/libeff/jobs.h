// -*- c++ -*-
#ifndef JOBS_H
#define JOBS_H
#include <stdlib.h>

#define INCL_WINSWITCHLIST

/* �����I�� PMInterface �N���X���Ă�ł��� */

class _SWBLOCK;
class _SWENTRY;

class Jobs {
  int count;
  _SWBLOCK *pswblock;
public:
  Jobs();
  ~Jobs(){ free(pswblock); }
  
  _SWENTRY &operator[] (int n);
  int N() const { return count; }
  
  void fg(int i);
  void bg(int i);
  void refresh();
  const char *getName(int i);
};

#endif
