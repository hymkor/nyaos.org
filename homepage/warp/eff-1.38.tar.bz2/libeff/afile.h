/* -*- c++ -*- */
#ifndef LIBEFF_AFILE_H
#define LIBEFF_AFILE_H

#include <string>
#include <vector>
#include "effetc.h"

struct _FILEFINDBUF4 ;
struct _FTIME ;
struct _FDATE ;
struct tm;

/* �t�@�C�����ێ��N���X */
class AFile {
public:
  /************************ �萔�E�N���X�錾 *************************/
  
  // �t�@�C�������萔.
  enum{
    ARCHIVED	= 0x20,	AND_ARCHIVED	= 0x2000, OR_ARCHIVED	= 0x20,
    DIRECTORY	= 0x10,	AND_DIRECTORY	= 0x1000, OR_DIRECTORY	= 0x10,
    VOLUME	= 0x80,	AND_VOLUME	= 0x800,  OR_VOLUME	= 0x8,
    SYSTEM	= 0x4,	AND_SYSTEM	= 0x400,  OR_SYSTEM	= 0x4,
    HIDDEN	= 0x2,	AND_HIDDEN	= 0x200,  OR_HIDDEN	= 0x2,
    READONLY	= 0x1,	AND_READONLY	= 0x100,  OR_READONLY	= 0x1,
    ALL = 0x37 ,
    ANDBIT = 8 ,
    ORBIT  = 0 ,
  };
  // �����ێ��N���X.
  struct Date{
    unsigned short year;
    unsigned char month,day,hour,minute,second;
    
    int compare( const Date &x ) const;

  public:
    // constructor and assignment.
    Date(){}
    Date( const Date &d ) : year(d.year) , month(d.month) , day(d.day)
      , hour(d.hour) , minute(d.minute) , second(d.second){}
    Date( const struct tm & );

    void set( const struct _FDATE & , const struct _FTIME & );
    Date &operator = (const Date &x ){
      year = x.year ; month = x.month   ; day = x.day;
      hour = x.hour ; minute = x.minute ; second = x.second;
      return *this;
    }
    Date &operator = (const struct tm &t );

    // getter.
    bool operator <  ( const Date &x ) const { return compare(x)<  0; }
    bool operator >  ( const Date &x ) const { return compare(x)>  0; }
    bool operator <= ( const Date &x ) const { return compare(x)<= 0; }
    bool operator >= ( const Date &x ) const { return compare(x)>= 0; }
    bool operator != ( const Date &x ) const { return compare(x)!= 0; }
    bool operator == ( const Date &x ) const { return compare(x)== 0; }
  };
  class Comparer;	// �t�@�C���\�[�g������p ��r�N���X.
  class List;		// �t�@�C���ꗗ�����N���X.
  class DirSave;	// �J�����g�f�B���N�g���Z�[�u & chdir.
private:
  string         name;
  unsigned long  size;
  unsigned short easize , attr ;
  Date		 create , access , write;
public:
  /********************** �R���X�g���N�^�E������Z�q *******************/
  AFile(){}
  AFile( const string &nm ) : name(nm) {}
  AFile( const string &nm , unsigned long sz , unsigned short at )
    : name(nm) , size(sz) , attr(at){}
  AFile( const AFile &x )
    : name(x.name) , size(x.size) , easize(x.easize) , attr(x.attr)
      , create(x.create) , access(x.access) , write(x.write){ }

  AFile &operator = (const AFile &x){
    name = x.name ; size = x.size ; easize = x.easize ; attr = x.attr ;
    create = x.create ; access = x.access ; write = x.write;
    return *this;
  }
  AFile &operator = (const struct _FILEFINDBUF4 &);

  void setName( const string &nm ){ name = nm; }
  void setSize( int s ){ size = s; }
  void setAttr( int a ){ attr = a; }
  void setEaSize( int e ){ easize = e; }
  void setCreatedDate ( const Date &cd ){ create = cd; }
  void setAccessedDate( const Date &ad ){ access = ad; }
  void setWrittenDate ( const Date &wd ){ write = wd; }
  
  /********************** �Q�b�^�[ *************************************/
  const string &getName() const { return name; }
  int getSize() const { return size; }
  int getAttr() const { return attr; }
  int getEaSize() const { return easize; }
  bool hasEa() const { return easize > 4 ; }
  const Date &whenCreated()  const { return create; }
  const Date &whenAccessed() const { return access; }
  const Date &whenWritten()  const { return write; }
  bool isDir()      const { return attr & DIRECTORY ; }
  bool isReadOnly() const { return attr & READONLY ; }
  bool isArchived() const { return attr & ARCHIVED  ; }
  bool isHidden()   const { return attr & HIDDEN; }
  bool isSystem()   const { return attr & SYSTEM; }

  /********************** �c�[�� ******************************/
  static bool isCurrentOrParent( const string &s );
  bool isCurrentOrParent() const{ return isCurrentOrParent(name); }
  
  static string makepath( const string &dir , const string &fname );
  string makepath( const string &dir )
    { return makepath( dir , name ); }
  static bool match( const char *pattern , const char *fname );
  bool match( const char *pattern )
    { return match( pattern , name.c_str() );  }
  static int f2b( const string &src , string &dst );
  static int b2f( const string &src , string &dst );
  static void make83name( char buffer[20] , const char *orgname );
  static int getFileSys(int drv);
  static int listing( vector<string> &src , vector<string> &dst , int width);
  static int explode( const char *path , vector<string> &array , char root);
};

class AFile::List {
  int status;
  unsigned long  handle , count;
  AFile fileinfo;
public:
  List( const string &path , int attr=AFile::ALL , const string &mask="*" );
  ~List();
  
  operator const void *() const { return status ? 0 : this; }
  int operator ! () const { return status; }
  
  List &operator++();
  void  operator++(int){ ++*this; }
  
  const AFile *operator->() const { return &fileinfo; }
  const AFile &operator *() const { return  fileinfo; }
};

class AFile::Comparer {
  int how2compare;
public:
  enum{
    NAME,
    CHANGE_TIME,
    LAST_ACCESS_TIME,
    SIZE,
    SUFFIX,
    MODIFICATION_TIME,
    NAME_IGNORE,
    NUMERIC,
    UNSORT,			    
    MASK    = 0xFF  ,
    
    REVERSE = 0x100 ,
    DIRTOP  = 0x200 ,
  };
  Comparer( int opt ) : how2compare( opt ){}

  bool operator() (const AFile &x , const AFile &y ) const;
};  

typedef AFile::List Dir2;

bool fnameMatch( const char *pattern , const char *fname );

class AFile::DirSave {
  string orgdir;
  char orgdrive;
public:
  int pushd( const string &path );
  int popd();
  DirSave() : orgdrive(-1){}
  DirSave( const string &path ) : orgdrive(-1) { pushd(path); }
  ~DirSave()
    { if( orgdrive != -1 ) popd(); }

  operator const void* () const { return orgdrive != -1 ? this : 0 ; }
  bool operator ! () const { return orgdrive == -1; }

  static int getcwd( string &curdir );
};

#endif
