/* -*- c++ -*- */
#ifndef LIBEFF_CANNA_H
#define LIBEFF_CANNA_H

#include <canna/jrkanji.h>
#include <string>

class ChrBuffer;

void euc2sjis1(char s1,char s2,char &d1,char &d2);
void euc2sjis( const char *sp,ChrBuffer &);
string euc2sjis( const char *sp);
inline string euc2sjis( const string &x )
{  return euc2sjis(x.c_str()) ;  }

inline bool isEucKana(int ch)
{  return (ch & 255) == 0x8E;  }
inline bool isEucKanji(int ch)
{  return ch & 0x80;  }

class Canna {
  class AutoSem; friend class AutoSem;
public:
  enum LoadFlag{ OK , NG , YET };
private:
  static LoadFlag loadflag;
  static int (*dllJrKanjiString)(int,int,char*,int,jrKanjiStatus*);
  static int (*dllJrKanjiControl)(int,int,char*);

  // Lock �̂��Ă��Ȃ����͔̂r����������Ȃ�.
  static int control(int req,char *arg,int context_id=0)
    {  return (*dllJrKanjiControl)( context_id , req , arg );  }
  static int initialize( char ***array , int context_id=0 )
    {  return control( KC_INITIALIZE , (char*)&array , context_id );  }
  static int setInitFname0( char *fn , int context_id=0)
    {  return control( KC_SETINITFILENAME , fn , context_id ); }
  static void requestSem();
  static void releaseSem();

  class AutoSem{
  public:
    AutoSem(){ requestSem(); }
    ~AutoSem(){ releaseSem(); }
  };

  jrKanjiStatus status;
public:
  static LoadFlag isLoaded(){ return loadflag; }
  static void killcanna(){ loadflag = NG ; }
  static void init(void *arg=0);
  static void initbg();
  static void release();
  static int controlLock(int req ,char *arg, int context_id=0);

  int convert(int key,char *buffer,int size,int context_id=0);
  int kakutei(char *buffer,size_t size);

  // ���[�h�\���֌W���|�[�g�֐�.
  const char *modeStr() const { return (const char*)status.mode; }
  int hasModeStr() const { return status.info & KanjiModeInfo; }

  // ���ϊ�������֌W���|�[�g�֐�.
  const char *echoStr() const { return (const char *)status.echoStr; }
  size_t echoLength() const { return status.length; }
  size_t echoRevPos() const { return status.revPos; }
  size_t echoRevLen() const { return status.revLen; }

  // �ϊ���⃊�X�g�֌W���|�[�g�֐�.
  const char *glineStr() const { return (const char *)status.gline.line; }
  size_t glineLength() const { return status.gline.length; }
  size_t glineRevPos() const { return status.gline.revPos; }
  size_t glineRevLen() const { return status.gline.revLen; }
  int hasGline() const { return status.info & KanjiGLineInfo; }
};

#endif
