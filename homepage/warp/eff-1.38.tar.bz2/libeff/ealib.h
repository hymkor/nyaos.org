/* -*- c++ -*- */
#ifndef EALIB_H
#define EALIB_H

#include <string>
#include <vector>

#ifndef numof
#  define numof(A) (sizeof(A)/sizeof((A)[0]))
#endif

enum{ 
  EA_ASCIITYPE = 0xFFFD,
  EA_MULTITYPE = 0xFFDF,
};

char *get_ascii_ea(  const char *fname , const char *eatype );
char **get_multiascii_ea( const char *fname  , const char *eatype );
void free_pointors(char **p);
int set_ascii_ea(const char *fname,const char *eatype,const char *value );
int set_multiascii_ea(  const char *fname,const char *eatype
		      , const char **values);
int unset_ea( const char *fname , const char *eatype );



class ExtAttr {
  class EACover;
  class MultiPointor;
public:
  static string getTextEA(  const string &fname , const string &eatype );
  static int    getTextEA(  const string &fname , const string &eatype 
			  , vector <string> &ealist );

  static string getLongname( const string &fname )
    { return getTextEA( fname , ".LONGNAME" ); }
  static string getSubject(  const string &fname )
    { return getTextEA( fname , ".SUBJECT" ); }
  static int getComments( const string &fname , vector<string> &comments )
    { return getTextEA( fname , ".COMMENTS" , comments ); }

  static string getOneComment( const string &fname ){
    string result=getSubject(fname);
    if( result.empty() ){
      vector<string> comments;
      if( getComments( fname , comments ) >= 1 )
	result=comments[0];
    }
    return result;
  }
};


#endif
