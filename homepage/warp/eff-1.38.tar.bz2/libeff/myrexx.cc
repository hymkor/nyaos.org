#include <cstdlib>
#include <cstdio>
#include <string>
#include <cctype>
#include <map>
#include <algorithm>
#include "alloca.h"

#define INCL_RXSUBCOM
#define INCL_RXFUNC
#include <os2.h>

#include "myrexx.h"

static const unsigned char rexxEnvironment[]="LIBEFF";

static int (*subcommand)( const char *cmdline ) = &system;

static ULONG subCommandFilter(  PRXSTRING source
			      , PUSHORT flags
			      , PRXSTRING result )
{
  if( (*subcommand)((const char *)source->strptr)==0 ){
    *flags = RXSUBCOM_OK;
  }else{
    *flags = RXSUBCOM_ERROR;
  }
  memcpy( result->strptr , "0" , 2 );
  result->strlength = 1;
  return 0;
}

void MyRexx::registSubCommand( int (*handler)(const char *s) )
{
  subcommand = handler;
  RexxRegisterSubcomExe(  rexxEnvironment
			, (PFN)&subCommandFilter , 0 );
}

typedef int (*rexx_function_t)(int argc,const string *argv,string &result);
static map<string,rexx_function_t> funclist;

static ULONG trueHandler(  const unsigned char *name
			 , unsigned long argc
			 , RXSTRING argv[]
			 , const unsigned char *queue
			 , PRXSTRING pResult )
{
  int rc=-1;
  string result( "ERROR" );
  map<string,rexx_function_t>::iterator itr
    =funclist.find( string((const char*)name) );
  
  if( itr != funclist.end() ){
    string *args=new string[ argc ];
    for(unsigned int i=0;i<argc;i++)
      args[ i ].assign( (const char*)argv[i].strptr , argv[i].strlength );
  
    rc = (*itr->second)(argc,args,result);
    delete[]args;
  }
  if( (pResult->strlength = result.length()) >= 256 ){
    if( DosAllocMem(  (void**)&pResult->strptr
		    , result.length()+1
		    , PAG_WRITE | PAG_READ | PAG_COMMIT ) != 0 )
      return ~0;
  }
  memcpy( pResult->strptr , result.c_str() , result.length()+1 );
  return (ULONG)rc;
}

void MyRexx::registFunction( const char *name , rexx_function_t handler )
{
  RexxRegisterFunctionExe( (PSZ)name , &trueHandler ) ;
  string s=name;
  transform( s.begin() , s.end() , s.begin() , toupper );
  funclist[ s ] = handler;
}

int MyRexx::operator() ( const char *argv0 ,... )
{
  vector<string> argv;

  argv.push_back( argv0 );
  
  va_list vp;
  va_start(vp,argv0);
  const char *p;
  while( (p=va_arg(vp,const char*)) != 0 )
    argv.push_back( p );
  
  va_end(vp);
  return (*this)( argv );
}

int MyRexx::operator() (vector<string> &args )
{
  /* �p�����[�^�̗p�� */
  RXSTRING *argv = (RXSTRING*) alloca( args.size()*sizeof(RXSTRING) );
  
  for(size_t i=0 ; i<args.size() ;i++ ){
    argv[i].strptr    = (PUCHAR)args[i].c_str();
    argv[i].strlength = args[i].length();
  }

  int rv = (*this)( args.size() , argv );
  return rv;
 
}

int MyRexx::operator() (int argc , const string args[] )
{
  /* �p�����[�^�̗p�� */
  RXSTRING *argv = (RXSTRING*) alloca( argc * sizeof(RXSTRING) );
  for(int i=0;i<argc;i++){
    argv[i].strptr    = (PUCHAR)args[i].c_str();
    argv[i].strlength = args[i].length();
  }

  int rv = (*this)( argc , argv );
  return rv;
}

int MyRexx::operator() (int argc , RXSTRING *argv )
{
  int rv=0;

  /* �߂�l�̓�����̗̂p�� */
  short rxResultNum;
  RXSTRING rxResult;
  rxResult.strptr    = 0;
  rxResult.strlength = 0;

  if( rexxCode.empty() ){
    /* �t�@�C���ǂݍ��݂̏ꍇ */
    rv = RexxStart(  argc
		   , argv
		   , (PUCHAR)title.c_str()
		   , 0
		   , rexxEnvironment
		   , RXCOMMAND	// or RXSUBROUTINE , RXCOMMAND or RXFUNCTION
		   , 0			// RXSYSEXIT
		   , &rxResultNum
		   , &rxResult
		   );
  }else{
    /* �C�����C���R�[�h�̏ꍇ */
    
    /* �R�[�h�̗p�� */
    RXSTRING proc[2];
    proc[0].strptr    = (PUCHAR)rexxCode.c_str();
    proc[0].strlength = rexxCode.length();
    proc[1].strptr    = (PUCHAR)compiledCode;
    proc[1].strlength = compiledLength;
    
    rv = RexxStart(  argc
		   , argv
		   , (PUCHAR)title.c_str()
		   , proc
		   , rexxEnvironment
		   , RXFUNCTION		// or RXSUBROUTINE , RXCOMMAND.
		   , 0			// RXSYSEXIT
		   , &rxResultNum
		   , &rxResult
		   );
  }

  /* �߂�l�� string �� */
  if( rxResult.strptr != 0 ){
    result.assign( (char*)rxResult.strptr , rxResult.strlength );
    DosFreeMem( rxResult.strptr );
  }
  return rv < 0 ? rv : rxResultNum;
}

MyRexx::~MyRexx()
{
  if( compiledCode != 0 )
    DosFreeMem( compiledCode );
}


#if 0
int main()
{
#if 0
  MyRexx inlineRexx("<Inline Rexx Script>",
		    "do i=1 to arg()\r\n"
		    "  say '///'|| arg(i) || 'ufufu'\r\n"
		    "end\n"
		    "return 'ahaha'\r\n"
		    );
#endif
  MyRexx inlineRexx(".\\temp.cmd");
  int rv=inlineRexx( "hogehoge","uhauah","ohoho",0 );
  cout << inlineRexx.getResult() << ": " << rv << endl;
  return 0;
}
#endif
