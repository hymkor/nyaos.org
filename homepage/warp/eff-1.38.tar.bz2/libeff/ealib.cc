#include <sys/ea.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "ealib.h"

// #define DEBUG2(x) (x)
#define DEBUG2(x) /**/

union MultiPtr {
  void *value;
  unsigned char *byte;
  unsigned short *word;
};


class EACover {
  struct _ea ea;
public:
  struct Failure{};

  EACover( const char *fname , const char *eatype ) throw(Failure){ 
    ea.value = NULL ;  ea.size = 0;
    if(    _ea_get( &ea , fname , 0 , eatype ) != 0
       || ea.size <= 0  || ea.value == NULL )
      throw Failure();
  }

  ~EACover(){  _ea_free( &ea ); }

  int   getSize()  const { return ea.size; }
  void *getValue() const { return ea.value; }
};

class MultiPointor {
  union Ptr{
    const void  *set;
    const char  *byte;
    const short *word;

    Ptr(const void *p) : set(p) {} 
  }ptr;
  int left;
public:
  struct OutOfRegion{};

  MultiPointor(const void *p,int L)
    : ptr(p) , left(L) {} 
  MultiPointor(const EACover &ea)
    : ptr(ea.getValue()) , left(ea.getSize()) {}

  int readw() throw(OutOfRegion){
    if( (left-=2) < 0 )
      throw OutOfRegion();
    return 0xFFFF & *ptr.word++;
  }
  char *readstr() throw(OutOfRegion);
  int getLeft() const { return left; }
};


char *MultiPointor::readstr() throw(MultiPointor::OutOfRegion)
{
  int size=readw();
  if( (left -= size) < 0 )
    throw OutOfRegion();
  
  char *rv=(char*)malloc( size+1 );
  if( rv == NULL )
    throw MultiPointor::OutOfRegion();

  memcpy( rv , ptr.byte , size );
  rv[ size ] = '\0';
  
  ptr.byte += size;
  return rv;
}



/* ASCII �^�C�v�̂d�`(.LONGNAME / .SUBJECT)���擾����B
 *	fname �c �t�@�C����
 *	eatype �c EA�̑�����(".LONGNAME" �� ".SUBJECT")
 * return
 *	����ꂽ EA (char *)
 */
char *get_ascii_ea(  const char *fname , const char *eatype )
{
  try{
    DEBUG2( fputs("make ea\n",stderr) );
    EACover ea(fname,eatype);

    DEBUG2( fputs("make ptr\n",stderr) );
    MultiPointor ptr(ea);

    DEBUG2( fputs("readw\n",stderr) );
    if( ptr.readw() != EA_ASCIITYPE ){
      DEBUG2( fputs("hogehogea\n",stderr) );
      throw MultiPointor::OutOfRegion();
    }

    DEBUG2( fputs("readstr\n",stderr) );
    return ptr.readstr();
  }catch(...){
    DEBUG2( fputs("caught\n",stderr) );
    return NULL;
  }
}

void free_pointors(char **p)
{
  if( p != NULL ){
    for(char **q=p ; *q != NULL ; q++ ){
      if( *q )
	free(*q);
    }
    free(p);
  }
}

/* �g������ .COMMENT �̓��e�𓾂�B
 *	fname ���������t�@�C���̖��O
 * return
 *	�����l���|�C���^�z��ŕԂ��B
 */
char **get_multiascii_ea( const char *fname  , const char *eatype )
{
  try{
    EACover ea( fname , eatype );
    MultiPointor ptr(ea);

    if( ptr.readw() != EA_MULTITYPE )
      throw MultiPointor::OutOfRegion();
    
    (void)ptr.readw(); /* �R�[�h�y�[�W��ǂ݂Ƃ΂� */
    int n=ptr.readw(); /* �e�[�u���T�C�Y */
    if( n <= 0 )
      return NULL;
    
    char **table=(char**)malloc( sizeof(char*)*(n+1) );
    if( table == NULL )
      return NULL;
    
    // NULL �ŏ�����.
    for(int i=0 ; i<n+1 ; i++ )
      table[ i ] = NULL;
    
    try{
      for(int i=0;i<n;i++){
	if( ptr.readw() != EA_ASCIITYPE )
	  throw MultiPointor::OutOfRegion();

	table[i] = ptr.readstr();
      }
      return table;
    }catch(...){
      free_pointors( table );
      return NULL;
    }
  }catch(...){
    return NULL;
  }
}

/* ASCII �^�C�v�̊g��������ݒ肷��B
 *	fname	�g��������ݒ肷��t�@�C���̃t�@�C����
 *	eatype	�g�������̃^�C�v(".SUBJECT"��)
 *	value	�ݒ肷����e�BNULL �̏ꍇ�A���̑������폜����B
 */
int set_ascii_ea(  const char *fname 
		 , const char *eatype 
		 , const char *value )
{
  struct _ea eavalue;

  eavalue.flags = 0;
  if( value == 0 || value[0] == '\0' ){
    /* EA �̒l������ */
    return _ea_remove( fname , 0 , eatype );
  }

  MultiPtr ptr;
  
  int len = strlen(value);
  ptr.value = eavalue.value = alloca( (eavalue.size = len+4)+1 );
  /* 4 �̓w�b�_�̃o�C�g�� */
  
  *ptr.word++ = 0xFFFD;
  *ptr.word++ = len;
  memcpy(ptr.value , value , len );
  return _ea_put( &eavalue , fname , 0 , eatype );
}


int set_multiascii_ea(  const char *fname 
		      , const char *eatype
		      , const char **values )
{
  int size=6; /* == �����}�[�N�{�R�[�h�y�[�W�{�d�`��  */
  int n=0;
  for(const char **p=values; *p != NULL ; p++ ){
    size += strlen(*p) + 4; /* 4 = �����}�[�N�{�R�[�h�y�[�W */
    ++n;
  }
  if( n==0 )
    return 0;
  
  struct _ea eavalue;
  MultiPtr ptr;
  
  eavalue.flags = 0;
  ptr.value = eavalue.value = alloca( (eavalue.size = size ) + 1 );
  
  *ptr.word++ = EA_MULTITYPE;
  *ptr.word++ = 0; /* code page */
  *ptr.word++ = n; /* EA �̐� */
  for(const char **p=values ; *p != NULL ; p++ ){
    *ptr.word++ = EA_ASCIITYPE;
    unsigned short *toSize=ptr.word++;
    *toSize = 0;
    for(const char *sp=*p ; *sp != '\0' ; ++sp ){
      *ptr.byte++ = *sp;
      ++*toSize;
    }
  }
  return _ea_put(&eavalue,fname,0,eatype);
}

int unset_ea( const char *fname , const char *eatype )
{
  return _ea_remove( fname , 0 , eatype );
}
