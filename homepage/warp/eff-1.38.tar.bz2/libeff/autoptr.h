/* -*- c++ -*- */

#ifndef AUTOPTR_H
#define AUTOPTR_H

template <class C> class autoptr_t {
  C *pointor;
public:
  C *operator -> () const { return pointor; }
  operator C* () const { return pointor; }
  
  autoptr_t() : pointor(0) { }
  explicit autoptr_t(autoptr_t &a){
    pointor = a.pointor;
    a.pointor = 0;
  }
  explicit autoptr_t(C *p) : pointor(p){ }
  ~autoptr_t(){ delete pointor; }

  autoptr_t &operator = (autoptr_t &a){
    if( &a != this ){
      delete pointor;
      pointor = a.pointor;
      a.pointor = 0;
    }
    return *this;
  }
  autoptr_t &operator = (C *p){
    if( p != pointor ){
      delete pointor ; pointor = p ;
    }
    return *this;
  }
};

#endif
