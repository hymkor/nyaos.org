#include "profile.h"
#define INCL_WINSHELLDATA
#include <os2.h>

void IniProfile::open( unsigned long hab , const string &fname )
{
  hini = PrfOpenProfile( hab , (PSZ)fname.c_str() );
}

void IniProfile::close()
{
  PrfCloseProfile(hini);
  hini = -1;
}

void IniProfile::listUp()
{
  char buffer[ 1024 ];
  long unsigned int size=sizeof(buffer);
  map<string,App*> profiles;

  if( PrfQueryProfileData(  hini
			  , NULL // �A�v������
			  , NULL // �L�[�͖���
			  , ""   // ��̏ꍇ�̒l
			  , buffer
			  , &size
			  ) == TRUE ){
    const char *sp=buffer;
    while( sp != NULL  &&  *sp != '\0' ){
      string appName( sp );
      sp += appName.length() + 1;
      
      apps[ appName ] = new App(appName);
    }
  }
}

void IniProfile::App::listUp(long hini)
{
  ULONG length;
  char buffer[ 1024 ];
  PrfQueryProfileString(  hini
			, getName()
			, NULL
			, ""
			, buffer
			, sizeof(buffer)
			, &length );
  
  const char *sp=buffer;
  while( sp != NULL  &&  *sp != '\0'  &&  sp < buffer+length ){
    string keyName( sp );
    sp += keyName.length() + 1;
    
    char value[ 1024 ];
    int len;
    PrfQueryProfileString(  hini
			  , getName()
			  , keyName.c_str()
			  , ""
			  , value
			  , sizeof(value)
			  , &len );
    keys[ keyName ] = new StringProfile(keyName,value);
  }
}

IniProfile::App::~App()
{
  for(  map<string,Key*>::iterator itr=keys.begin()
      ; itr != keys.end()
      ; ++itr){
    delete itr->second;
    itr->second = NULL;
  }
}
