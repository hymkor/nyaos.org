#include <cstdio>
#include <alloca.h>
#include "wmostream.h"

ios::streamsize wm_streambuf::xsputn( const char *str , ios::streamsize len )
{
  char *s=(char*)alloca(len+1);
  memcpy( s , str , len );
  s[len] = '\0';
  if( isBound ){
    wm_puts( wh , s );
    wm_cursor( wh );	// move cursor to here.
    wm_cvis( wh , 1 );	// cursor on
  }else{
    fputs( s , stdout );
  }
  return len;
}

int wm_streambuf::overflow(int c)
{
  char *p=pbase();
  if( p != 0 )
    xsputn( p , pptr()-pbase() );
  
  if( c != EOF ){
    if( isBound )
      wm_putc( wh , c );
    else
      putchar( c );
  }
  if( isBound ){
    wm_cursor( wh );	// move cursor to here
    wm_cvis( wh , 1 );	// cursor on
  }
  return 0;
}

