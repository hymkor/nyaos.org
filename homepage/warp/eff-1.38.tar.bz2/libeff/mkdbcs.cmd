/* make dbcstbl.c */

SAY '/* DBCS table initialized as Japanese */'
SAY 'char dbcsTable[256+128] = {'
line = "  "
j=0;
DO i=-128 TO 255
    c = D2C(i+256,1)
    x = '00'x

    IF ('81'x <= c & c <= '9F'x )|( 'E1'x <= c & c<= 'FC'x ) THEN
	x = BITOR(x,'01'x)

    IF 'a' <= c & c <= 'z' THEN
	x = BITOR(x,'02'x)
    
    IF 'A' <= c & c <= 'Z' THEN
	x = BITOR(x,'04'x)
    
    IF '0' <= c & c <= '9' THEN
	x = BITOR(x,'08'x)

    IF c==' ' | ('09'x <= c & c <= '0D'x ) THEN
	x = BITOR(x,'10'x)
    
    line = line || "0x"||D2X(C2D(x),2) ||","
    
    j = j + 1
    IF j >= 8 THEN DO 
	SAY line "/* 0x"|| D2X(i-7,2) "*/"
	line = "  "
	j = 0
    END
END
IF j <> 0 THEN 
    SAY line
SAY '};'
    

