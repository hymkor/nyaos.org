#undef DEBUG
#include "VBuffer.h"
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <sys/video.h>
#include <sys/winmgr.h>
#include "effetc.h"

#ifdef DEBUG
#  define DEBUG1(x) (x)
#else
#  define DEBUG1(x)
#endif

void VBuffer::reset()
{
  if( buffer != 0 )
    _tfree( buffer );
  buffer = 0;
  max = count = 0;
}

int VBuffer::setmem()
{
  if( buffer == 0 ){
    buffer = (char(*)[2])_tmalloc( 2*(max += UNITSIZE) );
  }else{
    buffer = (char(*)[2])_trealloc( buffer , 2*(max += UNITSIZE) );
  }
  if( buffer == 0 ){
    DEBUG1(fputs("(VBuffer::setmem) malloc/realloc error\n",stderr));
    max = 0;
    return -1;
  }
  return 0;
}

VBuffer &VBuffer::operator << ( const char *s )
{
  if( s == NULL )
    return *this;

  while( *s != '\0' ){
    if( *s == '\t' ){
      do{
	if( count >= max && setmem() == -1 )
	  return *this;

	buffer[count][0] = ' ';
	buffer[count][1] = attr;
	count++;
      }while( count % 8 != 0 );
      ++s;
    }else if( *s != -1 ){

      /* ���ʂɕ�����ǉ����� */
      if( count >= max  &&  setmem() == -1 )
	return *this;

      buffer[count][0] = *s++;
      buffer[count][1] = attr;
      count++;
    }else{
      /* 0xFF = ������ύX���� */
      attr = *++s;
      ++s;
    }
  }
  return *this;
}

VBuffer &VBuffer::operator << ( char ch )
{
  if( count >= max  &&  setmem() == -1 )
    return *this;

  if( ch == '\t' ){
    do{
      (*this) << ' ';
    }while( getLength() % 8 != 0 );
  }else{
    buffer[count][0] = ch;
    buffer[count][1] = attr;
    count++;
  }
  return *this;
}  

void VBuffer::pack()
{
  char (*newBuffer)[2] = (char(*)[2])_trealloc( buffer , (max = count)*2 );
  if( newBuffer != NULL )
    buffer = newBuffer;
}

VBuffer &VBuffer::putNumber(int num,int width,char fillchar,char sign)
{
  if( num < 0 ){ /* �}�C�i�X */
    return putNumber( -num , width , fillchar , '-' );
  }else if( num >= 10 ){
    putNumber( num / 10 , width-1 , fillchar , sign );
    return *this << "0123456789"[ num % 10 ];
  }else{
    if( sign != '\0' )
      width -= 2;
    else
      --width;
    
    while( width-- > 0 )
      *this << (char)fillchar;

    if( sign != '\0' )
      *this << sign;

    return *this << "0123456789"[ num ];
  }
}


VBuffer &VBuffer::printf( const char *s,... )
{
  char buffer[512];

  va_list vp;
  va_start(vp,s);
  
  vsnprintf( buffer , sizeof(buffer)-1 , s , vp );

  va_end(vp);
  return *this << buffer;
}

void VBuffer::putat(int x,int y)
{
  v_putline( (const char*)buffer , x , y , count );
}

void VBuffer::putatPart(int x,int y,int start,int length,int fillchar)
{
  if( length == -1 )
    length = count;
  int len = length;
  
  char *partbuf=(char*)_tmalloc( len * 2 );
  if( partbuf == NULL ){
    DEBUG1( fputs("(VBuffer::putatPart) _tmalloc failed\n",stderr ));
    return;
  }

  int column=0;
  char *dp=partbuf;
  bool afterkanji=false; // ������2byte�ڂȂ�΁Atrue.

  /* �\���������ŏ���1�������A������2byte�ڂ��ǂ������`�F�b�N���邽�߂ɁA
   * �ŏ�����A����/�񊿎������Ă��� */
  while( column < count  &&  start > 0 ){
    if( afterkanji )
      afterkanji = false;
    else if( isKanji( buffer[column][0] & 255) )
      afterkanji = true;
    ++column;
    --start;
  }
  /* �\������ŏ���1�������A�����̌㔼�o�C�g�Ȃ�΋󔒂Œu�������� */
  if( afterkanji ){
    *dp++ = ' ';
    *dp++ = buffer[column++][1];
    --len;
    afterkanji = false;
  }

  /* ���ۂɎw�肵���͈͂�\�����邪�A�Ō�� 1���������A�����̋����ʂ�
   * �`�F�b�N�ׂ̈ɁA�c���Ă���
   */
  while( column < count-1  &&  len > 1 ){
    if( afterkanji )
      afterkanji = false;
    else if( isKanji(buffer[column][0] & 255 ) )
      afterkanji = true;

    *dp++ = buffer[column  ][0];
    *dp++ = buffer[column++][1];
    --len;
  }
  if( column < count ){
    /* �Ō�� 1����������1byte�ڂȂ�΁A�󔒂ɒu�������� */
    if( !afterkanji  &&  isKanji( buffer[column][0] & 255 ) ){
      *dp++ = ' ';
    }else{
      *dp++ = buffer[column][0];
    }
    *dp++ = buffer[column++][1];
    --len;
  }
  
  while( len > 0 ){
    *dp++ = fillchar;
    *dp++ = attr;
    --len;
  }
  v_putline( (const char *)partbuf , x , y , length );
  _tfree(partbuf);
}
