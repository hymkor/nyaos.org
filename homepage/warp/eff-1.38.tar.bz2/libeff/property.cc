#include "property.h"

Property Property::root("root");

Property &Property::operator[]( const string &key )
{
  size_t dot=key.find('.');
  if( dot != string::npos ){
    // �L�[���u.�v���܂�ł���ꍇ:���̊K�w������ɌĂяo��.
    if( key.length() <= dot+1 ){
      // �u.�v�̌�Ɉꕶ���������ꍇ:�u.�v�𖳎�����.
      return (*this)[ key.substr(0,dot) ];
    }
    return (*this)[ key.substr(0,dot) ][ key.substr(dot+1) ];
  }
  if( child == 0 ){
    child = new Properties;
  }
  Properties::iterator itr=child->find(key);
  if( itr == child->end() ){
    Property *result=new Property( key );
    (*child)[ key ] = result;
    return *result;
  }else{
    return *itr->second;
  }
}

Property::~Property()
{
  if( child != 0 ){
    for( Properties::iterator itr=child->begin() ; itr!=child->end() ; ++itr ){
      delete itr->second;
      itr->second = NULL;
    }
    delete child;
  }
}

void Property::print(ostream &os , const string &at)
{
  string me = at + name();

  os << me << "=" << value() << endl;
  for(  Properties::iterator itr=child->begin()
      ; itr != child->end() ; ++itr ){
    itr->second->print( os , me+'.' );
  }
}


bool Property::boolean()
{
  if(   value().empty()     || value() == "0"
     || value() == "false"  || value() == "nil" )
    return false;
  return true;
}
