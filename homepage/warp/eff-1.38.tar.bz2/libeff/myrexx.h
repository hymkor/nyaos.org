/* -*- c++ -*- */
#ifndef LIBEFF_MYREXX_H
#define LIBEFF_MYREXX_H

#include <string>
#include <vector>
#include <cstdarg>

class _RXSTRING;

class MyRexx {
  string title;
  string rexxCode;
  void *compiledCode;
  unsigned long compiledLength;
  string result;

  int operator() ( int argc , _RXSTRING *args );
public:
  MyRexx( const string &filename )
    : title(filename) , compiledCode(0) , compiledLength(0){}
  
  MyRexx( const string &title_ , const string &inlineCodes )
    : title(title_) , rexxCode(inlineCodes) , compiledCode(0) 
      , compiledLength(0){}
  ~MyRexx();

  int operator() ( const char *argv0 ,... );
  int operator() ( int argc , const string *args );
  int operator() ( vector<string> &args );
  
  const string &getResult() const { return result; }
  const string &getTitle() const { return title; }
  unsigned long getCompiledSize() const { return compiledLength; }

  static void registSubCommand( int (*handler)(const char *s) );
  static void registFunction(  const char *name
			     , int (*handler)(  int argc
					      , const string argv[]
					      , string &result ) );
};

#endif
