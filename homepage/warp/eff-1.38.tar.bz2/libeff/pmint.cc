/* �o�l�֌W�̃v���O����
 *
 */

#define INCL_WIN
#define INCL_DOSPROCESS

#include <os2.h>
#include "pmint.h"

static HAB hab=0;
static HAB hmq;
static bool initialized=false;

/* VIO�v���O��������A�����I�� PM �A�v���P�[�V�����ɉ�����
 * ����ɂ���āAPM �̃N���b�v�{�[�h�̓ǂݏ������\�Ƃ���B
 */
int PMInterface::init(void *p)
{
  if( !initialized ){
    initialized = true;
    
    PTIB  ptib = NULL;
    PPIB  ppib = NULL;
    
    APIRET rc = DosGetInfoBlocks(&ptib, &ppib);
    if (rc != 0)
      return rc;
    ppib->pib_ultype = PROG_PM;
    hab = WinInitialize(0);
    hmq = WinCreateMsgQueue(hab, 0);
    if (hmq == NULLHANDLE)
      return rc;
  }
  if( p != 0 )
    *(HAB *)p = hab;
  return 0;
}

void PMInterface::writeClipBoard( const char *s )
{
  if( !initialized )
    init();

  int len=strlen(s);

  char *sharemem;
  if( DosAllocSharedMem(  (void**) &sharemem
			, NULL
			, (ULONG) len+1
			, PAG_COMMIT | PAG_READ | PAG_WRITE
			| OBJ_TILE | OBJ_GIVEABLE ) )
    return;

  strcpy( sharemem , s );
  
  WinOpenClipbrd(hab);
  WinSetClipbrdOwner(hab,NULLHANDLE);
  WinEmptyClipbrd(hab);
  WinSetClipbrdData( hab , (ULONG)sharemem , CF_TEXT , CFI_POINTER );
  WinCloseClipbrd(hab);
}

const char *PMInterface::readClipBoard()
{
  if( !initialized )
    init();

  WinOpenClipbrd( hab );
  WinSetClipbrdOwner(hab,NULLHANDLE);
  ULONG	ulFmtInfo;
  if( WinQueryClipbrdFmtInfo( hab, CF_TEXT, &ulFmtInfo ) ){
    return (char*)WinQueryClipbrdData( hab , CF_TEXT );
  }else{
    return NULL;
  }
}
