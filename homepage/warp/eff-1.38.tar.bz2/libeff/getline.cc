#undef DEBUG
#include <cctype>
#include <cstdlib>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <algo.h>

#include <sys/kbdscan.h>

#include "effetc.h"
#include "getline.h"
#include "afile.h"

#ifdef DEBUG
#  define DEBUG1(x) (x)
#else
#  define DEBUG1(x)
#endif

enum{
  UNIT_BUFSIZE = 40 ,
  INIT_BUFSIZE = 160,
};

/* ���[���[�`�� */
void GetLine::makeroom(int at,int size)
{
  /* �o�b�t�@�T�C�Y���������悤�ł���΁A�L���� */
  if( len+size > max ){
    max = len+size+UNIT_BUFSIZE;
    strbuf = (char*)realloc( strbuf, max );
    atrbuf = (char*)realloc( atrbuf, max );
    assert( strbuf != NULL  &&  atrbuf != NULL );
  }
  
  for(int i=len-1 ; i >= at ; i-- ){
    strbuf[ i+size ] = strbuf[ i ];
    atrbuf[ i+size ] = atrbuf[ i ];
  }
  len += size;
}

void GetLine::delroom(int at,int size)
{
  for(int i=at;i<len;i++){
    strbuf[ i ] = strbuf[ i+size ];
    atrbuf[ i ] = atrbuf[ i+size ];
  }
  len -= size;
}

/* �J�[�\���ȍ~���ĕ`�� */
void GetLine::repaint_after(int rm=0)
{
  int bs=0;
  for(int i=pos;i<len;i++){
    putchr( strbuf[ i ] );
    ++bs;
  }
  
  while( rm-- > 0 ){
    putchr( ' ' );
    ++bs;
  }
  putbs( bs );
}

/* �J�[�\����̒P��͈͎̔擾.
 * out:
 *	at - �P��̐擪
 *	size - �P��̒���
 * return:
 *	�����񎩐g
 */
string GetLine::current_word(int &at,int &size)
{
  int j=0;
  do{
    while( isspace(strbuf[j] & 255) &&  j < pos )
      ++j;
    at = j;
    while( !isspace(strbuf[j] & 255) && j < pos )
      ++j;
  }while( j < pos );
  size = j - at;
  
  return string( strbuf+at , size );
}

/* -----------------
 * �L�[�o�C���h�֌W
 * ----------------- */

GetLine::Status GetLine::enter(int){       return ENTER;    }

GetLine::Status GetLine::cancel(int key)
{
  if( len > 0 ){
    erase_all( key );
    return CONTINUE;
  }
  return CANCEL;
}


GetLine::Status GetLine::do_nothing(int){  return CONTINUE; }

GetLine::Status GetLine::insert(int key)
{
  int upperbyte=(key >> 8) & 255;

  if( upperbyte == 1 ){
    return CONTINUE;
  }else if( upperbyte != 0 ){
    /* DBCS���� */
    makeroom(pos,2);
    strbuf[ pos   ] = upperbyte;
    atrbuf[ pos++ ] = DBC1ST;
    putchr( upperbyte );
    
    strbuf[ pos   ] = key;
    atrbuf[ pos++ ] = DBC2ND;
    putchr( key & 0xFF );
  }else{
    makeroom(pos,1);
    strbuf[ pos   ] = key;
    atrbuf[ pos++ ] = SBC;
    putchr( key );
  }
  repaint_after();
  return CONTINUE;
}

GetLine::Status GetLine::erase_or_listing(int key)
{
  return pos == len ? this->listing(key) : this->erase(key);
}

GetLine::Status GetLine::erase(int)
{
  if( atrbuf[pos] == SBC ){
    delroom(pos,1);
    repaint_after(1);
  }else{
    delroom(pos,2);
    repaint_after(2);
  }
  repaint_after();
  return CONTINUE;
}


GetLine::Status GetLine::backspace(int key)
{
  if( pos > 0 ){
    backward(key);
    erase(key);
  }
  return CONTINUE;
}

GetLine::Status GetLine::foreward(int)
{
  if( pos < len ){
    if( atrbuf[pos] != SBC ){
      assert(atrbuf[pos] != DBC2ND );
      assert(pos+1<len);
      putchr(strbuf[pos++]);
    }
    putchr(strbuf[pos++]);
  }
  return CONTINUE;
}

GetLine::Status GetLine::backward(int)
{
  if( pos > 0 ){
    if( atrbuf[pos-1] != SBC ){
      if( pos >= 2 ){
	assert(atrbuf[pos-1] == DBC2ND );
	assert(atrbuf[pos-2] == DBC1ST );
	putbs(2);
	pos -= 2;
      }
    }else{
      putbs(1);
      --pos;
    }
  }
  return CONTINUE;
}

GetLine::Status GetLine::goto_head(int)
{
  putbs( pos );
  pos = 0;
  return CONTINUE;
}

GetLine::Status GetLine::goto_tail(int)
{
  for( ; pos < len ; pos++ )
    putchr( strbuf[pos] );
  return CONTINUE;
}

GetLine::Status GetLine::erase_line(int)
{
  for(int i=pos ; i<len ; i++)
    putchr( ' ' );
  putbs( len-pos );
  len=pos;
  return CONTINUE;
}

GetLine::Status GetLine::erase_all(int key)
{
  putbs( pos ); pos = 0;
  return erase_line( key );
}

int GetLine::insert_text(const char *s,int at)
{
  if( s == NULL )
    return 0;

  if( at==-1 )
    at = pos;

  int len=strlen(s);
  makeroom( at , len );
  bool afterkanji=false;

  while( *s != '\0' ){
    if( afterkanji ){
      atrbuf[ at ] = DBC2ND;
      afterkanji = false;
    }else if( isKanji(*s) ){
      atrbuf[ at ] = DBC1ST;
      afterkanji = true;
    }else{
      atrbuf[ at ] = SBC;
      afterkanji = false;
    }
    strbuf[ at++ ] = *s++;
  }
  return len;
}

GetLine::Status GetLine::yank(int)
{
  const char *clipboard=getClipBoardValue();
  if( clipboard == NULL )
    return CONTINUE;
  
  int len=insert_text( clipboard );
  while( len-- )
    putchr( strbuf[pos++] );

  repaint_after();
  return CONTINUE;
}

/* ��s���̓��C���֐�(2).
 * STL �𗘗p���Ȃ��\�[�X���痘�p����ۂɗ��p����.
 *	default_value ���͒l�̃f�t�H���g�l�B
 * return
 *	��NULL - ���͂���������B
 *	NULL - �L�����Z�����ꂽ�B
 */
const char *GetLine::operator() (const char *default_value)
{
  static string result;
  
  result.assign( default_value != NULL ? default_value : "" );
  if( (*this)( result ) >= 0 ){
    // �q�X�g���ɓ����Ă���͂�.
    return result.c_str();
  }else{
    return NULL;
  }
}

/* ��s���̓��C���֐�(1).
 *	result - [in] ���͂̃f�t�H���g�l [out] ���͌���
 * return
 *	0�ȏ� - ������̒���
 *	-1    - �L�����Z�����ꂽ
 *	-2    - ���̑��̃G���[
 */
int GetLine::operator() ( string &result )
{
  max = INIT_BUFSIZE;
  strbuf = (char*)malloc( INIT_BUFSIZE );
  if( strbuf == NULL ){
    return -2;
  }
  atrbuf = (char*)malloc( INIT_BUFSIZE );
  if( atrbuf == NULL ){
    free(strbuf);
    return -2;
  }
  pos = len = 0;

  /* �f�t�H���g�l������ꍇ */
  if( result.length() > 0 ){
    /* �f�t�H���g�l�̕����񒷂��m�ۂ����o�b�t�@���傫���� */
    int default_value_len = result.length();
    if( default_value_len >= max ){
      max = default_value_len + INIT_BUFSIZE;
      free(strbuf); strbuf = (char*)malloc( max );
      free(atrbuf); atrbuf = (char*)malloc( max );
      if( strbuf == NULL || atrbuf == NULL ){
	free(strbuf); free(atrbuf);
	strbuf = atrbuf = 0;
	return -2;
      }
    }
    const char *default_value = result.c_str();

    while( *default_value != '\0' ){
      if( isKanji(*default_value) ){
	putchr( strbuf[ len ] = *default_value++ );
	atrbuf[ len++ ] = DBC1ST;

	putchr( strbuf[ len ] = *default_value++ );
	atrbuf[ len++ ] = DBC2ND;
      }else{
	putchr( strbuf[ len ] = *default_value++ );
	atrbuf[ len++ ] = SBC;
      }
    }
    pos = len;
  }
  start();
  lastKey = 0;
  
  for(;;){
    int key=getkey();
    switch( (this->*bindkey(key))(key) ){
    case CONTINUE:
      break;

    case CANCEL:
      free(strbuf);
      free(atrbuf);
      end();
      strbuf = atrbuf = 0;
      result.erase();
      return -1;
      
    case ENTER:
      if( len > 0  &&  strbuf != NULL ){
	strbuf[len] = '\0';
	history.push_back( result = strbuf );
      }else{
	result = "";
      }
      
      while( ! future.empty() )
	future.pop();
      end();
      free(strbuf);
      free(atrbuf);
      strbuf = atrbuf = 0;
      return len;
    }
    lastKey = key;
  }
}

// -- at ���� nchars �o�C�g���� string �Œu������ --
int GetLine::replace(int at,int nchars, const char *string, int new_nchars)
{
  if( new_nchars < 0 )
    new_nchars=strlen(string);

  if( nchars < new_nchars ){
    makeroom( at+nchars , new_nchars-nchars );
  }else if( nchars > new_nchars ){
    delroom( at+new_nchars , nchars-new_nchars);
  }

  for(int i=0;i<new_nchars;i++){
    if( isKanji( string[i] ) ){
      assert( i < new_nchars-1 );
      strbuf[ at+i ] = string[i];
      atrbuf[ at+i ] = DBC1ST;
      i++;
      strbuf[ at+i ] = string[i];
      atrbuf[ at+i ] = DBC2ND;
    }else{
      strbuf[ at+i ] = string[i];
      atrbuf[ at+i ] = SBC;
    }
  }
  return new_nchars-nchars;
}

void GetLine::replace_all_repaint( const string &s )
{
  /* ���݂̃q�X�g���J�[�\���̓��e��ҏW���e�ƒu��������B */
  int diff=-replace(0,len, s.c_str() , s.length() );
  putbs(pos);
  for(pos=0;pos<len;pos++)
    putchr(strbuf[pos]);
  if( diff > 0 ){
    for(int bs=0;bs<diff;bs++)
      putchr(' ');
    putbs(diff);
  }
}

GetLine::Status GetLine::previous(int)
{
  if( history.empty() )
    return CONTINUE;

  if( len > 0 ){
    strbuf[ len ] = '\0';
    future.push( strbuf );
  }
  replace_all_repaint( history[ history.size()-1 ] );
  history.pop_back();

  return CONTINUE;
}


GetLine::Status GetLine::next(int)
{
  if( len > 0 ){
    strbuf[ len ] = '\0';
    history.push_back( strbuf );
  }
  if( future.empty() ){
    replace_all_repaint( "" );
  }else{
    replace_all_repaint( future.top() );
    future.pop();
  }

  return CONTINUE;
}

GetLine::Status (GetLine::*GetLine::bindmap[512])(int);

void GetLine::bindkey(int key,GetLine::BindFunc func)
{
  if( localmap == 0 ){
    localmap = (BindFunc*)malloc(sizeof(bindmap));
    memcpy(localmap,bindmap,sizeof(bindmap));
    currentmap = localmap;
  }
  assert( key <= numof(bindmap) );
  localmap[ key ] = func;
}


GetLine::GetLine()
: localmap(0) , currentmap(GetLine::bindmap)
{
  /* --- �o�C���h�֌W --- */
  static bool bindmap_inited=false;
  if( bindmap_inited == false ){
    bindmap_inited=true;
    /* -- �K�v�ŏ����̃L�[�o�C���h�݂̂��` -- */

    for(int i=0;i<numof(bindmap);i++)
      bindmap[ i ] = &do_nothing;
    for(int i=' ';i<256;i++)
      bindmap[ i ] = &insert;
    
    bindmap[ CTRL('D') ] = bindmap[ KEY(DEL)   ] = &erase;
    bindmap[ CTRL('F') ] = bindmap[ KEY(RIGHT) ] = &foreward;
    bindmap[ CTRL('B') ] = bindmap[ KEY(LEFT)  ] = &backward;
    bindmap[ CTRL('M') ] = bindmap[ CTRL('J') ]  = &enter;
    bindmap[ CTRL('H') ] =                         &backspace;
    bindmap[ CTRL('A') ] = bindmap[ KEY(HOME) ]  = &goto_head;
    bindmap[ CTRL('E') ] = bindmap[ KEY(END) ]   = &goto_tail;
    bindmap[ CTRL('K') ] =                         &erase_line;
    bindmap[ CTRL('U') ] =			   &erase_all;
    bindmap[ CTRL('[') ] =                         &cancel;
    bindmap[ CTRL('P') ] = bindmap[ KEY(UP) ]    = &previous;
    bindmap[ CTRL('N') ] = bindmap[ KEY(DOWN) ]  = &next;
    bindmap[ CTRL('I') ] =                         &complete;
    bindmap[ CTRL('Y') ] = bindmap[ KEY(CTRL_INS)] = &yank;
  }
}

GetLine::~GetLine()
{
  free(localmap);
}

void GetLine::makeCompletionList( const string &path , vector <string> &array )
{
  string basename=path;
  basename += '*';
  (void)AFile::explode( basename.c_str() , array , '/' );
}

/* ������ s1 �� ������ s2 �Ƃ̋��ʕ����̒����𓾂� */
static int sameLength(const char *s1 , const char *s2)
{
  int len=0;
  while( *s1 != '\0' && *s2 != '\0' &&  toupper(*s1) == toupper(*s2) ){
    if( isKanji(*s1) ){
      ++len; ++s1 ; ++s2;
      if( *s1 != *s2 ) /* ������2�o�C�g�ڂ� toupper �ƒʂ����ɔ�r���� */
	break;
    }
    ++len; ++s1 ; ++s2;
  }

  return len;
}

GetLine::Status GetLine::complete(int)
{
  int at,size;
  vector <string> list;
  
  makeCompletionList( current_word(at,size) , list );

  // �⊮��₪�P�����̏ꍇ�A���������ɏI������.
  if( list.size() <= 0 )
    return CONTINUE;
  
  // �⊮���̑������Ƃ肠�����o�b�t�@�փR�s�[.
  int leastmatch=list[0].length();
  char *match=(char*)alloca( leastmatch+1 );
  strcpy( match , list[0].c_str() );
  
  // ��Ԗڈȍ~�̌��Ɣ�r���Ă䂫�A���ʕ����������c���Ă䂭.
  for( size_t i=1; i < list.size() ; ++i ){
    leastmatch = sameLength( list[i].c_str() , match );
    match[ leastmatch ] = '\0';
  }
  if( leastmatch < size )
    return CONTINUE;

  // ���̓o�b�t�@�̍X�V
  replace(at,size,match,leastmatch);

  // �\���̍X�V.
  putbs( pos-at );
  for(int j=at ; j < at+leastmatch ; j++ )
    putchr( strbuf[j] );
  pos = at+leastmatch;
  
  repaint_after();
  return CONTINUE;
}

GetLine::Status GetLine::listing(int)
{
  // ��⊮������𔲂��o��.
  int at,size;

  // �⊮���쐬.
  vector <string> list;
  makeCompletionList( current_word(at,size) , list );

  // �⊮��₪�P�����̏ꍇ�A���������ɏI������.
  if( list.size() <= 0 )
    return CONTINUE;

  sort( list.begin() , list.end() );

  vector <string> prints;
  AFile::listing( list , prints , getWidth() );
  
  putchr('\n');
  for(size_t i=0;i<prints.size();i++){
    for(size_t j=0 ; j<prints[i].length() ; j++ )
      putchr( prints[i][j] );
    putchr('\n');
  }

  prompt();
  
  for(int i=0;i<pos;i++)
    putchr( strbuf[i] );
  repaint_after();
  
  return CONTINUE;
}

GetLine::Status GetLine::complete_or_listing(int key)
{
  if( lastKey == key )
    return this->listing(key);
  else
    return this->complete(key);
}

void GetLine::prompt()
{
  putchr('>') ; putchr(' ');
}
