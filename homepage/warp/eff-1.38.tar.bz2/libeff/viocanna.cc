#include <stdlib.h>
#include <stdio.h>
#include <sys/video.h>

#define INCL_WIN
#define INCL_VIO
#include <os2.h>

#include "pmint.h"
#include "effetc.h"
#include "icanna.h"

#undef TEST

void iCannaVio::start(void)
{
  ::box_cursor_on();
}

void iCannaVio::end(void)
{
  clear_bottom();
  ::cursor_off();
}

int iCannaVio::getrawkey(void)
{
  return ::readkey();
}

void iCannaVio::putchr(int ch)
{
  static int prevchar=0;
  if( prevchar != 0 ){
    char buf[3]={ prevchar , ch , '\0' };
    v_puts(buf);
    prevchar = 0;
  }else if( isKanji(ch) ){
    prevchar = ch;
  }else{
    v_putc(ch);
  }
}

void iCannaVio::putbs(int n)
{
  v_backsp(n);
}

int iCannaVio::puts_bottom( const char *str )
{
  int X,Y,W,H;
  
  v_dimen(&W,&H);
  v_getxy(&X,&Y);

  v_gotoxy(0,H-1);

  if( bottom_buffer == NULL ){
    bottom_buffer = _tmalloc( W*2 );
    if( bottom_buffer != NULL )
      v_getline( (char*)bottom_buffer , 0 , H-1 , W );
  }
  v_puts( str );
  int btmlen = strlen(str);
  int btmlen0 = getBottomSize();
  if( btmlen < btmlen0 )
    v_putn(' ',btmlen0-btmlen);

  v_gotoxy(X,Y);
  return btmlen;
}

void iCannaVio::clear_bottom()
{
  int W,H;
  v_dimen(&W,&H);
  if( bottom_buffer != NULL ){
    v_putline((char*)bottom_buffer , 0 , H-1 , W );
    _tfree(bottom_buffer);
    bottom_buffer = NULL;
  }else{
    v_scroll(0, H-1, W-1, H-1, 1, V_SCROLL_CLEAR );
  }
}

const char *iCannaVio::getClipBoardValue()
{
  return PMInterface::readClipBoard();
}

