#include <stdio.h>
#include "getline.h"

int TtyLineInput::getkey()
{
  fflush(stdout);
  return ::getkey();
}

void TtyLineInput::putchr(int ch)
{
  putchar(ch);
}
void TtyLineInput::putbs(int n)
{
  while(n--)
    putchar('\b');
}
void TtyLineInput::start(void)
{
  raw_mode();
  bindkey( CTRL('D') , &GetLine::erase_or_listing );
  bindkey( CTRL('I') , &GetLine::complete_or_listing );
}
void TtyLineInput::end(void)
{
  cocked_mode();
  putchar('\n');
}

