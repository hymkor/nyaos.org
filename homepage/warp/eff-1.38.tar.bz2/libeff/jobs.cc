#include "pmint.h"
#include "jobs.h"
#define INCL_WINSWITCHLIST
#include <os2.h>

SWENTRY &Jobs::operator[](int n)
{
  return pswblock->aswentry[n];
}

const char *Jobs::getName(int i)
{
  return pswblock->aswentry[i].swctl.szSwtitle;
}

void Jobs::refresh()
{
  HAB hab;
  PMInterface::init( &hab );

  count = WinQuerySwitchList(hab,NULL,0);
  int size = count*sizeof(SWENTRY) + sizeof( ULONG );
  
  free(pswblock);
  pswblock = (PSWBLOCK)malloc( size );
  if( pswblock != NULL ){
    WinQuerySwitchList(hab,pswblock,size);
  }else{
    count = 0;
  }
}

Jobs::Jobs()
: pswblock(0)
{
  refresh();
}

void Jobs::fg(int i)
{
  if( i < N() ){
    WinSwitchToProgram( pswblock->aswentry[i].hswitch );
    WinShowWindow( pswblock->aswentry[i].swctl.hwnd , TRUE );
  }
}

void Jobs::bg(int i)
{
  if( i < N() ){
    WinShowWindow( pswblock->aswentry[i].swctl.hwnd , FALSE );
  }
}
