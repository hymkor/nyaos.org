/* -*- c++ -*- */
#ifndef MACROS_H
#define MACROS_H

#undef THIS
#define THIS (*this)

#undef numof
#define numof(A) ((int)(sizeof(A) / sizeof((A)[0])))

#undef KEY
#define KEY(X) ( (K_##X) | 0x100 )

#undef CTRL
#define CTRL(X) ((X) & 0x1F)

/* �{�w�b�_�t�@�C���́AOS�ˑ����͂���܂���B*/

#ifdef DEBUG
#  undef DEBUG1
#  define DEBUG1(x) (x)
#else
#  undef DEBUG1
#  define DEBUG1(x)
#endif

#ifndef MALLOC_ERROR
#define MALLOC_ERROR
class MallocError{ };
#endif
class FileNotFound{ };

#define LIBEFF_VERSION "0.11"

inline bool isSjisKanji( int x )
{  return ((unsigned char)(((x)^0x20)-0xA1) <= 0x3B);  }

#endif /* MACROS_H */
