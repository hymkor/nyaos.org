#include <stdio.h>
#include <stdlib.h>
#include "effetc.h"

static int keybuf = -1;

int readkey(void)
{
  fflush(stdout);

  if( keybuf != -1 ){
    int ch=keybuf;
    keybuf = -1;
    return ch;
  }
  
  int ch = ( _read_kbd(0,1,0) & 0xFF );

  if( ch == 0 )
    ch = ( (0xFF & _read_kbd(0,1,0)) | 0x100 );
  else if( isKanji(ch) )
    ch = ((ch << 8)|(_read_kbd(0,1,0) & 0xFF));
  
  return ch;
}

void unreadkey(int key)
{
  keybuf = key;
}
