// -*- c++ -*-
#ifndef TOKENIZER_H
#define TOKENIZER_H

#include <string>
#include <iostream>
#include "effetc.h"

class Tokenizer{
  int lastchar , lnum;
  int read();
  int readcont();
  istream &ins;
public:
  int getLNum() const { return lnum; }

  /* �G���[�I�u�W�F�N�g */
  class ErrorObject {
    int lnum;
  public:
    ErrorObject( const Tokenizer &tzer ) : lnum( tzer.getLNum() ) {}
    ErrorObject( const ErrorObject &eo ) : lnum( eo.lnum ) {}
    virtual ~ErrorObject(){}
    virtual ostream &output( ostream &os );
    int getLNum() const { return lnum; }
  };

  class UnexpectedChar : public ErrorObject {
    char letter;
  public:
    UnexpectedChar( Tokenizer &tzer )
      : ErrorObject(tzer) , letter(*tzer) {}
    UnexpectedChar( Tokenizer &tzer , char ch ) 
      : ErrorObject(tzer) , letter(ch) {}
    ostream &output( ostream &os );
    char getChar() const { return letter; }
  };

  class UnexpectedWord : public ErrorObject {
    string word;
  public:
    const char *getWord() const { return word.c_str(); }
    
    UnexpectedWord( Tokenizer &tzer , const string &w )
      : ErrorObject(tzer) , word(w) {}
    
    UnexpectedWord( const UnexpectedWord &x )
      : ErrorObject(x) , word(x.word){}

    ostream &output( ostream &os );
  };

  class EtcError : public ErrorObject {
    string messege; // <- static string.
  public:
    const char *getMessege() const { return messege.c_str(); }
    EtcError( Tokenizer &tzer , const string &m )
      : ErrorObject(tzer) , messege(m) { }
    ostream &output( ostream &os );
  };

  class TooNearEof : public ErrorObject {
  public:
    TooNearEof( Tokenizer &tzer ) : ErrorObject(tzer) {}
    ostream &output( ostream &os );
  };

  // �R���X�g���N�^�B
  Tokenizer( istream &p_ins ) : lastchar('\n'),lnum(0),ins(p_ins){ }
  
  class PostIncResult {
    int prevchar;
  public:
    PostIncResult(int ch) : prevchar(ch) { }
    int operator * () const { return prevchar; }
  };

  int operator * () const { return lastchar; }
  Tokenizer &operator++(){ lastchar=read(); return *this; }
  PostIncResult  operator++(int){
    PostIncResult rc(lastchar);   ++*this;   return rc;
  }
  int isOk() const { return ins.good(); }

  /* �\����̊e�v�f���擾���� */
  Tokenizer &passSpace(); // �󔒂�ǂݔ�΂��B
  
  /* �� + ����̕������ǂݔ�΂� */
  void passChar(int ch)        throw(UnexpectedChar,TooNearEof);
  int  passChar(const char *s) throw(UnexpectedChar,TooNearEof);

  /* �󔒒���̍ŏ��̕����𓾂�....
   * ���A�|�C���^�́A���̕������������܂� */
  int topChar() throw(TooNearEof);

  /* ���ʎq( [ \t]*[_a-zA-Z][_a-zA-Z0-9]* ) */
  void readIdentifier( string &buffer )      throw(UnexpectedChar,TooNearEof);
  void readIdentifier(char *buffer,int size) throw(UnexpectedChar,TooNearEof);
  
  /* ������( �_�u���N�H�[�g�Ɉ͂܂ꂽ������ ) */
  void readQuoted( string &buffer )      throw(UnexpectedChar,TooNearEof);
  void readQuoted(char *buffer,int size) throw(UnexpectedChar,TooNearEof);
  
  void readQuotedRexxScript( string &buffer) throw(UnexpectedChar,TooNearEof);
  
  /* ���l */
  int readNumber() throw(UnexpectedChar,TooNearEof);

  void readline( string &buffer ) throw(TooNearEof);
};

inline ostream &operator << ( ostream &os , Tokenizer::ErrorObject &e )
{
  return e.output(os);
}

#endif
