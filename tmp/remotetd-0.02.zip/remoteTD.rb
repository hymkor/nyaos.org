#!/usr/local/bin/ruby -Ks

require "kconv.rb"
require "net/http"
require "cgi"

class RemoteTD 
    def initialize(url,user,passwd)
	Net::HTTP.version_1_2
	url = url + "/" if url !~ %r|/$|;
	if url =~ %r!^http://([^/]+)/! then
	    @server = $1
	end
	@req = Net::HTTP::Post.new("#{url}update.rb")
	@req.basic_auth(user,passwd)
    end
    def download(year,month,day)
	text  = nil
	title = nil
	year = year.to_i
	month = month.to_i
	day = day.to_i
	Net::HTTP.start(@server) do |http|
	    response = http.request(@req,
		sprintf("year=%02d&month=%02d&day=%02d&edit=edit",
			    year , month , day ) )
	    body = Kconv.tosjis(response.body)
	    if body =~ %r!<textarea name="body"[^>]*>(.*)</textarea>!im then
		text = $1
		text.gsub!(/&lt;/,'<')
		text.gsub!(/&gt;/,'>')
		text.gsub!(/&quot;/,'"')
		text.gsub!(/&amp;/,'&')
	    end	
	    if body =~ %r!<input[^>]+name="title"[^>]+value="([^"]+)">! then
		title = $1
		title.gsub!(/&lt;/,'<')
		title.gsub!(/&gt;/,'>')
		title.gsub!(/&quot;/,'"')
		title.gsub!(/&amp;/,'&')
	    end
	end
	{   
	    :title => title , :text  => text ,
	    :year => year   , :month => month , :day => day 
	}
    end
    def upload(mode,year,month,day,title,text)
 	text = "\r\n\r\n" + text.gsub(/\n/,"\r\n") 
	year = year.to_i
	month = month.to_i
	day = day.to_i
 	Net::HTTP.start(@server) do |http|
 	    @req[ 'Content-Type' ] = "application/x-www-form-urlencoded"
 	    response = http.request( @req , 
		sprintf("%s=%s&year=%04d&month=%02d&day=%02d"+
			"&old=%04d%02d%02d&title=%s&body=%s" ,
			mode , mode , 
			year , month , day ,
			year , month , day , 
			(title.nil? ? "" : CGI.escape( Kconv.toeuc(title) ) ),
			(text.nil? ? "" : CGI.escape( Kconv.toeuc(text) ) ) 
		)
	    )
 	end
    end
    def append(year,month,day,title,text)
	upload("append",year,month,day,title,text)
    end
    def replace(contents)
	upload("replace" , 
	    contents[:year] , contents[:month] ,  contents[:day] ,
	    contents[:title], contents[:text] )
    end
end

if __FILE__ == $0 then
    url    = nil
    user   = nil
    passwd = nil
    editor = nil
    pager = nil
    today = Time.now
    year = today.year
    month = today.month
    day = today.day

    # �蔲���ݒ�t�@�C������A���e��f�[�^���擾����.
    open(ENV["HOME"] + "/.tdiaryrc") do |fp|
	while line=fp.gets
	    line.chomp!
	    next if line =~ /^#/ || line =~ /^$/
	    url = $'    if line =~ /^url\s+/i ;
	    user = $'   if line =~ /^user\s+/i ;
	    passwd = $' if line =~ /^passwd\s+/i ;
	    editor = $' if line =~ /^editor\s+/i ;
	    pager = $'  if line =~ /^pager\s+/i ;
	end
    end

    todo_download = true
    while ARGV.length > 0 do
	argv = ARGV.shift
	if argv =~ /^(\d{4})(\d\d)(\d\d)$/ then
	    year  = $1.to_i
	    month = $2.to_i
	    day   = $3.to_i
	elsif argv =~ /^(\d\d)(\d\d)$/ then
	    month = $1.to_i
	    day   = $2.to_i 
	elsif argv =~ /^-n(ew)?$/ then
	    todo_download = false
	end
    end

    rtd = nil
    if todo_download then
	rtd = RemoteTD.new( url , user , passwd )
	contents = rtd.download( year , month , day )
    else
	contents = {
	    :title => "" , :text  => "" ,
	    :year => year   , :month => month , :day => day 
	}
    end

    tempname = ENV["temp"] + "/tdiarytmp.txt"

    fp = open(tempname,"w")
    fp.printf "To: <%s> %s\n" , user , url
    fp.printf "Subject: %s\n" , contents[:title]
    fp.printf "Date: %04d/%02d/%02d\n" ,
	contents[:year] , contents[:month] , contents[:day]
    fp.print "\n"
    fp.print contents[:text] unless contents[:text].nil? ;
    fp.close

    system editor,tempname

    contents = {}

    more = $stdout
    if ! pager.nil? then
	more = open("|#{pager}","w")
    end

    fp = open(tempname,"r")
    while line=fp.gets do
	more.print line
	line.chomp!
	if line =~ /^Subject: / then
	    contents[:title] = $'
	end
	if line =~ %r|^Date: (\d+)/(\d+)/(\d+)| then
	    contents[:year]  = $1
	    contents[:month] = $2
	    contents[:day]   = $3
	end
	if line =~ /^$/ then
	    more.print \
		contents[:text] = fp.readlines.join("")
	    break
	end
    end
    fp.close
    if more != $stdout then
	more.close
    end
    print "Do you post this article? [Y/N] : "
    if readline() =~ /^[yY]/ then
	begin
	    if rtd.nil? then
		# �_�E�����[�h���Ă��Ȃ����́AReplace �ł͂Ȃ��AAppend ����.
		rtd = RemoteTD.new( url , user , passwd )
		rtd.append( 
		    contents[:year] ,
		    contents[:month] ,
		    contents[:day] ,
		    contents[:title] ,
		    contents[:text] )
	    else
		# �_�E�����[�h�������́AReplace ����B
		rtd.replace( contents )
	    end
	rescue
	    print "Failure.\n"
	    raise $!
	else
	    print "Success.\n"
	    File.unlink( tempname )
	end
    end
end
