#!/usr/bin/perl

my @body = ();
while( <> ){
    if( /^(\>+\s?)+/ ){
	$body[ length($&) ] .= $' 
    }else{
	$body[ 0 ] .= $_;
    }
}
my $counter=1;
print "<html><body>\n";
print "<dl style=\"color:black;background-color:white\">\n";
for( my $i=$#body ; $i >= 0 ; --$i ){
    next unless length($body[$i]) > 0 ;
    $body = $body[$i];

    $body =~ s/^\n+//g;
    $body =~ s/&/&amp;/g;
    $body =~ s/</&lt;/g;
    $body =~ s/>/&gt;/g;
    $body =~ s/\n/<br>/g;
    my ($sec,$min,$hour,$mday,$mon,$year) = localtime(time() - $i*60 );

    printf "<dt style=\"font-weight:normal\"";
    printf ">%d ���O�F<font color=\"forestgreen\"><b>",$counter++;
    printf "���������񁗂��������ς��B</b></font>";
    printf "[sage] ���e���F%02d/%02d/%02d %02d:%02d</dt>\n" ,
	$year%100 , $mon+1 , $mday , $hour , $min ;
    printf "<dd>%s<br></dd>\n",$body;
__HERE__
}
print "</dl>\n";
print "</body></html>\n";
