#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

#undef DEBUG

#ifdef DEBUG
#  define DEBUG1(x) (x)
#else
#  define DEBUG1(x)
#endif

#define numof(A) (sizeof(A)/sizeof((A)[0]))

inline int getkey()
{
#ifdef XF86
  int ch=getchar();
  fflush(stdin);
  return ch;
#else
  return _read_kbd(0,1,1);
#endif
}

class Dir{
  DIR *dirp;
  struct dirent *entry;
public:
  enum{ 
    ARCHIVED	= 0x20,
    DIRECTORY	= 0x10,
    VOLUME	= 0x80,
    SYSTEM	= 0x4,
    HIDDEN	= 0x2,
    READONLY	= 0x1,
    ALL = 0x37 ,
  };
  Dir( const char *s ){
    dirp=opendir(s);
    if( dirp != NULL ) entry = readdir(dirp);
  }
  ~Dir(){
    if( dirp != 0 ) closedir(dirp);
  }
  void operator ++ () {
    entry = readdir(dirp);
  }
  operator const void* () const {
    return (dirp != 0 && entry != 0) ? this : 0;
  }
  int operator !() const {
    return dirp == 0 || entry == 0 ;
  }
  const char *get_name() const { return entry->d_name; }
  int get_name_length() const { return entry->d_namlen; }
  int get_size() const { return entry->d_size; }
  int get_attr() const { return entry->d_attr; }
  unsigned short get_date() const { return entry->d_date; }
  unsigned short get_time() const { return entry->d_time; }
  int is_dir() const { return entry->d_attr & DIRECTORY; }
};

static enum{
  NAME_COMPARE = 0,	/* ���O����e�Ƌ��ɔ�r���� */
  NAME_IGNORE  = 1,	/* ���O���r���Ȃ�(���e�I�����[) */
  NAME_ONLY    = 2,	/* ���O�������r����(���e�͔�r���Ȃ�) */
}compareMode = NAME_COMPARE;

bool isCaseIgnore=false;	/* ���O�̑啶���E����������ʂ��Ȃ� */
bool compareWithDiffTree=false; /* �Ⴄ�c���[�̃t�@�C���̂ݔ�r���� */
bool noQueryMode=false;
bool ignoreZero=false;		/* 0�o�C�g�̃t�@�C���𖳎����� */
bool ignoreRdonly=false;	/* �ǂݎ�葮���������Ă��₢���킹���Ȃ� */

const char *get_suffix(const char *name)
{
  const char *rv=_getext2(name);
  return *rv == '.' ? rv+1 : rv;
}

struct SuffixList {
  SuffixList *next;
  char suffix[1];
} *suffixList1st = NULL;

bool isInSuffixList(const char *fname)
{
  const char *suffix=get_suffix(fname);
  for( SuffixList *p=suffixList1st ; p != 0 ; p=p->next ){
    if( stricmp( suffix , p->suffix ) == 0 )
      return true;
  }
  return false;
}


unsigned calcHash(const char *s)
{
  unsigned sum;
  while( *s ){
    if( isCaseIgnore )
      sum += tolower(*s & 255) & 255;
    else
      sum += *s & 255;
    ++s;
  }
  return sum;
}


union TimeCover{
  unsigned short raw;
  struct {
    unsigned second:5;
    unsigned minute:6;
    unsigned hour:5;
  }t;
  TimeCover(){ }
  TimeCover(unsigned short r) : raw(r){ }
};

union DateCover{
  unsigned short raw;
  struct {
    unsigned day:5;
    unsigned month:4;
    unsigned year:7;
  }d;
  DateCover(){ }
  DateCover(unsigned short r) : raw(r){ }
};

/* �t�@�C�������ۂɔ�r����B
 *	fname1 , fname2 �c �t�@�C����
 * return 0�c ��v���� ��0�c��v���Ȃ��B
 */
int file_compare(const char *fname1,const char *fname2)
{
  FILE *fp1=fopen(fname1,"rb");
  if( fp1==NULL )
    return -1;
  FILE *fp2=fopen(fname2,"rb");
  if( fp2==NULL ){
    fclose(fp1);
    return -2;
  }

  int rv;
  for(;;){
    if( feof(fp1) ){
      if( feof(fp2) )
	rv = 0;
      else
	rv = 1;
      break;
    }
    if( getc(fp1) != getc(fp2) ){
      rv = 1;
      break;
    }
  }
  fclose(fp1);
  fclose(fp2);
  return rv;
}

struct FileInfo {
  struct FileInfo *next;
  long hash,size;
  int attr,id;
  TimeCover time;
  DateCover date;
  char *name;
  char fullpath[1];
} *fileinfo[1024];


void rm_latter( const char *curdir , Dir &dir )
{
  if( dir.get_attr() & Dir::READONLY ){
    if( ! ignoreRdonly ){
      printf("  %s/%s �͏������ݕی삳��Ă��܂��B�폜���܂����H [y/n] \n"
	     , curdir , dir.get_name() );
      if( getkey() != 'y' ){
	printf( "  cancel to rm %s/%s\n",curdir,dir.get_name() );
	return;
      }
    }
    chmod( dir.get_name() , S_IWRITE | S_IREAD );
  }
  if( remove( dir.get_name() )==0 )
    printf("  rm %s/%s\n",curdir,dir.get_name() );
  else
    printf("  fail to rm %s/%s\n",curdir,dir.get_name());
}

void rm2( const char *fname )
{
  if( remove( fname ) != 0 ){
    if( ! ignoreRdonly ){
      printf("  %s �͏������ݕی삳��Ă��܂��B�폜���܂����H [y/n] \n"
	     , fname );
      if( getkey() != 'y' ){
	printf( "  cancel to rm %s\n" , fname );
	return;
      }
    }
    if( chmod(fname,S_IWRITE | S_IREAD) != 0 || remove(fname) != 0 ){
      printf( "  fail to rm %s\n" , fname );
      return;
    }
  }
  printf( "  rm %s\n" , fname );
}


void rmclone(int id)
{
  struct Dirlist{
    Dirlist *next;
    char name[1];
  }*dirlist=NULL;

  char curdir[ FILENAME_MAX ];

  _getcwd2( curdir , sizeof(curdir) );
  int curdir_len=strlen(curdir);
  const char *suffix;
  
  for(Dir dir(".") ; dir ; ++dir ){
    if( dir.is_dir() ){
      if( dir.is_dir() && dir.get_name()[0] != '.' ){
	Dirlist *tmp=(Dirlist *)
	  alloca(sizeof(Dirlist)+dir.get_name_length());
	strcpy( tmp->name , dir.get_name() );
	tmp->next = dirlist;
	dirlist = tmp;
      }
    }else if( dir.get_size() == 0 ){
      if( ignoreZero )
	continue;
      
      /* �T�C�Y 0 �̃t�@�C�� */
      printf("  %s/%s�̓T�C�Y�� 0 �ł��B\n"
	     "[f][j] �폜���� [q]���f [��]�������Ȃ��B\n"
	     , curdir , dir.get_name() );
      int key=getkey();
      if( key=='j' || key=='J' || key=='f' || key=='F' ){
	rm2( dir.get_name() );
	goto nextfile;
      }else if( key=='q' || key=='Q' ){
	exit(0);
      }
      putchar('\n');

    }else if(   dir.get_name()[0] == 'c'
	     && strcmp(dir.get_name(),"core")==0 ){
      printf("    %s/%s�́A�R�A�_���v�t�@�C���̉\\��������܂��B\n"
	     "[f][j] �폜���� [q]���f  [��]�������Ȃ��B\n"
	     , curdir , dir.get_name() );

      int key=getkey();
      if( key=='j' || key=='J' || key=='f' || key=='F' ){
	rm2( dir.get_name() );
	goto nextfile;
      }else if( key=='q' || key=='Q' ){
	exit(0);
      }
      putchar('\n');
    }else if(   ( *(suffix=get_suffix(dir.get_name()))=='$'
		 && stricmp(suffix,"$$$")==0  )
	     || (   toupper(*suffix & 255)=='T' && stricmp(suffix,"TMP")==0 )){
      printf("   %s/%s�̓e���|�����t�@�C���̉\\��������܂��B\n"
	     "[f][j] �폜���� [q]���f  [��]�������Ȃ��B\n"
	     , curdir , dir.get_name() );

      int key=getkey();
      if( key=='j' || key=='J' || key=='f' || key=='F' ){
	rm2( dir.get_name() );
	goto nextfile;
      }else if( key=='q' || key=='Q' ){
	exit(0);
      }
      putchar('\n');
      
    }else if( isInSuffixList( dir.get_name() ) ){
      DEBUG1( printf("skipped the file : `%s'.\n",dir.get_name() ) );
      goto nextfile;
    }else{
      /* �d���t�@�C���̌��� 
       * �u���O�݂̂̔�r�v�̏ꍇ�́A���O�̃n�b�V���l
       * �����Ȃ���΁A�t�@�C���T�C�Y��
       * �n�b�V���l�Ƃ���B
       */
      long hashValue= (compareMode == NAME_ONLY
		       ? calcHash( dir.get_name() )
		       : dir.get_size()     );
      long address =  hashValue % numof(fileinfo);
      
      for(struct FileInfo *ptr=fileinfo[address]; ptr != NULL; ptr=ptr->next){
	/* �n�b�V���R�[�h���r���� */
	if( ptr->hash != hashValue )
	  continue;
	
	/* ���O���r����B*/
	if( compareMode != NAME_IGNORE
	   && ( isCaseIgnore
	       ? stricmp( ptr->name , dir.get_name() )
	       : strcmp ( ptr->name , dir.get_name() ) ) != 0 )
	  continue;
	
	/* ���e���r���� */
	if(   compareMode != NAME_ONLY
	   && file_compare( ptr->fullpath , dir.get_name() ) != 0 )
	  continue;

	/* �Ⴄ�c���[�̃t�@�C�����u�݂̂��r����ꍇ */
	if( compareWithDiffTree  && ptr->id == id  )
	  continue;

	TimeCover tc(dir.get_time());
	DateCover dc(dir.get_date());

	printf("   %8ld %04d-%02d-%02d %02d:%02d %s"
	       "\x1B[K\n"
	       "== %8ld %04d-%02d-%02d %02d:%02d %s/%s"
	       "\x1B[K\n"
	       "[f]�O�҂��폜  [j]��҂��폜 [q]���f"
	       " [�����ȊO]�������Ȃ�\n"

	       , ptr->size        , 1980+ptr->date.d.year , ptr->date.d.month 
	       , ptr->date.d.day  , ptr->time.t.hour , ptr->time.t.minute
	       , ptr->fullpath

	       , dir.get_size() , 1980+dc.d.year , dc.d.month
	       , dc.d.day       , tc.t.hour , tc.t.minute
	       , curdir , dir.get_name() );

	if( noQueryMode ){
	  rm_latter( curdir , dir );
	  goto nextfile;
	}

	int key=getkey();
	if( key == 'j' || key =='J' ){
	  rm_latter( curdir , dir );
	  goto nextfile;
	}else if( key == 'f' || key == 'F' ){
	  rm2( ptr->fullpath );
	  goto nextfile;
	}else if( key == 'q' || key == 'Q' ){
	  exit(0);
	}else{
	  goto nextfile;
	}
	putchar('\n');
      }

      /* �{�t�@�C���̓o�^ */
      struct FileInfo *tmp = (struct FileInfo *)
	malloc(  sizeof(struct FileInfo)
	       + curdir_len + dir.get_name_length() );
      
      char *dp=tmp->fullpath;
      int lastchar=0;
      for(const char *sp=curdir ; *sp != '\0' ; ++sp )
	lastchar = *dp++ = *sp;
      if( lastchar !='\\' && lastchar != '/' )
	*dp++ = '/';
      tmp->name = dp;
      for(const char *sp=dir.get_name() ; *sp != '\0' ; ++sp )
	*dp++ = *sp;
      *dp = '\0';
      tmp->size = dir.get_size();
      tmp->attr = dir.get_attr();
      tmp->id = id;
      tmp->hash = hashValue;
      tmp->time.raw = dir.get_time();
      tmp->date.raw = dir.get_date();
      
      tmp->next = fileinfo[ address ];
      fileinfo[ address ] = tmp;
    }
  nextfile:
    ;
  }
  
  for(Dirlist *ptr=dirlist ; ptr != NULL ; ptr=ptr->next ){
    if( chdir( ptr->name ) != 0 ){
      fprintf(stderr,"%s : cannot chdir.\n",ptr->name );
      return;
    }
    printf("chdir %s\x1B[K\r",ptr->name );
    rmclone(id);
    chdir( ".." );
  }
}

int main(int argc,char **argv)
{
  for(int i=0; i<numof(fileinfo) ; i++ )
    fileinfo[ i ] = NULL;

  int ndirs=0;
  char curdir[ FILENAME_MAX ];
  _getcwd2( curdir , sizeof( curdir ) );

  for(int i=1;i<argc;i++){
    if( argv[i][0] == '-' ){
      switch( argv[i][1] ){
      default:
	fprintf(stderr,"%s : no such option `%s'\n"
		, argv[0] , argv[i] );
	break;

      case 'i':
	isCaseIgnore = true;
	break;

      case 'n':
	compareMode = NAME_IGNORE;
	break;

      case 'f':
	compareMode = NAME_ONLY;
	break;
	
      case 't':
	compareWithDiffTree = true;
	break;

      case 'x':
	{
	  const char *p=argv[i]+2;
	  if( *p == '.' )
	    ++p;
	  int len=strlen(p);
	  SuffixList *tmp=(SuffixList*)malloc(sizeof(SuffixList)+len);
	  tmp->next = suffixList1st;
	  strcpy( tmp->suffix , p );
	  suffixList1st = tmp;
	}
	break;

      case 'q':
	noQueryMode = true;
	break;

      case '1':
	ignoreZero = true;
	break;

      case 'r':
	ignoreRdonly = true;
	break;

      case 'h':
	printf("RMCLONE 2.3 (c) HAYAMA,Kaoru.\n"
	       "\n"
	       "> rmclone {options} {directories}\n"
	       "  -h  : This message\n"
	       "  -i  : Ignore filename's cases.\n"
	       "  -n  : Ignore filename.\n"
	       "  -f  : Compare only filename.(Ignore size,etc...)\n"
	       "  -q  : Not query. always kill the latter file.\n"
	       "  -t  : Compare with files on different directory tree.\n"
	       "  -r  : Not query even if the file is write protected.\n"
	       "  -1  : Ignore files whose size are zero.\n"
	       );
	return 0;
      }
    }else{
      _chdir2( argv[i] );
      printf( "chdir %s\r" , argv[i] );
      rmclone(i);
      _chdir2( curdir );
      ndirs++;
    }
  }
  if( ndirs == 0 )
    rmclone(0);

  return 0;
}
