/* ���O�t���p�C�v�ɂ�� NYAOS �R���g���[���F�T���v�� */

#include <stdlib.h>
#include <stdio.h>
#define INCL_DOSQUEUES
#include <os2.h>

int main()
{
  /* ���s����R�}���h �� */
  const char commands[] = "ls ; cd ..";
  
  const char *pipeName2nyaos=getenv( "PIPE2NYAOS" );
  if( pipeName2nyaos == NULL ){
    puts("not set $PIPE2NYAOS");
    return -1;
  }

  HPIPE hp;
  unsigned long ulAction;

  int rc=DosOpen( (unsigned const char *)pipeName2nyaos
		 , &hp
		 , &ulAction
		 , 0
		 , FILE_NORMAL
		 , OPEN_ACTION_FAIL_IF_NEW | OPEN_ACTION_OPEN_IF_EXISTS
		 , OPEN_ACCESS_WRITEONLY | OPEN_SHARE_DENYNONE
		 , NULL );
  if( rc ){
    printf("can't DosOpen(%d)\n",rc);
    return -1;
  }
  unsigned long nbytes;
  
  DosWrite( hp , commands , sizeof(commands) , &nbytes );
  DosClose(hp);
  return 0;
}
