#
# mjdiary_style.rb: tDiary style class for mjDiary format.
# $Id$
#
# if you want to use this style, add @style into tdiary.conf below:
#
#    @style = 'mjDiary'
#
# 2004/02/21 modified by K.hayama from etdiary
# 2005/01/09

def auto_anchor(text)
    return nil if text.nil?
    text.gsub(/(http\:[^\"\{\s]+)\{([^\}]+)\}/) do 
	url = $1 ; body = $2
	url.gsub!( /\&amp;/ , "\&" )
	url.gsub!( /\&/ , "\&amp;" )
	body.gsub!( /^\s+/ , '' )
	body.gsub!( /\s+$/ , '' )
	%Q|<a href="#{url}" target="_blank">#{body}</a>|
    end
end
    
module TDiary
    ### ��������󥪥֥������� ###
    class MjdiarySection
        attr_reader :subtitle, :bodies, :author, :anchor_type
        attr_reader :categories, :stripped_subtitle

        alias :subtitle_to_html :subtitle
        alias :stripped_subtitle_to_html :stripped_subtitle
    
        def initialize( title, author = nil )
            @subtitle = title
            if @subtitle then
                if "" == @subtitle then
                    @subtitle = nil
                    @anchor_type = :P
                elsif "<>" == @subtitle then
                    @subtitle = nil
                    @anchor_type = :A
                elsif /^<>/ =~ @subtitle then
                    @subtitle = @subtitle[2..-1]
                    @anchor_type = :H4
                else
                    @anchor_type = :H3
                end
            else
                @subtitle = nil
                @anchor_type = nil
            end
            @bodies = []
            @categories = get_categories
            @stripped_subtitle = auto_anchor(strip_subtitle)
        end
    
	def set_body( bodies )
	    @bodies = bodies
	end
        def body
            if @bodies then
                @bodies.join('')
            else
                ''
            end
        end
	def each_paragraph
	    section = nil
	    each_paragraph do |fragment|
		if section and nil == fragment.anchor_type then
		    section << fragment.body
		else
		    yield section if section and section.anchor_type
		    section = fragment.dup
		    section.set_body( [ fragment.body ] )
		end
	    end
            yield section if section
	end
        alias :body_to_html :body

        def << (string)
            @bodies << string
        end

        def to_src
            s = ''
            case @anchor_type
            when :A
                s << "<<<>>>\n"
            when :P
                s << "<<>>\n"
            when :H4
                s << "[#{@author}]" if @author
                s << "<<<>" + @subtitle + ">>\n"
            when :H3
                s << "[#{@author}]" if @author
                s << "<<" + @subtitle + ">>\n"
            end
            s + ( if "" != body then body else "\n" end )
        end
    
        def to_s
            "subtitle=#{@subtitle}, body=#{body}"
        end

        def get_categories
            return [] unless @subtitle
            cat = /^(\[(.*?)\])+/.match(@subtitle).to_a[0]
            return [] unless cat
            cat.scan(/\[(.*?)\]/).collect do |c|
                c[0].split(/,/)
            end.flatten
        end

        def categorized_subtitle
            return "" unless @subtitle
            cat = /^(\[(.*?)\])+/.match(@subtitle).to_a[0]
            return @stripped_subtitle unless cat
            cat.gsub(/\[(.*?)\]/) do
                $1.split(/,/).collect do |c|
                    %Q|<%= category_anchor("#{c}") %>|
                end.join
            end + @stripped_subtitle
        end

        def strip_subtitle
            return nil unless @subtitle
	    @subtitle.sub(/^(\[(.*?)\])+/,'')
        end
    end

    class MjHtml4Factory
        def initialize( opt, idx = 1 )
            @opt = opt
            @idx = idx
        end
        # ���դ��������Τ��顢�����ȥ�HTML����������.
        def title( date, fragment )
            return nil if nil == fragment.anchor_type
            name = 'p%02d' % @idx
            @idx += 1
            if :A == fragment.anchor_type then
                if @opt['anchor'] then
                    return "<a name=\"#{name}\"></a>"
                else
                    return nil
                end
            end

            r = "<a"
            r << " name=\"#{name}\"" if @opt['anchor']
            r << " href=\"" + @opt['index']
            r << "<%=anchor \"" + date.strftime('%Y%m%d') + "#" + name + "\" %>\">"
            r << @opt['section_anchor'] + "</a>"
            r << "[" + fragment.author + "]" if fragment.author
            r << fragment.categorized_subtitle if fragment.subtitle

            case fragment.anchor_type
            when :P
                r
            when :H4
                "<h4>" + r + ":</h4>\n"
            when :H3
                "<h3>" + r + "</h3>\n"
            end
        end
        def section_start
            "<div class=\"section\">\n"
        end
        def section_end
            "</div>\n"
        end
        def block_title?( fragment )
            case fragment.anchor_type
            when :H3, :H4
                true
            else
                false
            end
        end
        def p_start
            "<p>"
        end
        def p_end
            "</p>"
        end
        def pre_start
            "<pre>"
        end
        def pre_end
            "</pre>"
        end
    end

    class MjCHtmlFactory
        def initialize( opt, idx = 1 )
            @opt = opt
            @idx = idx
        end
        def title( date, fragment )
            return nil if nil == fragment.anchor_type
            name = 'p%02d' % @idx
            @idx += 1
            r = "<A NAME=\"#{name}\">"
            return r + "</A>" if :A == fragment.anchor_type
            r << "*" if :A != fragment.anchor_type
            r << "</A> "
            r << "[" + fragment.author + "]" if fragment.author
            r << fragment.subtitle if fragment.subtitle
            case fragment.anchor_type
            when :P
                r
            when :H4
                r + ": "
            when :H3
                "<H3>" + r + "</H3>\n"
            end
        end
        def section_start
            ""
        end
        def section_end
            ""
        end
        def block_title?( fragment )
            case fragment.anchor_type
            when :H3
                true
            else
                false
            end
        end
        def p_start
            "<P>"
        end
        def p_end
            "</P>"
        end
        def pre_start
            "<PRE>"
        end
        def pre_end
            "</PRE>"
        end
    end

    class MjdiaryDiary
        include DiaryBase
        include CategorizableDiary
    
        TAG_BEG_REGEXP = /\A<([A-Za-z0-9]+)([^>]*)>([^\r]*)\z/
        TAG_END_REGEXP = /\A([^\r]*)<\/([A-Za-z0-9]+)>\n*\z/
        PRE_REGEXP     = /\A<[Pp][Rr][Ee][^>]*>([^\r]*)<\/[Pp][Rr][Ee]>\n*\z/
        TITLE_REGEXP   = /\A<<([^\r]*?)>>[^>]/
        USRTAG_REGEXP  = /\A</
        TABLE_REGEXP   = /\A\s*\|\|/
        DL_REGEXP      = /\A\s*\:/
        UL_REGEXP      = /\A\s*\*/
        P256_REPEXP    = /\A>>\s*(.*)\s*<<\s*\Z/m
    
        def initialize( date, title, body, modified = Time::now )
            init_diary
	    set_date( date )
	    set_title( title )
	    @sections = []
	    if body != '' then
		append( body )
	    end
            @last_modified = modified
        end
    
        def style
            'mjDiary'
        end
    
        def replace( date, title, body )
            set_date( date )
            set_title( title )
            @sections = []
            append( body )
        end

        ### ���ɵ��ע� �ƥ����Ȥ򥻥�����󤴤Ȥ�ʬ�䤷�ơ�@sections ����Ͽ...
        def append( body, author = nil )
            section = nil   ### (8/12RM) MjdiarySection::new( nil, author )
            buffer = nil    ### �� ��������λ����ޤǡ��ݴɤ���Хåե�
            tag_kind = nil  ### �� ̤�������μ���

            ### body ����Ԥ�ʬ�䤷��������Ȥ˽���.
            body.gsub(/\r/,'').sub(/\A\n*/,'').sub(/\n*\z/,"\n\n").each("") \
	    do |fragment|
                if buffer and \
                   TAG_END_REGEXP =~ fragment and \
                   $2.downcase == tag_kind \
                then
                    ### �Ĥ��������������� ###
                    section << buffer + fragment.sub(/\n*\z/,"\n\n")
                    tag_kind = nil
                    buffer = nil
                elsif buffer then
                    ### ������̤���ξ��ϡ��Хåե����
                    buffer << fragment
                else
		    if section
			@sections << section
		    end
                    ### ������³�ǤϤʤ������̤�����.
                    title = TITLE_REGEXP.match(fragment+"\n").to_a[1]
		    section = MjdiarySection::new( title, author )
		    ### �������Τ��饿���ȥ�Ԥ����.
		    fragment = fragment[ title.length + 4 .. -1 ] \
			.sub(/\A\n/,'') if title
                    ### �����ǻϤޤ�ԤǤ����...
                    if TAG_BEG_REGEXP =~ fragment then
                        tag_kind = $1.downcase
                        ### ���������뤷�Ƥ����顢
                        if TAG_END_REGEXP =~ fragment and \
                           $2.downcase == tag_kind \
                        then
                            section << fragment.sub(/\n*\z/,"\n\n")
                            tag_kind = nil
                        else
                            buffer = fragment
                        end
                    ### �ץ졼�������Ǥ����...
                    else
                        section << fragment
                    end
                end
            end
            if section then
                @sections << section
            end
            @last_modified = Time::now
            self
        end

	def each_paragraph
	    @sections.each do |fragment|
		yield fragment
	    end
	end

	def each_section
	    section = nil
	    each_paragraph do |fragment|
		if section and nil == fragment.anchor_type then
		    section << fragment.body
		else
		    yield section if section and section.anchor_type
		    section = fragment.dup
		    section.set_body( [ fragment.body ] )
		end
	    end
	    yield section if section
	end   

        def to_src
            src = ''
	    each_paragraph do |fragment|
		src << fragment.to_src
            end
            src.sub(/\n*\z/,"\n")
        end

        ### ������������HTML�� ###
        def to_html_section(section, factory)
            ## ����ͤ� HTML
            r = ''
            ## ����Τ�����������
	    s = if section.bodies then
		section.body 
	    else 
		nil 
	    end
            ## ����Τ����Υ����ȥ���
	    t = factory.title( date, section )
	    t = auto_anchor( t ) if t

	    if factory.block_title?(section) then
		r << t if t
		t = nil
	    end

            ## section.bodies.each do |fragment|
            ### <PRE>��������� ###
            if s && PRE_REGEXP =~ s then
                r << factory.p_start << t << factory.p_end << "\n" if t
                r << factory.pre_start
                r << $1.gsub(/&/,"&amp;").gsub(/</,"&lt;").gsub(/>/,"&gt;")
                r << factory.pre_end << "\n"
            ### ���̥������������ ###
            elsif s && USRTAG_REGEXP =~ s then
                r << factory.p_start << t << factory.p_end << "\n" if t
                r << auto_anchor(s.sub( /\n*\z/, "\n" ))
            ### �ơ��֥륻������� ###
            elsif s && TABLE_REGEXP =~ s then
                r << "<table border align=\"center\" class=\"framed\"><tr>"
                $'.split(/\|/).each do |ss|
                    if ss =~ /\A\Z/ then
                        r << "</tr>\n<tr>"
                    else
                        r << "<td>#{ss}</td>\n"
                    end
                end
                r << "</tr></table>\n"
            ### 256������������� ###
            elsif s && P256_REPEXP =~ s then
                r << %Q|<p align="center" class="OxFF">#{$1}</p>\n|
            ### ���ꥹ�ȥ�������� ###
            elsif s && DL_REGEXP =~ s then
                r << factory.p_start << t << factory.p_end << "\n" if t
                r << "<dl>\n"
                s.split(/^\s*:/).each do |ss|
                    if ss =~ /^:/ then
                        r << "<dd>" << auto_anchor($') << "</dd>\n"
                    else
                        r << "<dt>" << auto_anchor(ss) << "</dt>\n"
                    end
                end
                r << "</dl>\n"
            ### ����������� ###
            elsif s && UL_REGEXP =~ s then
                r << factory.p_start << t << factory.p_end << "\n" if t
                r << "<ul>\n<li>";
                r << auto_anchor(
                        $'.gsub(/\:\:/,'<br>&emsp;') \
                        .split(/\n\s*\*\s*/) \
                        .join("</li>\n<li>") )
                r << "</li>\n</ul>\n";
            ### �ץ졼������������ ###
            else
                r << factory.p_start if t || s
                r << t if t
                r << auto_anchor(s.sub(/\A\n*/,"\n").sub( /\n*\z/, "\n" ) ) if s
                r << factory.p_end + "\n" if t || s 
            end
            r
        end

        ### �����ǡ����� HTML ���Ѵ�����.
        def to_html( opt, mode = :HTML )
            case mode
            when :CHTML
                f = MjCHtmlFactory::new(opt)
            else
                f = MjHtml4Factory::new(opt)
            end
            r = f.section_start
	    each_paragraph do |fragment|
		if :H3 == fragment.anchor_type and r != f.section_start then
		    r << f.section_end << "\n" << f.section_start
		end
	        r << to_html_section(fragment,f)
            end
            r + f.section_end
        end

        def to_s
            "date=#{date.strftime('%Y%m%d')}, title=#{title}, " \
                + "body=[#{@sections.join('][')}]"
        end
    end
end
#vim:set ts=4:
