#!/usr/bin/env ruby

require 'erb'

def anchor(text)
    text.gsub(/(http\:[^\"\{\s]+)\{([^\}]+)\}/) do 
	url = $1 ; body = $2
	url.gsub!( /\&amp;/ , "\&" )
	url.gsub!( /\&/ , "\&amp;" )
	body.gsub!( /^\s+/ , '' )
	body.gsub!( /\s+$/ , '' )
	%Q|<a href="#{url}" target="_blank">#{body}</a>|
    end
end

PRE_REGEXP     = /\A<[Pp][Rr][Ee][^>]*>([^\r]*)<\/[Pp][Rr][Ee]>\n*\z/
TABLE_REGEXP   = /\A\s*\|\|/
H3_REGEXP      = /\A\s*<<(.*)>>\s*\Z/
H4_REGEXP      = /\A\s*<<<>(.*)>>\s*\Z/
DL_REGEXP      = /\A\s*\:/
UL_REGEXP      = /\A\s*\*/
USRTAG_REGEXP  = /\A</
P256_REPEXP    = /\A>>(.*)<<\s*\Z/m

print "<html>\n<head>\n"

option = {}
ARGV.each do |fn|
    if fn =~ /\.css$/ then
	print %Q|  <link rel="stylesheet" type="text/css" href="#{fn}" />\n|
    elsif fn =~ /=/ then
	option[ $` ] = $`
    end
end
ARGV.delete_if { 
    |fn| fn =~ /\.css$/ || fn =~ /=/
}

print "</head><body>\n"

ERB.new($<.read).result.split("\n\n").each do |fragment|
    if PRE_REGEXP =~ fragment then
	print "<pre>"
	print $1.gsub(/&/,"&amp;").gsub(/</,"&lt;").gsub(/>/,"&gt;")
	print "</pre>\n"
    elsif P256_REPEXP =~ fragment then
	print %Q|<p align="center" class="OxFF">#{$1}</p>\n|
    elsif USRTAG_REGEXP =~ fragment then
	print anchor(fragment.sub( /\n*\z/, "\n" ))
    elsif TABLE_REGEXP =~ fragment then
	print %Q|<table border align="center" class="framed"><tr>|
	$'.split(/\|/).each do |s|
	    if s =~ /\A\Z/ then
		print "</tr>\n<tr>"
	    else
		print "<td>#{s}</td>\n"
	    end
	end
	print "</tr></table>\n"
    elsif H4_REGEXP =~ fragment then
	print "<h4>#{$1}</h4>\n"
    elsif H3_REGEXP =~ fragment then
	print "<h3>#{$1}</h3>\n"
    elsif DL_REGEXP =~ fragment then
	print "<dl>\n"
	fragment.split(/^\s*:/).each do |s|
	    if s =~ /^:/ then
		printf "<dd>%s</dd>\n", anchor($')
	    else
		printf "<dt>%s</dt>\n", anchor(s) 
	    end
	end
	print "</dl>\n"
    elsif UL_REGEXP =~ fragment then
	descript = nil
	printf "<ul>\n<li>%s</li>\n</ul>\n" ,
		anchor($'.gsub(/\:\:/,"<br />&emsp;") \
		    .split(/\n\s*\*\s*/).join("</li>\n<li>") )
    else
	printf "<p>%s" ,
	    anchor(
		fragment.sub(/\A\n*/,"\n").sub( /\n*\z/, "\n</p>\n") 
	    )
    end
end
print "</body>\n</html>\n"
