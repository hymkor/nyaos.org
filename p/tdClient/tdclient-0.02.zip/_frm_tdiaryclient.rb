## CAUTION!! ## This code was automagically ;-) created by FormDesigner.
# NEVER modify manualy -- otherwise, you'll have a terrible experience.

require 'vr/vruby'
require 'vr/vrcontrol'
require 'vr/vrhandler'

module Extn_title
  include VRFocusSensitive

  def _cntn_init
   vrinit
  end

end

module Extn_body
  include VRFocusSensitive

  def _cntn_init
   vrinit
  end

end

module Frm_TDiaryClient

  def _TDiaryClient_init
    $_TDiaryClient_fonts=[
      @screen.factory.newfont('�l�r �S�V�b�N',-12,0,4,0,0,0,49,128)
    ]
    self.caption = 'tDiaryClient'
    self.move(48,50,193,275)
    addControl(VRStatic,'static_month',"��",88,16,16,24,1342177280)
    addControl(VREdit,'title',"",8,40,168,24,1342242944)
    @title.extend(Extn_title)._cntn_init
    addControl(VRCombobox,'mode',"",8,216,56,80,1342177795)
    addControl(VRButton,'edit',"�ҏW",96,72,80,24,1342242816)
    addControl(VRStatic,'static_year',"�N",48,16,16,24,1342177280)
    addControl(VRStatic,'modified',"",152,8,16,24,1342177280)
    addControl(VRButton,'download',"Download",8,72,80,24,1342177280)
    addControl(VRButton,'clear',"����",72,216,48,24,1342177280)
    addControl(VREdit,'year',"",8,8,40,24,1342242944)
    addControl(VREdit,'day',"",104,8,24,24,1342242944)
    addControl(VRStatic,'static_day',"��",128,16,24,24,1342177280)
    addControl(VRText,'body',"<�{��>",8,104,168,104,1344340036)
    @body.extend(Extn_body)._cntn_init
    @body.setFont($_TDiaryClient_fonts[0])
    addControl(VREdit,'month',"",64,8,24,24,1342242944)
    addControl(VRButton,'submit',"�o�^",128,216,48,24,1342177280)
  end 

  def construct
    _TDiaryClient_init
  end 

end 

#VRLocalScreen.start Frm_TDiaryClient
