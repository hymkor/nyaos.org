#! ruby -Ks
require 'vr/vruby'
require File.dirname(__FILE__) + '/_frm_tdiaryclient.rb'
require File.dirname(__FILE__) + '/remotetd.rb'

module Frm_TDiaryClient
    MB_OK                   = 0 # OK->1
    MB_OKCANCEL             = 1 # OK->1, CANCEL->2
    MB_ABORTRETRYIGNORE     = 2 # ABORT->3, RETRY->4, IGNORE->5
    MB_YESNOCANCEL          = 3 # YES->6, NO->7, CANCEL->2
    MB_YESNO                = 4 # YES->6, NO->7
    MB_RETRYCANCEL          = 5 # RETRY->4, CANCEL
    RET_MB_OK = 1
    RET_MB_CANCEL = 2
    RET_MB_ABORT=3
    RET_MB_RETRY=4
    RET_MB_IGNORE=5
    RET_MB_YES=6
    RET_MB_NO=7

    def set_modified()   @modified.caption = "*" ; end
    def reset_modified() @modified.caption = "" ; end
    def is_modified()    @modified.caption == "*" ; end

    def year_changed()   set_modified ; end
    def month_changed()  set_modified ; end
    def day_changed()    set_modified ; end
    def title_changed()  set_modified ; end

    def are_you_sure()
	RET_MB_YES == 
	    messageBox("���[�J���ł̕ύX���e��j�����Ă悢�ł���",
		"Download article from Server", MB_YESNO)
    end

    def self_created
	@body.readonly=true
	@year.caption=sprintf("%04d",Time.now.year)
	@month.caption=sprintf("%02d",Time.now.month)
	@day.caption=sprintf("%02d",Time.now.day)
	@mode.setListStrings ["�ǋL","�u��"]
	@mode.select 0

	open( ENV["HOME"]+"/.tdiaryrc" ,"r" ) do |fp|
	    while line=fp.gets do
		next if line =~ /^\s*#/ || line =~ /^\s*$/
		chomp;
		@url = $'    if line =~ /^url\s+/i
		@user = $'   if line =~ /^user\s+/i
		@passwd = $' if line =~ /^passwd\s+/i
	    end
	end
	if @url.nil? || @user.nil? || @passwd.nil? then
	    self.caption = "tDiaryClient - status invalid"
	else
	    @url.gsub!(/\s+$/,"")
	    @user.gsub!(/\s+$/,"")
	    @passwd.gsub!(/\s+$/,"")
	    self.caption = "tDiaryClient - #{@user}@#{@url}"
	end
	self.visible=true
	reset_modified
	focus
    end

    def download_clicked
	if is_modified() && !are_you_sure() then
	    return
	end
	if @account.nil? then
	    # VRLocalScreen.start( Frm_TDiaryLogin )
	    # VRLocalScreen.modelessform(nil,nil,Frm_TDiaryLogin)
	    @account = RemoteTD.new(@url,@user,@passwd)
	end
	# begin
	begin
	    contents = @account.download(@year.text , @month.text , @day.text)
	    @title.text=contents[:title]
	    @body.text=contents[:body].gsub(/\n/,"\r\n")
	    @mode.select 1
	    reset_modified()
	rescue SocketError
	    messageBox("�ʐM�Ɏ��s���܂���","SocketError")
	rescue RemoteTDAuthorizationFailed
	    messageBox("�F�؂Ɏ��s���܂���","RemoteTDAuthorizationFailed")
	end
    end
    def edit_clicked
	tempname = ENV["TEMP"] + "/tdiarytmp.txt"
	open(tempname,"w") do |fp|
	    fp.printf "Subject: %s\n" , @title.text
	    fp.printf "Date: %04d/%02d/%02d\n" ,
		@year.text.to_i , @month.text.to_i , @day.text.to_i
	    fp.print "\n"
	    fp.print @body.text.gsub(/\r/,"") unless @body.nil?
	end
	self.visible=false
	    system ENV["COMSPEC"],"/c","start","/wait",tempname
	self.visible=true
	open(tempname,"r") do |fp|
	    while line=fp.gets do
		line.chomp!
		if line =~ /^Subject: / then
		    @title.text = $'
		end
		if line =~ %r|^Date: (\d+)/(\d+)/(\d+)| then
		    @year.text  = $1
		    @month.text = $2
		    @day.text   = $3
		end
		if line =~ /^$/ then
		    @body.text = fp.readlines.join("").gsub(/\n/,"\r\n")
		    break
		end
	    end
	end
	set_modified
    end
    def clear_clicked
	if are_you_sure() then
	    @title.text=""
	    @body.text=""
	    @mode.select 0
	    reset_modified()
	end
    end
    def submit_clicked
	if messageBox("�o�^���Ă悢�ł����H","Submit?",MB_YESNO) == RET_MB_NO
	    return
	end
	if @account.nil? then
	    @account = RemoteTD.new(@url,@user,@passwd)
	end
	contents = { 
	    :year => @year.text , :month => @month.text , :day => @day.text ,
	    :title => @title.text , :body => @body.text.gsub(/\r/,"")
	} 
	begin
	    if @mode.selectedString == 1 then
		@account.replace( contents )
	    else
		@account.append( contents )
	    end
	    @modified.caption = ""
	    messageBox("�o�^���܂���","TDiaryClient:Submit")
	rescue SocketError
	    messageBox("�ʐM�Ɏ��s���܂���","Socket Error")
	rescue RemoteTDAuthorizationFailed
	    messageBox("�F�؂Ɏ��s���܂���","RemoteTDAuthorizationFailed")
	end
    end
end

VRLocalScreen.start Frm_TDiaryClient
