require "kconv.rb"
require "net/http"
require "cgi"

class RemoteTDAuthorizationFailed < Exception
end
class RemoteTD
    # �ҏW���鎞�̊����R�[�h.
    CODE_FOR_EDIT=Kconv::SJIS

    def initialize(url,user,passwd)
	Net::HTTP.version_1_2
	url += "/" if url !~ %r|/$|;
	if url =~ %r!^http://([^/]+)/! then
	    @server = $1
	end
	@req = Net::HTTP::Post.new("#{url}update.rb")
	@req.basic_auth(user,passwd)
    end
    def download(year,month,day)
	text  = ""
	title = ""
	year = year.to_i
	month = month.to_i
	day = day.to_i
	Net::HTTP.start(@server) do |http|
	    response = http.request(@req,
		sprintf("year=%02d&month=%02d&day=%02d&edit=edit",
			    year , month , day ) );
	    if response.code != "200" then # �F�؃G���[.
		raise RemoteTDAuthorizationFailed , \
		    "response.code=#{response.code}"
	    end
	    body = Kconv.kconv( response.body , CODE_FOR_EDIT )
	    if body =~ %r!<textarea name="body"[^>]*>(.*)</textarea>!im then
		text = $1
		text.gsub!(/&lt;/,'<')
		text.gsub!(/&gt;/,'>')
		text.gsub!(/&quot;/,'"')
		text.gsub!(/&amp;/,'&')
		text.gsub!(/\A\n+/,'')
	    end	
	    if body =~ %r!<input[^>]+name="title"[^>]+value="([^"]+)">! then
		title = $1
		title.gsub!(/&lt;/,'<')
		title.gsub!(/&gt;/,'>')
		title.gsub!(/&quot;/,'"')
		title.gsub!(/&amp;/,'&')
	    end
	end
	{   
	    :title => title , :body  => text ,
	    :year => year   , :month => month , :day => day 
	}
    end
    def upload(mode,year,month,day,title,text)
 	text = "\r\n\r\n" + text.gsub(/\n/,"\r\n") 
	year = year.to_i
	month = month.to_i
	day = day.to_i
 	Net::HTTP.start(@server) do |http|
 	    @req[ 'Content-Type' ] = "application/x-www-form-urlencoded"
 	    response = http.request( @req , 
		sprintf("%s=%s&year=%04d&month=%02d&day=%02d"+
			"&old=%04d%02d%02d&title=%s&body=%s" ,
			mode , mode , 
			year , month , day ,
			year , month , day , 
			(title.nil? ? "" : CGI.escape( Kconv.toeuc(title) ) ),
			(text.nil? ? "" : CGI.escape( Kconv.toeuc(text) ) ) 
		)
	    )
	    if response.code != "200" then # �F�؃G���[.
		raise RemoteTDAuthorizationFailed , \
		    "response.code=#{response.code}"
	    end
 	end
    end
    def append(contents)
	upload("append",
	    contents[:year] , contents[:month] ,  contents[:day] ,
	    contents[:title], contents[:body] )
    end
    def replace(contents)
	upload("replace" , 
	    contents[:year] , contents[:month] ,  contents[:day] ,
	    contents[:title], contents[:body] )
    end
end
