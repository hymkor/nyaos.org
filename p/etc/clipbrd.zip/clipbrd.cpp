/* Borland-C++ �ł����A�e�X�g����Ƃ�܂��� */
#include <assert.h>
#include <io.h>
#include <fcntl.h>
#include <stdio.h>
#include <windows.h>

void writeClipBoard( const char *ptr , int size )
{
    HGLOBAL hText = GlobalAlloc(GMEM_DDESHARE | GMEM_MOVEABLE, size+1 );
    char *pText = (char*)GlobalLock(hText);
    if( pText != NULL ){
        memcpy( pText , ptr , size );
        pText[ size ] = '\0';
        GlobalUnlock(hText);

        OpenClipboard(NULL);
        EmptyClipboard();
        SetClipboardData(CF_TEXT, hText);
        CloseClipboard();
    }
}

int main(void)
{
    char line[ 1024 ];
    char *buffer=NULL;
    size_t size=0;

    setmode( fileno(stdin), O_BINARY );
    while( fgets(line,sizeof(line),stdin) != NULL ){
	int len=strlen(line);
	buffer = (char*)realloc(buffer,size + len + 1);
	assert( buffer != NULL );
	strcpy( buffer+size , line );
	size += len ;
    }
    writeClipBoard( buffer , size );
    free(buffer);
    return 0;
}
